.\" font settings for the Mark Williams COHERENT manuals.
.\" by fwb, 6/91.
.\"
.\" copyright (c) 1991 by Mark Williams Company, Northbrook, Ill.
.\"
.lf RS  Bookman_R.fwt   8
.lf IS  Bookman_I.fwt   8
.lf R	Bookman_R.fwt   9
.lf SC	Bookman_R.fwt   8
.lf B	Bookman_B.fwt   9
.lf I	Bookman_I.fwt   9
.lf L	Courier_R.fwt   8
.lf HR	HelvNar_R.fwt  12
.lf HB	HelvNar_BI.fwt 12
.lf HL	HelvNar_BI.fwt 14
.lf HH	HelvNar_B.fwt  18
.lf HC	Avant_B.fwt    24
.lf S	Symbol.fwt      9
.lf DB	Dingbats.fwt    9
