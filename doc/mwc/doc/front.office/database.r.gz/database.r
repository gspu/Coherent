.ds TL "Invoice Data Base"
.NH "Data Base"
.PP
The following describes the data base for the Mark Williams company.
It stores the following information:
.IP \(bu 0.3i
The name, address, and telephone number
of every person and company that contacted us, either to order a product
or request information.
.IP \(bu
Each invoice every order.
Invoice information include each item that comprises the invoice, the
total cost of the invoice, and the the advertisement or mailer that enticed
the user to contact us.
.IP \(bu
Information about all shipments, in particular for packages shipped via UPS.
.IP \(bu
Users reactions and registration cards.
.IP \(bu
Return authorizations and information about bad media.
.PP
This is a relational data base that is written in standard SQL, under
the Informix DBMS.
If the terms ``relational data base'' or ``SQL'' mystify you, then
you should first read a book on the subject of data bases before you
attempt to read further in this chapter.
.SH "The mwc Data Base"
.PP
The data base, which is named
.BR mwc ,
is maintained by the Informix relational data-base package.
It resides under the SCO version of UNIX system V, on the SCO machine in
the back area of the office.
The data base physically resides in directory
.BR /u/dbase/base .
.PP
The directory
.B /u/dbase/new
also contains a data base named
.BR mwc ,
which has the same schema as the one
.BR /u/dbase/base .
The data base in
.BR /u/dbase/new ,
however, contains junk data and is used only to test changes to the system
before they go into production.
The rest of this section describes each table in the data base
.BR mwc .
.Sh "sws: Identify the System"
.PP
This static table identifies the data base with which you are working.
It is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE sws (
	systm	CHAR(20)	# Which system is this really 
)
.DE
If field
.B systm
is
.BR BASE ,
then you are working with the real data base, which lives in directory
.BR /u/dbase/base .
If, however, it is
.BR JUNK ,
then you are working with the test data base, which lives in directory
.BR /u/dbase/new .
.PP
This table is also used to lock exclusive access to the
.BR tymenet
system.
.Sh "customer: Define a Customer"
.PP
The table
.B customer
gives information about a customer.
There is one record for each customer.
It is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE customer (
	cust_no	SERIAL,
	contact	CHAR(38),
	phone_no	CHAR(36),
	all_nfo	CHAR(1),	# 'y', 'n, or 'x' for non-mailer
	user_id	CHAR(9),
	cust_date	DATE,	# date customer record entered
	crunch	CHAR(10),	# contact in uppercase no vowels
	inq_src	SMALLINT	# source of original inquiry
)
.DE
.IS \fBcust_no\fR 1.0i
A unique serial number for each customer.
This field links to field
.B cust_no
in table invoice, and to field
.B cust_no
in table
.BR address .
.IS \fBcontact\fR
The contact name of the customer, in mixed case, and including spaces.
Note that a ``customer'' may be a company, a married couple, or any other
entity that can sign a check or render a credit-card purchase.
.IS \fBphone_no\fR
The customer's telephone number.
This includes area code, country code (if applicable), and all other
information needed to dial the customer.
.IS \fBall_nfo\fR
A flag that indicates whether the customer is to receive information
on all MWC products.
.B Y
indicates that the customer will receive information on all products;
.B N
indicates that the customer will receive information \*(CO updates only.
.B X
indicates that we no longer have a valid address for this customer.
.IS \fBuser_id\fR
The login identifier of the person at MWC who entered this record.
.IS \fBcust_date\fR
The date that this record was entered into the system.
.IS \fBcrunch\fR
The contents of field
.B contact
but ``crunched'' by the metaphone algorithm (as implemented in the module
.BR metaphone.c )
into a form that is more easily sought.
For example, the names ``Charles Fitterman'' and ``Charles E. Fiterman'' both
crunch into the form ``XRLS FTMN''; which means that you will find this user
regardless of which form of his name you enter.
.IS \fBinq_src\fR
A code for the way in which the customer was moved to first contact MWC.
For example, if a customer calls to request a mailer,
he can say that he first heard about us through an advertisement in
.IR Byte .
This field links to field
.B inq_src
in table
.BR magazines .
.Sh "invoice:  Record an Invoice"
.PP
This table gives the master record for an invoice.
When a customer contacts MWC to order products, one of these records is
created and linked to the customer.
Each product in the invoice has its own entry in table
.BR inv_line ,
which is described below.
.PP
Table
.B invoice
is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE invoice (
	invoice_no	SERIAL(20000),	# invoice number
	cust_no	INTEGER,
	invoice_date	DATE,
	icomments	CHAR(50),
	inq_src	SMALLINT,	# magazine etc
	subtotal	MONEY(8, 2),	# total of invoice lines
	ship_no	SMALLINT,	# Shipper (UPS etc)
	card_no	CHAR(20),	# card no
	exp_date	CHAR(5),	# mm/yy
	ship_amt	MONEY(6, 2),	# Shipping charges
	discount	MONEY(8, 2),	# Customer discount
	taxes	MONEY(8, 2),	# Taxes
	itotal	MONEY(8, 2),	# Total
	ship_date	DATE,	# ship date
	term_no	SMALLINT,	# VISA MC COD etc
	user_id	CHAR(9),	# user who entered invoice
	bounce	CHAR(1),	# the check for this invoice bounced
	batch_ix	INTEGER,	# credit card entry batch no
	ref_no	INTEGER,	# credit card entry reference no
	cap_no	INTEGER,	# credit card capture number
	tym_flag	SMALLINT,	# NULL not part of system
			# 1 new 2 sent 3 approved 4 disapproved
			# 5 new void 6 void 7 disapproved void
			# 8 void in transit
	back_flag	SMALLINT
)
.DE
.IS \fBinvoice_no\fR 1.0i
The unique serial number for this invoice.
This field links to field
.B invoice_no
in table
.BR inv_line .
.IS \fBcust_no\fR
The customer who made this order.
This field links to field
.B cust_no
in table
.BR customer .
.IS \fBinvoice_date\fR
The date the invoice was rendered.
.IS \fBicomments\fR
Comments that apply to this invoice.
.IS \fBinq_src\fR
A code that identifies the source for the order \(em that is,
the source that influenced to customer to pick up his telephone and
buy something from us.
This may have been a mailing, an advertisement in a magazine, word of
mouth, or some other source.
This field links to field
.B inq_src
in table
.BR magazines .
.IS \fBsubtotal\fR
The subtotal of the order.
This field gives the sum of the prices of the products that are linked to
this invoice via table
.BR inv_line .
If, example, the customer has ordered \*(CO plus COHware volume III and
the device-driver kit, then this invoice is linked to three rows in
.BR inv_line ,
one for each product.
Each entry in
.B inv_line
links, in turn, to an entry in table
.BR product ,
whch (among other things) gives the price of the product.
Field
.B subtotal
gives the sum of the prices of the products; in this example, it gives a sum
of the price of \*(CO, of COHware volume III, and of the device-driver kit.
This is called a
.I subtotal
because it does not include the cost of shipping
and handling, Illinois tax (if applicable), and other miscellaneous charges.
.IS \fBship_no\fR
The number of the shipper by which the product will be delivered \(em
UPS, Federal Express, U.S. Mail, etc.
.IS \fBcard_no\fR
The number of the customer's credit card.
.IS \fBexp_date\fR
Date the customer's credit card expires, in the form
.BR mm/yy .
.IS \fBship_amt\fR
The shipping charges.
.IS \fBdiscount\fR
The discount given to the customer, based on the special offer to which
the customer is responding.
.IS \fBtaxes\fR
Illinois sales taxes.
This applies only to residents of Illinois.
.IS \fBitotal\fR
The total charge for this invoice.
It sums the fields
.BR subtotal ,
.BR ship_amt ,
.BR discount ,
and
.BR taxes .
.IS \fBship_date\fR
The date this order was shipped.
.IS \fBterm_no\fR
The manner in which the user paid \(em Visa, MasterCard, COD,
check, etc.
It links to field
.B term_no
in table
.BR terms .
.IS \fBuser_id\fR
The login identifier of the user who entered this invoice.
.IS \fBbounce\fR
Flag if the customer's check bounced.
.IS \fBbatch_ix\fR
The batch number for the credit-card entry.
It links to field
.B batch_ix
in table
.BR batch .
.IS \fBref_no\fR
gives the reference number for the credit-card entry.
.\" Huh?
.IS \fBcap_no\fR
gives the credit-card capture number.
.\" Huh?
.IS \fBtym_flag\fR
The result of a
.B tymnet
transaction.
(\fBtymnet\fR is the network that checks customers' credit cards for validity.
It will disapprove a card if it has been reported to have been lost, if the
customer has reached his credit limit, or some other problem has occurred.)
This flag can be set to one of the following values:
.DS
.ta 0.5i 1.5i
	NULL	not part of system
	1	new
	2	sent
	3	approved
	4	disapproved
	5	new void
	6	void
	7	disapproved void
	8	void in transit
.DE
.IS \fBback_flag\fR 1.0i
Flag whether a product in this invoice is back ordered.
.Sh "address:  Customer's Addresses"
.PP
The table
.B address
gives a customer's addresses.
A customer can has two addresses:
his billing address and his ship-to address.
These addresses may, of course, be the same.
.PP
.B address
is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE address (
	cust_no	INTEGER,	# customer number
	add_type	CHAR(1),	# B = bill to S = ship to X = both
	line1	CHAR(38),
	line2	CHAR(38),
	line3	CHAR(38),
	city	CHAR(20),
	state	CHAR(4),
	country	CHAR(14),
	zipcode	CHAR(11)
)
.DE
.IS \fBcust_no\fR 1.0i
Serial identifier of the customer.
This links to field
.B cust_no
in table
.BR customer .
.IS \fBadd_type\fR
The type of address:
.B B
indicates the bill-to address,
.B S
indicates the ship-to address,
and
.B X
indicates both.
.IS \fBline1\fR
.IS \fBline2\fR
.IS \fBline3\fR
The text of the address \(em that is, the street address,
apartment number, rural-route number, and so on.
.IS \fBcity\fR
.IS \fBstate\fR
.IS \fBcountry\fR
Identify the city, state, and country of the address.
.B state
also identifies Canadian provinces.
A NULL value in field
.B country
indicates the United States.
.IS \fBzipcode\fR
The ZIP code of the address.
If the
.B country
is not
.BR USA ,
this field can hold any text,
e.g., a Canadian postal code.
.Sh "email: Give a User E-mail Address"
.PP
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE email (
	em_cust_no	INTEGER,	# link to customer.cust_no
	em_address	CHAR(35)
)
.DE
.IP \fBem_cust_no\fR
This field gives the customer's serial number, as set in table
.BR customer.cust_no .
.IS \fBem_address\fR
This gives the customer's E-mail address.
.Sh "tech_fup: Technical-Support Follow-up"
.PP
This table records a call that a customer makes to Technical Support.
It is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE tech_fup (
	tf_serial_id	SERIAL,
	tf_cust_no	INTEGER,	# link to customer.cust_no
	tf_user_id	CHAR(9),	# log-in ID of person who took call
	tf_call_date	DATE,	# date the user first called
	tf_resolve_date	DATE,	# date the problem was resolved
	tf_problem1	CHAR(78),	# problem, line 1
	tf_problem2	CHAR(78),	# problem, line 2
	tf_problem3	CHAR(78),	# problem, line 3
	tf_solution1	CHAR(78),	# resolution, line 1
	tf_solution2	CHAR(78),	# resolution, line 2
	tf_solution3	CHAR(78)	# resolution, line 3
)
.DE
.IP \fBtf_serial_id\fR
This gives a unique serial number to each problem.
This is the ``problem number'' that identifies each problem.
.IS \fBtf_cust_no\fR
This gives the number of the customer, as set in table
.BR customer.cust_no .
.IS \fBtf_user_id\fR
This gives the login identifier of the technical-support person who
handled the call.
.IS \fBtf_call_date\fR
This gives the date that the customer called.
.IS \fBtf_resolve_date\fR
This gives the date that the problem was declared to have been resolved.
Note that this field is not yet used.
.IS \fBtf_problem1\fR
.IS \fBtf_problem2\fR
.IS \fBtf_problem3\fR
These fields give a brief description of the problem as the customer
described it to the technical-support person.
.IS \fBtf_solution1\fR
.IS \fBtf_solution2\fR
.IS \fBtf_solution3\fR
These fields hold a description of the advice that the technical-support
person gave to the customer.
.Sh "hardware: Identify Customer Hardware"
.PP
This table describe's a customer's computer system.
It is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE hardware (
	hw_cust_no	INTEGER,
	hw_processor	CHAR(1),
	hw_sx_dx	CHAR(1),
	hw_proc_speed	SMALLINT,
	hw_coproc	CHAR(1),
	hw_ram	SMALLINT,
	hw_video_card	CHAR(10),
	hw_video_ram	SMALLINT,
	hw_hd	CHAR(1),
	hw_hd_space	SMALLINT
);
.DE
.IS \fBhw_cust_no\fR
This gives the customer's serial number, as set in table
.BR customer .
.IS \fBhw_processor\fR
This gives the type of microprocessor the customer's system has, as follows:
.DS
.ta 0.5i 0.8i
	2	80286
	3	80386
	4	80486
	P	Pentium
.DE
.IS \fBhw_sx_dx\fR
This notes whether the processor is a DX or SX:
`D' indicates DX, `S' indicates SX.
Note that this applies only to the 80386 and 80486 microprocessors.
.IS \fBhw_proc_speed\fR
The speed of the microprocessor, in megahertz.
.IS \fBhw_coproc\fR
Whether the user's system has a mathematics co-processor:
`Y' indicates that it does; `N' indicates that it does not.
This applies only to the 80286, 80386, and 80486-SX microprocessors.
.IS \fBhw_ram\fR
The amount of RAM on the user's system, in megabytes.
.IS \fBhw_video_card\fR
The type of video card the user has.
.IS \fBhw_video_ram\fR
The amount of video RAM the user's video card has, in kilobytes.
.IS \fBhw_hd\fR
The type of hard disk the user has.
`A' indicates an AT; `S' indicates SCSI; and `B' indicates both.
.IS \fBhw_hd_space\fR
The amount of disk space the user has, in total, in megabytes.
.Sh "states: Identify States and Provinces"
.PP
This static table gives the abbreviations of states and Canadian provinces.
It is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE states (
	state	CHAR(4),
	country	CHAR(14),
	blue_zone	SMALLINT,
	red_zone	SMALLINT,
	dest_no	SMALLINT
)
.DE
.IS \fBstate\fR 1.0i
The abbreviation of the state or province.
This field is linked to field
.B state
in table
.BR address .
.IS \fBcountry\fR
The country of which this
.B state
is a part.
.IS \fBblue_zone\fR
.IS \fBred_zone\fR
The blue zone and the red zone for this
.BR state ,
as set by the United Parcel Service.
.IS \fBdest_no\fR
The destination number for this state.
It links to field
.B dest_no
in table
.BR dests .
.Sh "prod_ship:  Cost of a Shipment"
.PP
The static table
.B prod_ship
notes how much it costs to ship a product to a given destination.
This table is obsolete and should be ignored.
.\"It is defined as follows:
.\".DM
.\".ta 0.5i 1.5i 3.0i
.\"CREATE TABLE prod_ship (
.\"	prod_no	SMALLINT,
.\"	ship_no	SMALLINT,
.\"	dest_no	SMALLINT,
.\"	const_cost	MONEY(6,2),
.\"	lb_cost	MONEY(6,2)
.\")
.\".DE
.\"Field
.\".B prod_no
.\"identifies the product.
.\"It links to field
.\".B prod_no
.\"in field
.\".BR product .
.\".PP
.\"Field
.\".B ship_no
.\"identifies the shipper that is carrying the product to its destination.
.\"It links to field
.\".B ship_no
.\"in table
.\".BR shippers .
.\".PP
.\"Field
.\".B dest_no
.\"identifies a destination.
.\"It links to field
.\".B dest_no
.\"in table
.\".BR dests .
.\".PP
.\"Fields
.\".B const_cost
.\"and
.\".B lb_cost
.\"give the cost of the shipment.
.\".B const_cost
.\"gives the constant cost of a shipment; and
.\".B lb_cost
.\"gives the cost per pound for shipment.
.Sh "dests:  Identify a Destination"
.PP
The static table
.B dests
identifies a destination.
It is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE dests (
	dest_no	SERIAL,
	dest_name	CHAR(15)
)
.DE
.IS \fBdest_no\fR 1.0i
The unique identifier to a destination.
.IS \fBdest_name\fR
The name of the destination.
.Sh "inv_line:  Link a Product to an Invoice"
.PP
Table
.B inv_line
links a product to an invoice.
It is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE inv_line (
	invoice_no	INTEGER,
	prod_no	SMALLINT,
	quantity	SMALLINT,
	pack_no SMALLINT	# numbers of pakages
)
.DE
.IS \fBinvoice_no\fR 1.0i
identifies the invoice of which this product is a part.
It links to field
.B invoice_no
in table
.BR invoice .
.IS \fBprod_no\fR
The product in question.
It links to field
.B prod_no
in table
.BR product .
.IS \fBquantity\fR
The number of products being shipped.
.IS \fBpack_no\fR
The number of packages by which the product is shipped.
.Sh "product:  Identify a Product"
.PP
The static table
.B product
identifies the products that we sell.
Each variation on our products are included; for example, there
are separate entries for \*(CO with 5.25-inch disks and for \*(CO
with 3.5-inch disks.
It is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE product (
	prod_no	SERIAL,
	prod_name	CHAR(30),
	comment1	CHAR(30),
	price	MONEY(8, 2),
	weight	SMALLINT,
	nolist	SMALLINT,	# don't put on product list
	back_flag	SMALLINT	# Product on back order
)
.DE
.IS \fBprod_no\fR 1.0i
The unique serial number for the product.
.IS \fBprod_name\fR
The name of the product.
.IS \fBcomment1\fR
Comment on the product.
.IS \fBprice\fR
The price of the product.
.IS \fBweight\fR
gives the product's weight, in pounds.
.IS \fBnolist\fR
If is not NULL, indicates that this product is not part of the product list.
.IS \fBback_flag\fR
Flag if a product is currently on back-order.
.Sh "terms:  Note Terminology"
.PP
The static table
.B terms
identifies contractions used throughout the system.
It is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE terms (
	term_no	SERIAL,
	term_name	CHAR(6)
)
.DE
\fBterm_no\fR gives the serial number of the term.
.B term_name
identifies the term.
.Sh "shippers:  Identify a Shipper"
.PP
The static table
.B shippers
identifies a shipper.
It is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE shippers (
	ship_no	SERIAL,
	ship_name	CHAR(15),
	cust_cost	MONEY(6, 2)
)
.DE
.IS \fBship_no\fR 1.0i
The unique serial number that identifies this shipper.
.IS \fBship_name\fR
The name of the shipper.
.IS \fBcust_cost\fR
Cost to the customer for this shipper.
.Sh "magazines:  Identify Magazines"
.PP
The static table
.B magazines
identifies sources of information about MWC.
As the name implies, it identifies the magazines in which we advertise;
it also identifies other avenues of information.
This table is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE magazines (
	inq_src		SERIAL,
	mag_name	CHAR(20),
	cost	MONEY(8, 2),
	cur_ad	SMALLINT
)
.DE
.IS \fBinq_src\fR 1.0i
The serial number for this information source.
.IS \fBmag_name\fR
The source of information \(em usually, the name of a magazine.
.IS \fBcost\fR
The cost for advertising in this magazine, should this be a magazine.
.IS \fBcur_ad\fR
Flag if we currently advertise in that magazine.
.Sh "batch:  Identify a Batch of Credit-Card Purchases"
.PP
Credit-card sales are sent to the bank in batches, usually one batch a day.
Table
.B batch
identifies each batch.
It is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE batch (
	batch_ix	SERIAL(1000),
	batch_no	SMALLINT,
	batch_date	DATE
)
.DE
.IS \fBbatch_ix\fR 1.0i
The serial identifier of the batch.
.IS \fBbatch_no\fR
The batch number given the batch by the bank.
.IS \fBbatch_date\fR
The date that the batch was submitted.
.Sh "cmemo:  Record a Credit Memo"
.PP
Table
.B cmemo
records a credit memo \(em that is, a set of information about rendering
a credit to a customer.
It is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE cmemo (
	memo_no	SERIAL(10000),	# credit memo number
	memo_date	DATE,	# credit memo date
	invoice_no	INTEGER,	# invoice number
	auth_no	INTEGER,	# return authorization no
	amount	MONEY(8, 2),	# credit amount
	com1	CHAR(50),	# comment
	com2	CHAR(50),
	batch_ix	INTEGER	# credit card entry
	ref_no	INTEGER,
	cap_no	INTEGER,
	tym_flag	SMALLINT
)
.DE
.IS \fBmemo_no\fR 1.0i
The serial number of the credit memo.
.IS \fBmemo_date\fR
The date the memo was rendered.
.IS \fBinvoice_no\fR
The number of the invoice for which this credit memo is being rendered.
It links to field
.B invoice_no
in table
.BR invoice .
.IS \fBauth_no\fR
The return-authorization number.
It links to field
.B auth_no
in table
.BR auth .
.IS \fBamount\fR
The amount of the credit.
.IS \fBcom1\fR
.IS \fBcom2\fR
Comment on the credit memo.
.IS \fBbatch_ix\fR
The batch in which the credit-card order was rendered, if applicable.
It links to field
.B batch_ix
in table
.BR batch .
.IS \fBref_no\fR
.IS \fBcap_no\fR
.IS \fBtym_flag\fR
Help identify the credit-card order.
.B tym_flag
holds the result of a query to
.BR tymnet ;
its codes have the same meaning as defined above
for field
.B tym_flag
in table
.BR invoice .
.Sh "auth:  Record a Return Authorization"
.PP
Table
.B auth
records that authorization has been granted for returning a product.
It is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE auth (
	auth_no	SERIAL(2000),
	auth_date	DATE,
	return_date	DATE,
	invoice_no	INTEGER,
	contact	CHAR(38),
	reason	SMALLINT,
	other_reason	CHAR(38)
)
.DE
.IS \fBauth_no\fR 1.0i
The serial identifier for this authorization.
.IS \fBauth_date\fR
The date authorization was rendered.
.IS \fBreturn_date\fR
The date the product was returned.
.IS \fBinvoice_no\fR
The invoice through which this product was purchased.
Links to field
.B invoice_no
in table
.BR invoice .
.IS \fBcontact\fR
The person who is returning the product.
It should match field
.B contact
in table
.B customer
for the customer who made the purchase in the first place.
.IS \fBreason\fR
.IS \fBother_reason\fR
Record why the user is returning the product.
The former gives a code from a standard set of reasons for return;
and the latter gives any reason that lies
outside our standard set of reasons for return.
.Sh "payments:  Record Payment for Product"
.PP
Table
.B payments
records how a person pays for an order
It is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE payment (
	pay_no	SERIAL(10000),	# payment number
	pay_date	DATE,	# payment date
	invoice_no	INTEGER,	# invoice number
	amount	MONEY(8, 2),	# payment amount
	com1	CHAR(50)	# comment
)
.DE
.IS \fBpay_no\fR 1.0i
The serial number of this payment.
.IS \fBpay_date\fR
The date of payment.
.IS \fBinvoice_no\fR
The invoice for which payment is being rendered.
It links to field
.B invoice_no
in table
.BR invoice .
.IS \fBamount\fR
The amount of the payment.
.IS \fBcom1\fR
Comment on this payment.
.Sh "regcard:  Old Registration Cards"
.PP
Table
.B regcard
holds information transcribed from the old registration cards.
Information from the current registration cards is kept in table
.BR newreg ,
which is described below.
.PP
.B regcard
is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE regcard (
	ser_no	INTEGER,	# fancy permuted SERIAL no
	cust_no	INTEGER,
	reg_date	DATE,
	comp_type	CHAR(38),
	disk_size	SMALLINT,	# disk size in meg
			# mag checklist
	byte	CHAR(1),
	c_gazette	CHAR(1),
	cug	CHAR(1),
	circ_cel	CHAR(1),
	comm_acm	CHAR(1),
	comp_shop	CHAR(1),
	comp_lang	CHAR(1),
	comp_world	CHAR(1),
	dr_dobbs	CHAR(1),
	unix_rev	CHAR(1),
	unix_today	CHAR(1),
	unix_world	CHAR(1),
	ee_times	CHAR(1),
	embed_sys	CHAR(1),
	ieee_spec	CHAR(1),
	info_world	CHAR(1),
	pc_comp	CHAR(1),
	personal_comp	CHAR(1),
	personal_wk	CHAR(1),
	prog_journal	CHAR(1),
	sys_integrat	CHAR(1),
	pc_mag	CHAR(1),
	pc_week	CHAR(1),
	pc_world	CHAR(1),
	exp_level	CHAR(1),
	personal_use	CHAR(1),
	business_use	CHAR(1),
	education	CHAR(1)
)
.DE
Field
.B cust_no
identifies the customer.
It links to field
.B cust_no
in table
.BR customer .
For information on the other fields, see an example of the card in question.
.Sh "newreg:  New Registration Cards"
.PP
Table
.B newreg
holds information transcribed from the registration cards
now included with \*(CO.
It is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE newreg (
	ser_no	INTEGER,	# fancy permuted SERIAL no
	cust_no	INTEGER,
	reg_date	DATE,
	comp_type	CHAR(38),
	disk_size	SMALLINT,	# disk size in meg
	develop	CHAR(1),	# How do you plan to use Coherent
	learn	CHAR(1),
	other	CHAR(1),
	communication	CHAR(1),
	business	CHAR(1),
	software_exp	SMALLINT,	# 1 < 250, 2 < 500, 3 < 1000,
			# 4 < 3000, 5 < 5000, 6 > 5000
	exp_level	CHAR(1),
	personal_use	CHAR(1),
	business_use	CHAR(1),
	education	CHAR(1),
	c_comp	CHAR(1),
	turbo_c	CHAR(1),
	microsoft_c	CHAR(1),
	other_c	CHAR(1),
	macintosh	CHAR(1),
	windows	CHAR(1),
	workstations	CHAR(1),
	sun	CHAR(1),
	ibm	CHAR(1),
	dec	CHAR(1),
	hewlett_packard	CHAR(1),
	operating_sys	CHAR(1),
	unix_v	CHAR(1),
	ultrix	CHAR(1),
	xenix	CHAR(1),
	aix	CHAR(1),
	sunos	CHAR(1),
	hpux	CHAR(1),
	esix	CHAR(1),
	other_os	CHAR(10)
)
.DE
Field
.B cust_no
identifies the customer.
It links to field
.B cust_no
in table
.BR customer .
For information on the other fields, see an example of the card in question.
.Sh "shipreg:  Register a Shipment"
.PP
This table registers a shipment.
This helps support personnel to answer the question, ``Where's my \*(CO?''
It is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE shipreg (
	cust_no	INTEGER,
	ser_no	INTEGER,
	trace_no	DECIMAL(11,0)
)
.DE
.IS \fBcust_no\fR 1.0i
The serial number of the customer.
It links to field
.B cust_no
in table
.BR customer .
.IS \fBser_no\fR
The serial number of the copy of \*(CO being shipped.
.IS \fBtrace_no\fR
The number of the trace that the shipper has put on the shipment.
.Sh "bad_disk:  A Product With a Bad Disk"
.PP
Table
.B bad_disk
records when a customer received a bad disk, and we had to reship product.
It is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE bad_disk (
	baddisk_no	SERIAL,
	ser_no	INTEGER,	# serial number of product
	cust_no	INTEGER,	# number of customer 
	call_d	DATE,	# call date
	med_type	CHAR(1),	# b = bad r = replacement
	cmnt	CHAR(28),	# comments
	reply	DATE,	# reply date
	ship_no	SMALLINT,	# number of shipper
	prod_no	SMALLINT,	# product number
	disk	CHAR(13),	# bad disk number(s)
	head	SMALLINT,
	cylinder	SMALLINT,
	badfile	CHAR(24),	# bad file(s)
	controller	CHAR(38),
	i_msgs	CHAR(38)	# installation message
)
.DE
.IS \fBbaddisk_no\fR 1.0i
The number of the bad disk in the package.
.IS \fBser_no\fR
The serial number of the product.
.IS \fBcust_no\fR
The serial identifier of the customer.
It linkes to field
.B cust_no
in table
.BR customer .
.IS \fBcall_d\fR
The date that the customer called to complain of the bad disk.
.IS \fBmed_type\fR
The type of medium:
.B b
indicates bad,
.B r
indicates replacement.
.IS \fBcmnt\fR
Comments.
.IS \fBreply\fR
The date of our reply to the customer.
.IS \fBship_no\fR
The number of the shipper.
.IS \fBprod_no\fR
The number of product.
It links to field
.B prod_no
in table
.BR product .
.IS \fBdisk\fR
.IS \fBhead\fR
.IS \fBcylinder\fR
Respectively, the number, the head, and the cylinder of the bad disk.
.IS \fBbadfile\fR
gives the name of the file that is bad, should a file be involved.
.IS \fBcontroller\fR
The controller.
.IS \fBi_msgs\fR
The message that the installation program displayed to indicate that
a disk was bad.
.Sh "call_tag:  Record a Call Tag"
.PP
Table
.B call_tag
records an inquiry to UPS to find what happened to a shipment.
It is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE call_tag (
	tag_no	INTEGER,
	invoice_no	INTEGER,
	why	CHAR(70),
	action	CHAR(70),
	issue_date	DATE,
	rec_date	DATE
)
.DE
.IS \fBtag_no\fR 1.0i
The tag number of the shipment.
.IS \fBinvoice_no\fR
The serial identifier of the invoice.
It links to field
.B invoice_no
in table
.BR invoice .
.IS \fBwhy\fR
Why the inquiry was made.
.IS \fBaction\fR
The action taken to resolve this problem.
.IS \fBissue_date\fR
The date this this inquiry was issued.
.IS \fBrec_date\fR
The date a reply was received.
.Sh "w_z_p:  Link Weight and Zone to Price"
.PP
The static table
.B w_z_p
links a weight and a zone to a price of shipment.
It is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE w_z_p(
	weight	SMALLINT,
	zone	SMALLINT,
	price	MONEY(5,2),
	commer	SMALLINT
)
.DE
.IS \fBweight\fR 1.0i
A weight, in pounds.
.IS \fBzone\fR
The zone to which the product is being shipped.
It is linked to field
.B zone
in table
.BR ground .
.IS \fBprice\fR
The price of shipping a given weight to a given zone.
.\" Field commer?
.Sh "pickup_line:  Table for UPS Reports"
.PP
Table
.B pickup_line
is populated when reports are generated on UPS shipments.
It is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE pickup_line (
	invoice_no	INTEGER,
	contact	CHAR(14),
	address	CHAR(18),
	city	CHAR(8),
	state	CHAR(3),
	country	CHAR(4),
	zipcode	CHAR(7),
	commer	SMALLINT,
	weight	SMALLINT,
	zone	SMALLINT,
	charge	MONEY(8, 2),
	dec_value	MONEY(8, 2),
	cod_amt	MONEY(8, 2),
	cod_chrg	MONEY(8, 2),
	aod	CHAR(1),
	cll	CHAR(1),
	pack_no	SMALLINT,
	closed	CHAR(1),
	cl_date	DATE,
	ship_loc	SMALLINT
)
.DE
Its fields are all derived from other tables.
.Sh "ground:  Define UPS Zones"
.PP
Table
.B ground
defines the zones used by UPS to charge for shipment by ground.
It is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE ground(
	from_zip	SMALLINT,
	to_zip	SMALLINT,
	zone	SMALLINT
)
.DE
.IS \fBzone\fR 1.0i
The number of the zone.
.IS \fBfrom_zip\fR
.IS \fBto_zip\fR
The range of ZIP codes that comprise this zone.
If a ZIP code does not appear between any two
.B from_zip
and
.B to_zip
fields in this table, then it is not available via UPS ground service.
For example, rural Alaska does not have UPS ground service available.
.Sh "RecNumber:  A Dead Table"
.PP
Table
.B Rec_Number
is a dead table, and serves no practical use.
It remains in the data base solely because some code references it,
and the code must modified and recompiled before the table can be
dropped safely.
.Sh "workf:  A Temporary Table"
.PP
Table
.B workf
is a temporary table that is created by module
.B mailc.4gl
and used by module
.BR bigmail.4gl .
It is defined as follows:
.DM
.ta 0.5i 1.5i 3.0i
CREATE TABLE workf (
	cust_no	INTEGER,
	tbl	SMALLINT,	# the mailing classification
	addons	SMALLINT	# the number of addon products
			# purchased (the definition shifts)
)
.DE
For details on what the fields in this table represent, see the code
for the above-mentioned modules.
.SH "Data-Base Software"
.PP
The software that populates and maintains the data base is written in
Informix 4GL, with a few subroutines written in C.
The sources are kept in directory
.BR SOURCEDIR .
.PP
The software consists of three classes of modules:
.I screens
(which reside in files that have the suffix \fB.per\fR),
.I 4GL
modules (which reside in files that have the suffix \fB.4gl\fR),
and C programs.
The screens are compiled by the Informix package;
compiled screens have the suffix
.BR \&.frm .
.PP
The Informix package contains the command
.BR c4gl ,
compiles 4GL into C, which is then compiled with the SCO C compiler.
C programs can be compiled either
The entire process of compilation is managed by \fBcc\fR or \fBc4gl\fR;
you should use the latter if the C program contains any code to interact
with 4GL modules.
.Sh "4GL Modules"
.PP
The following describes each module of 4GL code.
No module manipulates more than one table.
Note that many modules are self-contained executable programs.
.IP \fBaddline.4gl\fR 1.0i
Create the city, state, country, and ZIP code portion of a printed address.
.IP \fBaddress.4gl\fR
Add addresses to and retrieving addresses from the data base.
.IP \fBall.4gl\fR
This is the master module.
It includes the
.B MAIN
function and calls the main menu.
All other modules are subordinate to this.
.IP \fBauth.4gl\fR
Present the menu for return authorization.
.IP \fBbad_disk.4gl\fR
Capture information on bad disks.
.IP \fBbad_report.4gl\fR
Generate reports on bad media.
.IP \fBbad_table.4gl\fR
Create the table
.BR bad_disk .
.IP \fBbase.4gl\fR
Create the program with which the user can update tables
.BR product ,
.BR shippers ,
and
.BR magazines .
.IP \fBbigmail.4gl\fR
Generate a program for creating mailing lists.
.IP \fBccreps.4gl\fR
Create a program that generates reports on invoices.
.IP \fBcount_rows.4gl\fR
Create a program that counts the number of rows in each table in the data base.
.IP \fBcredit.4gl\fR
Create the program that generates credit memos.
.IP \fBcruncher.4gl\fR
Create a program that ``crunches'' customer names
into a form more easily searched.
Works with
.BR crunch.c .
.IP \fBdbase.4gl\fR
Drop and re-generate the
data base.
.IP \fBdest.4gl\fR
Manipulate the table
.BR dest ,
including searching for a destination.
.IP \fBdrop_rows.4gl\fR
Generate a test data base.
It copies the
.B mwc
data base into another directory, then selectively drops rows
from the test data base to make it smaller.
.IP \fBdupfind.4gl\fR
Create a program to find duplicate customers in the data base.
.IP \fBdupl_cust.4gl\fR
Create another program to find duplicate customers.
It can also remove the duplicate, should the user wish, and relinks
the data (addresses and invoices) linked to the duplicate customers to the
``true'' customer.
.IP \fBfreight.4gl\fR
Display the menu for handling freight.
It also generates the freight report.
.IP \fBglobals0.4gl\fR
Declare the global variables used in the main
.B mwc
program.
.IP \fBmag.4gl\fR
Manipulate the table
.BR magazines .
.IP \fBmailc.4gl\fR
Create a program that counts how many customer fit a given customer profile.
It is used to compute how many mailers should be printed for a given mailing.
.IP \fBmailer.4gl\fR
Generate mailing lists.
.IP \fBmainline.4gl\fR
Manipulate the table
.BR invoice .
With it, you can add, modify, and delete entries into this table,
and generate reports.
.IP \fBmism.4gl\fR
Create a program to print reports of selected errors and
inconsistencies in the data base.
.IP \fBnewreg.4gl\fR
Create a program for transcribing the ``new'' registration
cards into the data base.
These are the registration cards that are now sent out with MWC products.
.IP \fBpayment.4gl\fR
Enter information about a payment.
.IP \fBprod.4gl\fR
Manipulate the table
.BR products .
With it, you can add a product, delete a product, find a product,
``free'' the invoices of back-ordered products, among other tasks.
.IP \fBqcount.4gl\fR
Create a report to count the number of each product that we sold today.
.IP \fBqlist.4gl\fR
Create a report that returns a sample of the users who received no upgrade.
.IP \fBregcard.4gl\fR
Let the user transcribe an ``old'' registration card into
the data base, and perform other useful tasks (e.g., generate reports).
.IP \fBreindex.4gl\fR
Create all indexes for the data base.
.IP \fBreports.4gl\fR
Create a program that prints reports on invoices.
.IP \fBrepx.4gl\fR
Generate a program that prints one-time, or unusual reports.
.IP \fBship.4gl\fR
Let the user manipulate the table
.B shippers .
It also prints a report of our activity with each shipper.
.IP \fBshipdate.4gl\fR
Set the shipping date.
.IP \fBstate.4gl\fR
Create a program to maintain table
.BR states .
.IP \fBtech.4gl\fR
Give sources for the
.B tech
system, which
manages the table
.BR tech_fup .
.IP \fBterm.4gl\fR
Maintain table
.BR terms .
.IP \fBtnet.4gl\fR
Create a program that calls
.B tymnet
and generates invoices.
.IP \fBups_add.4gl\fR
Add a new entry to a UPS report.
.IP \fBups_charge.4gl\fR
Insert data into the table
.BR w_p_z ,
which correlates weight plus UPS zone with UPS charge.
.IP \fBups_cor.4gl\fR
Manipulate table
.BR pickup_line .
.IP \fBups_func.4gl\fR
Find the parameters for UPS shipping.
.IP \fBups_grzone.4gl\fR
Manipulate table
.BR ground .
.IP \fBups_main.4gl\fR
This is the main module for the UPS sub-system.
.IP \fBups_report.4gl\fR
Generate the main UPS report.
.IP \fBups_table.4gl\fR
Create the tables with data base
.B mwc
that handle UPS information.
.IP \fBups_tag.4gl\fR
Generate UPS tags.
.IP \fBwand.4gl\fR
Let the user wand in various values off of tags and forms.
.IP \fBwork.4gl\fR
Generate the test
.B mwc
system.
.Sh "C Modules"
.PP
The following described the C programs that help support the data base
.BR mwc .
.IP \fBPrintLine.c\fR 1.0i
Print a line of text on the HP LaserJet.
.IP \fBbacct.c\fR
Generate a \fB.bat\fR file to interrogate Owen's Cougar Mountain
accounting system.
.IP \fBc10.c\fR
Print a file in ten-point Courier font on the HP LaserJet,
then reset the printer to its default settings.
.IP \fBcform.c\fR
Print a file of credit memos.
.IP \fBcheckno.c\fR
Search a comment in the data base to find a check number.
.IP \fBchesh.c\fR
Print mailing labels on a Decwriter.
.IP \fBcomform.c\fR
Format Informix output for printing commercial invoices.
.IP \fBconnect.c\fR
Telephone
.BR tymnet ,
upload a set of credit memos, and record
.BR tymnet 's
response to each request for credit.
.IP \fBcrib.c\fR
Build a ``cribsheet'' from one or more files of source code.
.IP \fBcrunch.c\fR
Implement the Metaphone algorithm, which ``crunches'' a user's
name into a form that is easily sought within the data base.
.IP \fBdupwrite.c\fR
Find and print duplicates within a list.
.IP \fBexp_num.c\fR
Checks whether a clerk has entered a ``legal'' serial number
for a given release of \*(CO.
.IP \fBfileread.c\fR
Permit a 4GL module to read a non-Informix file.
.IP \fBformat.c\fR
Format invoice information extracted from the data base.
.IP \fBforrdb.c\fR
Massage the output of an Informix query into a form that can be loaded into
.BR /rdb .
Used by Jay.
.IP \fBget_usr.c\fR
Return the identity of the user who is running this application.
.IP \fBgetopt.c\fR
Get an option letter from
.BR argv .
.IP \fBmform.c\fR
Drive the printing of labels for mailers.
.IP \fBmv2xy.c\fR
Moves the cursor to a given X,Y point on the screen.
.IP \fBmwlogo.c\fR
Print the MWC logo.
.IP \fBpacct.c\fR
Another version of the C module
.BR bacct.c .
.IP \fBprint_land.c\fR
Reset the HP LaserJet to print in landscape mode.
.IP \fBreplace.c\fR
Replace one string with another.
.IP \fBsales.c\fR
Call
.BR dial.c ,
and drive the process of interacting with
.BR tymnet .
.IP \fBstrstr.c\fR
Implement the function
.BR strstr() .
Obsolete.
.IP \fBtranlog.c\fR
Record information in a transaction log.
.IP \fBtransact.c\fR
Generate a transaction.
.IP \fBtyme.c\fR
Another version of
.BR sales.c .
.IP \fBunblank.c\fR
Drop blank lines from a file of text.
.IP \fBxacct.c\fR
Another program for Owen's accounting package.
.IP \fBxread.c\fR
Another program to help Informix read non-Informix files.
.Sh "Screens"
.PP
The following describes the screens that help manage the
.B mwc
data base.
Note that most screens in this system manipulate one, or at most two,
tables.
This is designed in part for simplicity, and in part to try to avoid
the half-megabyte limit, beyond which Interactive Informix jumps the rails.
For that reason, too, no module uses pop-up windows or complex screen displays.
.IP \fBPickLine.per\fR 1.0i
This screen lets the user invoke UPS reports.
It is opened in module
.BR ups_main.4gl .
.IP \fBauth.per\fR
This screen lets the user enter a return authorization.
It is opened in module
.BR auth.4gl .
.IP \fBbad_disk.per\fR
This form lets the user enter information about a bad disk.
It is opened in module
.BR bad_disk.4gl .
.IP \fBcredit.per\fR
This lets the user enter a credit memo.
It is opened in module
.BR credit.4gl .
.IP \fBdupl_cust.per\fR
This form displays duplicate customers for the user.
With it, the user can decide if two customers are in fact duplicates, and
if so, choose which is the more correct.
It is opened in module
.BR dupl_cust.4gl .
.IP \fBground.per\fR
This lets the user look up a UPS-ground zone.
It is opened in module
.BR ups_grzone.4gl .
.IP \fBmag.per\fR
This lets the user look up information about a magazine.
It is opened in module
.BR base.4gl .
.IP \fBmailer.per\fR
This screen lets the user look up information about a mailer.
It is opened in module
.BR all.4gl .
.IP \fBmainline.per\fR
This lets the user enter information about an invoice.
It is opened in module
.BR ccrep.4gl .
.IP \fBnumbers.per\fR
This screen displays the contents of table
.BR recnumber .
It is not opened by any 4GL module.
.IP \fBpay.per\fR
This screen helps the user to record a payment.
It is opened in module
.BR payment.4gl .
.IP \fBproduct.per\fR
This screen displays the contents of table
.BR product .
It is opened in module
.BR base.4gl .
.IP \fBregcard.per\fR
This screen lets the user transcribe an ``old'' registration card.
It is opened in module
.BR all.4gl .
.IP \fBshipdate.per\fR
This screen lets the user manipulate the contents of table
.BR invoice .
It is opened in module
.BR all.4gl .
.IP \fBshippers.per\fR
This screen lets the user manipulate the contents of table
.BR shippers .
It is opened in module
.BR base.4gl .
.IP \fBstate.per\fR
This screen displays the contents of table
.BR states .
It is opened in module
.BR base.4gl .
.IP \fBtech.per\fR
This screen displays the contents of table
.BR tech_fup .
It also lets the user add a new customer, or updating an existing customer's
address, telephone number, and E-mail address.
.IP \fBterm.per\fR
This screen displays the contents of table
.BR terms .
It is opened in module
.BR base.4gl .
.IP \fBups_tag.per\fR
This table displays the contents of table
.BR pickup_line .
It is opened in module
.BR ups_tag.4gl .
.IP \fBwand.per\fR
This screen is used when a customer number is linked to a tag number
by wanding the tag.
It manipulates the contents of table
.BR shipreg .
It is opened in module
.BR all.4gl .
.PP
The following chapter walks you through the program.
It indicates what screen and source module is being used at any given
point in the program.
