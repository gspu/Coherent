.ds TL Introduction
.NH Introduction
.PP
This document describes the system used by Mark Williams Company (MWC) to
manage its sales and shipping.
It describes the tasks that are involved in selling and shipping our
products and the steps required to accomplish each task.
It also the computer system with which we manage sales and shipping.
.PP
We need your help to keep this document up to date.
If you notice any errors in it, please mail to user \fBfwb\fR on the
HP the following information:
.IP \fB1.\fR 0.3i
The version of the document in which you found the error.
.IP \fB2.\fR
The page on which error occurs.
.IP \fB3.\fR
What the error is.
.IP \fB4.\fR
What the document should say in place of the error.
.PP
The only thing worse than an undocumented system is one that is documented
incorrectly.
Please correct any errors you find
.IR immediately .
