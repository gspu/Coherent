.ds TL "Front-Office Procedures"
.NH Tasks
.PP
The following describes how to perform specific tasks with the sale and
shipment of a product.
.SH "Create an Invoice"
.PP
Whenever you sell a product to someone, you must create an invoice.
An
.I invoice
is a record of a customer's order.
It links the entity that is making the purchase (either a person or a company)
with the product or products being purchased.
Creating an invoice sets into motion the machinery of assembling a package,
generating a credit-card order, creating shipping orders, and so on.
.PP
Note that the method of entering an invoice is the same whether the
order is received via mail or taken via telephone.
.PP
To enter an invoice, first log into the SCO inventory system, then invoke
the command
.BR inv .
When the main menu appears, select the option
.BR Inv ;
you will then see the Invoice screen, as follows:
.B1
.sp \n(pDu
	INVOICE:   Add   Find   Query   Card   Report   Xtra   Ytra   Exit
.sp \n(pDu
	invoice no   [f000       ] invoice date [f001      ]      ship dt. [f003      ]
	contact      [a001                                  ]     cust no  [a000       ]
	phone no     [a002                                ]       orig inq [f047]
	address type [c]   [f018                                  ]	
	 ser [f043      ]  [f019                                  ]  Club  [a003]
	 id  [f042     ]   [f020                                  ]
	city [f021                ] ST [a0  ] ctry [f023          ]    zip [f022       ]
	terms [f9  ][f009   ] card [f040                ] [f041 ]   rf [f046      ] [d]
	payments [f031       ] credits [f030       ] batch [f045 ]  bounce [a]
	comments [f005                                              ]
	inquiry source [f006] [f038                ]
	prod no   [f024  ] quant [f025  ] price [f026    ] Ext [f027    ] [e]
	prod name [f028                          ][f029                          ]
	prod no   [f024  ] quant [f025  ] price [f026    ] Ext [f027    ] [e]
	prod name [f028                          ][f029                          ]
	ship via [f008  ] [f034           ] amt [f013    ] trc [f044              ] [f]
	subtot [f007     ] disc [f014     ] tax [f017][f015    ] tot [f016     ]
.sp \n(pDu
.B2
.PP
Select
.B Add
from the ring menu.
This moves the cursor into the field labelled
.BR "invoice date" .
.PP
The first task is to enter information about the customer.
If you know the customer's customer number, move the cursor to the field
labelled
.B "cust no"
and type the number in;
note that on a mailer, the customer number is the number that appears next
to his name.
When you type the customer number,
the program looks up the information on this customer and displays it.
Verify that the program has found the right person.
If all of the information is wrong, you probably have not typed the
customer number correctly; verify the number and try to type it again.
If one or two of the fields are wrong (e.g., the customer's address or
telephone number), move the cursor to that field and type the correct
information.
.PP
Note that a customer can have two addresses:
the shipping address, and the billing address.
You must indicate what type of address this is by typing the correct code
into the field labelled
.BR "address type" .
The system recognizes the following codes:
.DS
	\fBb\fR	Billing address
	\fBs\fR	Shipping address
	\fBx\fR	Both
.DE
.PP
Usually, you will type the shipping address.
.PP
Please note:
.I
Do not retype all of the customer's information!
If you do, you probably have obliterated someone else's record!
.R
.PP
If you do not know the customer number, or if the customer is contacting us
for the first time, fill in the information on this customer.
The system records in the data base the information you have typed about the
customer only after you have finished entering information into all of the
fields.
At that point, it generates and displays a customer number.
To abort entering a customer record, press
.BR <del> .
.PP
Next, enter information about how the customer will be paying.
Type the payment code into the field labelled
.BR terms .
The system recognizes the following payment codes:
.DS
	\fB1\fR	amex (American Express)
	\fB2\fR	visa (Visa)
	\fB3\fR	mc (Master Card)
	\fB4\fR	discov (Discover Card)
	\fB5\fR	ppd (Pre-Paid)
	\fB6\fR	n/c (No Charge)
	\fB7\fR	net 10 (?)
	\fB8\fR	net 30 (?)
	\fB9\fR	error 
	\fB10\fR	upon r (Upon Receipt)
	\fB11\fR	cod (Collect on Delivery)
	\fB12\fR	wire t (?)
	\fB13\fR	Hole i (?)
	\fB14\fR	net 60 (?)
.DE
These will change from time to time, so check the list in your cubicle.
When you enter a code, the system looks it up and displays the name of the
method of payment in the next next to where you entered the code.
Check the name and ensure that it is correct.
.PP
If the user is paying via credit card, enter the credit-card
into the field labelled
.BR card ,
and its expiration date (in the form ``MM/YY'') into the field to its right.
.PP
If the user is paying with a check (as often happens with mail orders),
type the appropriate code into the field labelled
.BR terms ;
type the sum of the payment into the field marked
.BR payments ,
and the number of the customer's check into the field marked
.BR comments .
.PP
After you enter the payment information, the cursor jumps to the field labelled
.BR "inquiry source" .
Fill in the number of the inquiry source; the system recognizes the following
source codes:
.sp \n(pDu
.nf
	\fB1\fR	\fIByte\fR
	\fB2\fR	\fIDr Dobbs\fR
	\fB3\fR	\fIInfo World\fR
	\fB4\fR	\fIComputer Language\fR
	\fB5\fR	\fIOpen Systems Today\fR
	\fB6\fR	UUNET
	\fB7\fR	Word of mouth
	\fB8\fR	None
	\fB9\fR	\fIPC Magazine\fR
	\fB10\fR	\fIProgrammers' Journal\fR
	\fB11\fR	Coupon mailer 
	\fB12\fR	Sent Information from MWC
	\fB13\fR	\fIUnix World\fR
	\fB14\fR	\fIComputer Shopper\fR
	\fB15\fR	\fIC Users Journal \fR
	\fB16\fR	\fICircuit Cellar\fR
	\fB17\fR	\fIC Gazette \fR
	\fB18\fR	Evaluation copy 
	\fB19\fR	\fICommunications of the ACM\fR
	\fB20\fR	\fIEXE \fR
	\fB21\fR	\fIUnix Review \fR
	\fB22\fR	\fIMidnight Engineering\fR
	\fB23\fR	\fIRacunari\fR
	\fB24\fR	\fIPC Week \fR
	\fB25\fR	Software Mag. (Neth)
	\fB26\fR	\fITech Specialist \fR
	\fB27\fR	\fITHE Journal \fR
	\fB28\fR	\fIMicroTimes\fR
	\fB29\fR	Update mailing
	\fB30\fR	\fIElectrical Engineering Times \fR
	\fB31\fR	\fIComputer Monthly\fR
	\fB32\fR	\fIFocus on AIX\fR
	\fB33\fR	\fIGovernment Computer News\fR
	\fB34\fR	\fICompute \fR
	\fB35\fR	\fIEDN Electrical Design\fR
	\fB36\fR	\fIComputer World\fR
	\fB37\fR	\fIEmbedded Systems \fR
	\fB38\fR	\fIIEEE Spectrum \fR
	\fB39\fR	\fIPC Computing\fR
	\fB40\fR	\fISystems Integration \fR
	\fB41\fR	\fIPC World\fR
	\fB42\fR	\fIPersonal Computing\fR
	\fB43\fR	\fIPersonal Workstation\fR
	\fB44\fR	\fIPC USER UK\fR
	\fB45\fR	Spring '91 mailing 
	\fB46\fR	Repeat order
	\fB47\fR	Release notes 
	\fB48\fR	\fIElectronic Products \fR
	\fB49\fR	\fIDatamation\fR
	\fB50\fR	\fILan Computing \fR
	\fB51\fR	\fIElectronic News \fR
	\fB52\fR	Software Mag (US) 
	\fB53\fR	\fIRainbow/PCM \fR
	\fB54\fR	\fIElectronics \fR
	\fB55\fR	\fIComputer Tech Review\fR
	\fB56\fR	\fINASA Tech Briefs\fR
	\fB57\fR	\fIPC Sources\fR
	\fB58\fR	\fIComputer Buy'n World\fR
	\fB59\fR	\fIComputer Reseller News\fR
	\fB60\fR	Update 3.2 mailing
	\fB61\fR	\fIByte\fR mailing list
	\fB62\fR	\fIAET \fR
	\fB63\fR	Registration card 
	\fB64\fR	\fB/rdb\fR mailing
	\fB65\fR	\fIEducational Info \fR
	\fB66\fR	\fISNI \fR
	\fB67\fR	4.0 update mailer 
	\fB68\fR	VAR Program 
	\fB69\fR	Phone Persuasion
	\fB70\fR	\fISCO Magazine\fR
	\fB71\fR	Acucobol A/C 11 
	\fB72\fR	Acucobol A/C 22 
	\fB73\fR	\fIUNIX International\fR
	\fB74\fR	Accucobol
	\fB76\fR	Telemarketing 
	\fB77\fR	Mailing-Feb/March '93
	\fB75\fR	\fIUnix Review \fR
.PP
As you can see, some of the above are redundant.
Please note that these codes do change from time to time, so consult the
sheet that is in your cubicle.
.PP
When you enter a code, the system looks it up and displays the code's meaning
in the field to the right of where you typed the code.
If what the system retrieves is incorrect, try again.
.PP
After you have entered the inquiry source, you can enter information about
products.
Fill in the number of the product the user is ordering; the system recognizes
the following codes:
.sp \n(pDu
.nf
	\fB5\fR	Mark Williams C For the Atari ST, release 3.0.9
	\fB6\fR	Mark Williams C For the Atari ST Update, 3.0.6
	\fB7\fR	No product shipped
	\fB8\fR	Let's C
	\fB10\fR	CSD for the Atari ST
	\fB16\fR	\*(CO Manual
	\fB17\fR	Manual
	\fB27\fR	\*(CO 3.1.0, 3.5-inch disks
	\fB31\fR	\*(CO 3.1.0, 5.25-inch disks only
	\fB32\fR	\*(CO 3.1.0, 3.5-inch disks only
	\fB33\fR	Update to \*(CO 3.1.0, 5.25-inch disks only
	\fB34\fR	Update to \*(CO 3.1.0, 3.5-inch disks only
	\fB35\fR	Driver Kit, 5.25-inch disks only
	\fB36\fR	Driver Kit, 3.5-inch disks only
	\fB37\fR	Update to \*(CO 3.1.0, 5.25-inch disks
	\fB38\fR	Update to \*(CO 3.1.0, 3.5-inch disks
	\fB39\fR	COHware Volume I, 5.25-inch disks
	\fB40\fR	COHware Volume I, 3.5-inch disks
	\fB42\fR	Text Book Manual (old manual)
	\fB44\fR	\*(CO 3.2.1, 5.25-inch disks
	\fB45\fR	\*(CO 3.2.1, 3.5-inch disks
	\fB46\fR	\*(CO 3.2.1, 5.25-inch disks only
	\fB47\fR	\*(CO 3.2.1, 3.5-inch disks only
	\fB50\fR	Device Driver Kit, release 1.2, 5.25-inch disks
	\fB51\fR	Device Driver Kit, release 1.2, 5.25-inch disks
	\fB52\fR	COHware Volume II, 5.25-inch disks
	\fB53\fR	COHware Volume II, 3.5-inch disks
	\fB54\fR	Update to \*(CO 3.2, 5.25-inch disks only
	\fB55\fR	Update to \*(CO 3.2, 3.5-inch disks only
	\fB56\fR	Update to \*(CO 3.2, 5.25-inch disks
	\fB57\fR	Update to \*(CO 3.2, 3.5-inch disks
	\fB58\fR	/rdb Relational Database, 5.25-inch disks
	\fB59\fR	/rdb Relational Database, 3.5-inch disks
	\fB60\fR	\*(CO 4.0, 5.25-inch disks
	\fB61\fR	\*(CO 4.0, 3.5-inch disks
	\fB62\fR	Update to \*(CO 4.0.0, 5.25-inch disks
	\fB63\fR	Update to \*(CO 4.0.0, 5.25-inch disks
	\fB64\fR	\*(CO 4.0, 5.25-inch disks only
	\fB65\fR	\*(CO 4.0, 3.5-inch disks only
	\fB66\fR	Device Driver Kit 2.0, 5.25-inch disks
	\fB67\fR	Device Driver Kit 2.0, 5.25-inch disks
	\fB68\fR	GNU C, 5.25-inch disks
	\fB69\fR	GNU C, 3.5-inch disks
	\fB70\fR	GNU Tools, 5.25-inch disks
	\fB71\fR	GNU Tools, 3.5-inch disks
	\fB72\fR	COHware Volume III, 5.25-inch disks
	\fB73\fR	COHware Volume III, 3.5-inch disks
	\fB74\fR	ACUCOBOL Dev/\*(CO 4.0, 5.25-inch disks A/C 11
	\fB75\fR	ACUCOBOL Dev/\*(CO 4.0, 3.5-inch disks A/C 11
	\fB76\fR	ACUCOBOL Runtime/\*(CO 4.0, 5.25-inch disks A/C 11
	\fB77\fR	ACUCOBOL Runtime/\*(CO 4.0, 3.5-inch disks A/C 11
	\fB78\fR	ACUCOBOL Dev/\*(CO 4.0, 5.25-inch disks A/C 22
	\fB79\fR	ACUCOBOL Dev/\*(CO 4.0, 3.5-inch disks A/C 22
	\fB80\fR	ACUCOBOL Runtime/\*(CO 4.0, 5.25-inch disks A/C 22
	\fB81\fR	ACUCOBOL Runtime/\*(CO 4.0, 3.5-inch disks A/C 22
	\fB83\fR	XTree, 5.25-inch disks
	\fB84\fR	XTree, 3.5-inch disks
	\fB85\fR	GNU C Sources, 5.25-inch disks
	\fB86\fR	GNU C Sources, 3.5-inch disks
	\fB87\fR	COHware Volume IV, 5.25-inch disks
	\fB88\fR	COHware Volume IV, 3.5-inch disks
	\fB89\fR	Cohware Volume V, 5.25-inch disks
	\fB90\fR	Cohware Volume V, 3.5-inch disks
	\fB91\fR	GNU C, 5.25-inch disks
	\fB92\fR	GNU C, 3.5-inch disks
.PP
Note that product codes differ not only on the name of the product, but its
release and the size of the disk required by the user.
The above list contains some redundancies; be aware of them.
The above list also corrects some misspellings and inconsistencies that
exist in the data base.
The product list does change from time to time; consult the list
in your cubicle.
.PP
When you type a product code, the system looks up that code and displays the
name of the product in the field labelled
.BR "prod name" .
Confirm that this is the correct product, the correct release, and
the correct size of disk; if it is not, retype the product code.
.PP
After you have entered the product code, enter the quantity.
The system looks up the price of the product and displays the subtotal for you.
.PP
Repeat this for each product that the customer wants.
After you have finished entering information about products, type
.BR <Esc> .
This indicates that you have finished entering products into this invoice.
.PP
After you have typed information about the products (and typed
.B <Esc>
to confirm that the order is correct),
enter information about shipping.
Type the code for the shipper into the field labelled
.BR "ship via" .
The system recognizes the following codes:
.PP
.nf
	\fB1\fR	UPS Ground
	\fB2\fR	UPS Blue
	\fB3\fR	UPS Red
	\fB4\fR	US Airmail
	\fB5\fR	FEDEX
	\fB6\fR	Pick-up
	\fB7\fR	US Express Mail
	\fB8\fR	DHL
	\fB9\fR	M.S.A.S.
	\fB10\fR	Emery
	\fB11\fR	Team Air
	\fB12\fR	UPS Ground Res
	\fB13\fR	Transportation
	\fB14\fR	Collect
	\fB15\fR	Airborne Express
	\fB16\fR	Kuehne & Nagel
	\fB17\fR	C&F
	\fB18\fR	Purolator
	\fB19\fR	Intertrans Corp.
	\fB20\fR	Admiral
	\fB21\fR	Hellmann
	\fB22\fR	Tokyu Air Cargo
.PP
When you enter a code, the system looks up the name of the shipper and
displays it in the field to the right of where you typed the code.
Check that name to confirm that you have selected the correct shipper.
.PP
When you select a shipper, the system calculates the cost of the shipment,
based on what the user has ordered, the zone in which the user lives, and the
rates charged by the particular shipper; and it displays the result of its
computation in the field labelled
.BR amt .
Usually, the system's charges are correct; confirm that they are so,
and correct them if they are not.
.PP
The system computes the subtotal.
If the customer is entitled to a discount, type it into the field labelled
.BR disc .
If the customer lives in Illinois, the system computes
the amount of sales tax he owes, and displays it in the field labelled
.BR tax .
.PP
When you have finished entering the invoice, press
.B <Enter>
until you pass the end of the form.
The system will return the cursor to the top of the screen, and await your
next instruction.
When you have finished entering the sales information,
the system prints a summary of the sale on the sales-log printer,
by the front desk.
.PP
Finally, fill out a paper invoice form.
This must include the number of the invoice, as returned by the system, plus
information about the customer and the order.
Leave it in the appropriate place, so it can be picked up later.
.SH "Processing Invoices"
.PP
Invoices are processed in batch.
To run a batch of invoices, you must perform the following tasks:
.IP \fB1.\fR 0.3i
Gather the paper invoice order forms; organize them.
.IP \fB2.\fR
Run an invoice report.
This report communicates with
.B tymnet
to confirm all credit-card orders, and prints a summary report of the
orders in this batch.
(This is done only when taking a product off back order.)
.IP \fB3.\fR
Print and separate individual packing sheets.
.IP \fB4.\fR
Process orders that fail credit-card checking.
.IP \fB5.\fR
Assemble and package the products.
.IP \fB6.\fR
Link a product number to an invoice number.
.PP
The following sub-sections describe each step in detail.
.Sh "Gather the Orders"
.PP
Each sales person fills out a paper invoice form for each invoice that he takes.
Gather the forms from each sales person's cubicle, plus those entered in the
front office (the ones that were transcribed from mail orders).
Sort them into numerical order, by their invoice number.
.Sh "Run the Invoice Report"
.PP
The invoice report actually processes the invoices.
Processing the invoices means contacting
.B tymnet
and checking whether a credit-card order is correct;
and printing an invoice sheet for each order.
.PP
To run the report, do the following:
.IP \fB1.\fR 0.3i
Log into the SCO machine, and type the command
.B inv
to invoke the invoice program.
.IP \fB2.\fR
From the main menu, select
.BR Inv .
.IP \fB3.\fR
When the invoice screen (shown above) appears, type
.BR Ytra ,
for ``yet more reports'', from the ring menu.
.IP \fB4.\fR
From the Ytra ring menu, select
.BR Inv ,
which runs the batch invoice program.
.IP \fB5.\fR
In the field labelled
.BR "invoice no" ,
type first invoice number of the batch you have collected, then a colon `:',
then the last invoice number in the batch.
The system will then process all invoices that lie between the two
extremes you have entered.
For example, if the batch you have collected consists of invoices
1234 through 1249, type the following into field
.BR "invoice no" :
.DM
	1234:1249
.DE
This report automatically telephones
.BR tynmet ,
passes it the appropriate information about credit-card orders, and
records what
.BR tymnet 's
response is to each credit-card order.
If an invoice contains a product that is back-ordered, the system sits on that
invoice until the back-ordered product appears.
This report takes a while to run; please be patient.
.Sh "Print and Separate Packing Sheets"
.PP
When a batch has been processed to completion, the system prints
one invoice sheet for each invoice.
Set it aside for the fulfillment person to process.
.PP
A bar-coded user-registration card comes attached to the package from the
reproduction service.
Inside the package is a user-reaction report that has an identical bar code
on it.
.Sh "Process Failed Orders"
.PP
The packing sheet indicates whether a credit-card order was accepted or
rejected; and if rejected, gives the reason.
If a credit-card order is rejected, the order is processed further, as follows:
.IP \(bu 0.3i
Attempt to run the order again manually using the ZON machine.
.IP \(bu
If the ZON machine fails, contact the customer and explain the situation.
It may be that the credit-card number was transcribed incorrectly, or the
customer may choose to use a different credit card.
In either case, process the charge again by hand.
.IP \(bu
Continue to try the ZON machine either until the order succeeds, or the
customer explicitly tells us to drop the order.
.IP \(bu
When hand processing succeeds, staple the printed printout from the ZON
machine to the order.
Then, enter the Invoice screen (shown above) and use the option
.B Find
to find invoice; this option finds invoices through their invoice numbers.
When you have located the invoice, hit the \fB<Enter>\fRkey
until the cursor is in the field labelled
.BR batch ,
then type the batch number as shown on the ZON machine's printout.
This is necessary to balance the system.
If the credit-card information for this customer has changed,
then move the cursor to the fields labelled
.B ST
and
.BR card ,
and retype the credit-card information.
.Sh "Package the Orders"
.PP
When an order has cleared credit check, its invoice sheet is guillotined
into two parts.
The top half is the packing list; it is included with the product that is
sent to the customer.
The bottom half is used to prepare the package.
Beginning in October 1994, this sheet was redesigned so the split always
appears at the same point on the sheet, so they can be chopped in batches.
The packing to use depends on how the package is being shipped, and the
variety and number of products being shipped.
If the package is being shipped by any means other than UPS, tape it to the
package.
.Sh "Record the Product and Shipping Information"
.PP
The next step is to record every product that we ship.
This is done through the
.B Wand
screen of the invoice program.
.PP
First, log into the SCO machine, and type the command
.B inv
to invoke the invoice program.
When the main menu appears, select the command
.BR Wnd .
The program displays the following screen:
.B1
.sp \n(pDu
	WAND:  Add  Find  Delete  Exit
.sp \n(pDu
			Wand Screen
.sp \n(pDu
	Customer Number: [           ]
	Invoice Number:  [           ] 
	Trace Number:    [                  ]
	Shipping Date:   [          ]
	Serial Number:   [           ]
.sp \n(pDu
.B2
.PP
The option you select depends on what you must do to fulfill the
customer's order, as follows:
.IP \(bu 0.3i
To begin processing an order, select
.B Add
from the ring menu.
When the cursor enters the field labelled
``Customer Number'',
wand the bar code on the top of the invoice sheet.
If the bar code is marred and you must enter the customer number by hand,
you must enter press the
.B <return>
key twice to exit this field.
.IP \(bu
The cursor jumps to the field labelled ``Invoice Number''.
Wand the bar code that at the bottom of the invoice sheet, which
gives the invoice number.
If the bar code is marred and you must enter the customer number by hand,
you must enter press the
.B <return>
key twice to exit this field.
.IP \(bu
The cursor jumps to the field labelled ``Trace Number''.
If the shipment is being traced
(i.e., the package is being shipped UPS Red or UPS Blue),
wand the trace number from the shipping label.
Again, if you must enter this number by hand \(em or if you are skipping
this field \(em press
.B <return>
twice.
.IP \(bu
When you exit the ``Trace Number'' field,
the system generates the UPS record for this shipment.
You may experience a slight delay before the cursor jumps into the next
field; please be patient.
.IP \(bu
When cursor enters the ``Shipping Date'' field, it is initialized by default
to today's date.
To move the date to one day in the past, press
.B <ctrl-Y>
(for ``yesterday'').
To move the date one day in the future, press
.B <ctrl-T>
(for ``tomorrow'').
Note that you must press
.B <return>
only once to exit this field.
.IP \(bu
When the cursor enters the field labelled ``Serial Number'', wand the
serial numbers from the \*(CO registration cards for each of the
\*(CO packages that you are shipping.
If you must type a number by hand, press
.B <return>
twice.
To stop entering serial number, leave this field blank and press
.B <return>
twice.
.PP
To find a shipping record, press
.B Find
on the ring menu, and enter the appropriate information.
.PP
To delete a shipping record, press
.B Delete
on the ring menu, and again enter the appropriate information.
The system will ask you to confirm that you wish to delete this record
before it executes this instruction.
.PP
To return to the main menu, select
.B Exit
from the main menu.
.SH "Run the UPS Program"
.PP
The UPS program generates reports for use by UPS, and records the date that
a product was shipped.
It is important to record the date, because it is impossible to trace products
via UPS unless we know exactly what date we shipped the product.
.PP
In previous version of this program,
the fulfillment person had to enter information into this program by hand;
Beginning in October 1994, this step is no longer needed, because
the information it needs is entered by the
.B Wand
program.
However, the following describes the UPS program, which can be used to
look up and modify shipments.
.PP
To run the UPS program, log into the SCO machine, then type the command
.B inv
to invoke the invoice program.
When the main menu appears, select
.BR UPS ;
then from the main UPS menu, select
.BR "UPS Report" .
The program clears the screen, and asks you to identify the site that you
are at.
Always enter `0' \(em for Mark Williams Company.
.PP
After you identify yourself, the program displays the following screen:
.B1
.sp \n(pDu
	Add    Today   Report UPS    Last    Close    Exit
.sp \n(pDu
				UPS REPORT DATABASE
.sp \n(pDu
	invoice_no [           ]
	contact    [              ]
	address    [                  ]	    commercial [  ]
.sp \n(pDu
	city       [        ]       ST [   ]     cntry [    ]      zip [       ]
.sp \n(pDu
	weight     [      ]       zone     [      ]       charge   [           ]
	dec_value  [           ]  cod_amt  [           ]  cod_chrg [           ]
	aod        [ ]            Call tag [ ]
.sp \n(pDu
	tag number [           ]
	why        [                                                           ]
	action     [    			                               ]
	issue date [          ]             recieve date [          ]
.sp \n(pDu
.B2
.PP
Invoke the command
.B Add
from the ring menu, then wand the bar code that is on the packing sheet
(the bottom half, which you used to prepare the package).
The system look up the invoice, and displays the name and address of the
person to whom it is being shipped.
The system asks if what you've entered is correct.
Check it over quickly; if it is correct, type
.BR y .
If it's wrong, type
.B n
and then retype the information.
Do this once for each product that is being shipped via UPS.
.PP
When you have finished entering invoices into this UPS batch, select
.B Close
from the UPS ring menu.
This tells the system that you've finished entering invoices into this batch.
.PP
To generate the UPS report, select the command
.BR "Report UPS"
from the ring menu.
This generates two reports:
a report that lists the invoices that have been processes, with information
about each customer and his order; and a report that summarizes the orders
in the batch, including summaries of income.
Give both to the UPS driver.
.PP
If a product is being shipped by a shipper other than UPS, the shipping
date must be entered by hand into its invoice record.
From the main menu, select the option
.BR Date .
Enter the invoice number into the field labelled
.BR "invoice no" .
Then type the date the product was shipped into the field labelled
.BR "ship date" .
The system initializes this date to yesterday's date;
if this is not the correct, press the space bar to blank out the field
or type the correct date over it.
.PP
To exit from this screen, press \fB<Esc>\fR, which accepts the shipping
date that appears on the screen; or \fB<Del>\fR, which aborts data entry.
.PP
This concludes the discussion of how to process invoices.
.SH "Process a Bounced Check"
.PP
By default, orders that are received with checks are processed as soon as we
receive them.
As noted above, the number of the customer's check is typed into the field
labelled
.B comments
on the main invoice screen.
The check is then forwarded to the bank for processing.
.PP
If a check bounces, invoke the main invoice screen, and invoke the command
.B Find
so you can look up the invoice by entering its number.
As soon as you have found the correct invoice, press the \fB<Enter>\fR key
until the cursor is in the field labelled
.BR bounce ;
then `Y', to indicate that the check has bounced.
Turn the matter over to your supervisor.
.\" Bob then calls Guido, who breaks the customer's legs.
.SH "Returned Products"
.PP
When a customer purchases one of our products, he has 60 days to evaluate
the product.
If he decides the product is not for him
.\" or if he decides to rip it off
he can return the product and get his money back.
.PP
The first step in the returning process is for the customer to telephone us
and obtain a return-authorization number.
The person who speaks with the customer must fill out the authorization
screen.
Log into the SCO machine, then type
.B inv
to invoke the invoice program.
.PP
Before you can enter an authorization, you must find the customer's invoice
number.
If the has the invoice number, from his packing sheet, all is well; if not,
invoke the command
.BR Inv ,
from the main menu,
which displays the main invoice screen, as shown above.
From this screen's ring menu, invoke the command
.BR Query ,
and enter information you take from the customer to look up his invoice.
When you have found the correct invoice number, jot it down on a piece of
paper, and press
.B Exit
to return to the main menu.
.PP
From the main menu, invoke the command
.BR Auth ,
which executes a return authorization.
When you invoke this command, the system displays the following screen:
.B1
.sp \n(pDu
	Authorization:  Add  Query  Modify  Delete  Report  Why  Exit
.sp \n(pDu
			Return Authorization
.sp \n(pDu
	auth no    [           ] auth date [          ] ret date [          ]
				 inv date [          ] ship date [          ]
	invoice no [           ] [                                      ]
        	                 [                                      ]
	                         [                                      ]
	        	    phone no     [                                    ]
	prod   [    ] [                              ]
	reason [    ] [                                      ]
.sp \n(pDu
.B2
.PP
Press
.B Add
to add a new return-authorization.
The system displays information about the customer; read it to ensure that you
have found the right invoice.
When you are sure that you have found the correct invoice, move the cursor
to the field labelled
.B prod
and enter the code of the product to be returned.
The legal product codes are given above.
The system looks up the product's name and displays it for you; read it to
ensure that you have entered the correct product.
Note that the system does
.I not
cross check what you enter with what is already in the data base, so be
very sure that you do not enter a return authorization for a product that
the customer did not purchase.
.PP
After you have found the correct invoice and the correct product,
move the cursor to the field labelled
.B reason
and enter the code for the reason why the user wishes to return the product.
Usually you will enter `5', for ``Other''; in this case, the cursor jumps
to the field to the right of the one labelled
.BR reason ,
and you should type the reason why the user wishes to return the product.
Be succinct.
.PP
When you have finished entering the reason, the system will record the
return authorization, and display in the field labelled
.B "auth no"
the return-authorization number.
Give that number to the user, and ask him to write it prominently on the
face of the package when he returns the product.
.PP
When a product is returned,
again invoke the Auth screen; then invoke the
.B Query
command to look up the return-authorization record.
Type the return-authorization number into the field labelled
.BR "auth no" ,
then press
.BR <Esc> .
Check what the system displays to make sure that you have found the correct
authorization record.
.PP
When you have found the correct record, press
.B Modify
to modify the record; then type today's date into the field labelled
.BR "ret date" ,
to note the date that the product was returned.
Note the number of the invoice for this return.
Make sure that we received the product no more than 60 days after it
was shipped.
If the customer waited considerably longer than 60 days, then the guarantee
is void; ship the product back to him.
.PP
If, however, the customer returned the product in time, then he must be
reimbursed.
Exit from this screen to the main menu; then invoke the Inv screen.
Invoke the
.B Find
command; then use the invoice number to look up this invoice record,
and see how the customer paid.
.PP
If the customer paid by check, then fill out a check-request form.
Make a copy of the form and send it to the customer;
send the original form to Accounting, who will cut a check for the customer and
mail it to him.
.PP
If the customer paid via credit card, then you must generate a credit memo.
Invoke the
.B inv
program; from the main menu, invoke the command
.BR Crdt .
The system displays the following screen:
.B1
.sp \n(pDu
	CREDIT:  Add    Query    Card    Report    Exit
.sp \n(pDu
				Credit Memo
.sp \n(pDu
	memo no    [           ] memo date [          ] auth no [          ]
	invoice no [           ] [                                      ]
	amount     [           ] payments [           ]
	comments   [                                                  ]
	           [                                                  ]
	bounce	   [ ] batch [      ]
	terms [    ] card [                    ] [     ] rf [          ] [ ]
	add type   [ ] [                                      ]
	               [                                      ] 
	               [                                      ]
	city [               ] state [    ] country [              ] zip [          ]
.sp \n(pDu
.B2
.PP
Invoke the command
.BR Add .
Move the cursor to the field labelled
.B "auth no"
and enter the return-authorization number.
The system looks up this product's invoice and displays it;
read it to confirm that you have selected the correct invoice.
When you are certain you have the right invoice, confirm the amount to
credit the customer.
The credit memo will be processed automatically the next time we contact
.BR tymnet .
.SH "Record a Payment"
.PP
Some large institutions (e.g., governmental agencies and universities)
purchase our products through a purchase order rather than via check or
credit card.
They pay for the product after they have received it; and sometimes payments
are in piecemeal.
.PP
Therefore, sometimes it is necessary to record a payment for a product that's
already been shipped.
To record a payment, log into the SCO machine and type
.B inv
to invoke the invoice program.
If the paperwork that accompanies the check does not include the number of the
invoice for which payment is being rendered, invoke the
.B Inv
command, and use its screen to find the number of this customer's invoice.
.PP
When you have found the number of the customer's invoice,
select the command
.B Pay
from the main menu.
The program displays the following screen:
.B1
.sp \n(pDu
	Payment:  Add  Query  Modify  Delete  Report  Exit
.sp \n(pDu
				Payment Screen

	payment no  [           ]
	pay date    [          ]
	invoice no  [           ]
	contact     [                                      ]
	phone_no    [                                    ]
	amount      [           ]
	comment     [                                                  ]
.sp \n(pDu
.B2
.PP
Select the command
.B Add
and transcribe appropriate information into each field.
The program skips the field labelled
.BR "payment no" ;
the system generates this number after you have finished entering
information into the other fields.
The system also looks up and displays the name and telephone
number of the customer after you enter the invoice number.
Record the number of the check in the field labelled
.BR comment .
.PP
When you have finished entering information, the system writess the row into
its data base.
Double check what you have typed to make sure that it is correct.
If you find an error, you can use the command
.B Modify
from the ring menu to correct it.
Select
.B Exit
to return to the main menu, or add another payment record, as you prefer.
.SH "Adding a Person to a Mailing List"
.PP
Often, customers contact us to request information about our products.
We add these persons to our mailing list.
The information we record here is not only used to send mailers to the
customer, but is used when the customer calls back to order a product.
.PP
To add a person to the mailing list, invoke the
.B inv
program, then select
.B Mail
from the main menu.
The system displays the following screen:
.B1
.sp \n(pDu
	MAILER:  Add  Query  Modify  Delete  Call  Report  Exit
.sp \n(pDu
					Mailer screen
	customer no  [           ] id [         ] ser [          ] date [           ]
	contact      [                                      ]
	phone no     [                                    ]
	all info     [ ]
	address      [                                      ]
	             [                                      ]
	             [                                      ]
	city [                    ] ST [    ] cntry [              ] zip [           ]
	inquiry source [      ] [                    ]
.sp \n(pDu
.B2
.PP
If the customer doesn't know if he's contacted us before, select the
option
.B Query
and type his name into the field labelled
.BR contact .
See if what the system retrieves; if the customer is already there, then
there's no need to do anything further.
.PP
If the customer knows that he's never contacted us before, or if you cannot
find him in the data base, select the option
.B Add
from the ring menu.
The system walks you through the fields one by one.
.PP
Please note that the field labelled
.B "all info"
is obsolete; type a `Y' into it.
.PP
When you enter the field labelled
.BR "inquiry source" ,
type the code of the source for the inquiry:
a magazine advertisement, word of mouth, or whatever.
A list of legal codes is given above, in the section on entering an invoice.
The system looks up the code and displays its interpretation in the field
to the right of where you typed the code.
Read what the system prints and make sure that the code you typed is correct;
and fix it if necessary.
.SH "Processing a Call to Technical Support"
.PP
When a customer calls with a technical problem, information about that call
is recorded throught the sub-system
.BR tech .
.PP
To invoke this sub-system,
select
.B tech
from the main menu.
It displays the following screen:
.DM
.sp \n(pDu
	Customer  Add Customer  Fix Address  Hardware  New  Update  Exit
.sp \n(pDu
	COHERENT Serial No.: [           ]  Customer No.: [           ]
	Name: [                                      ]
	      [                                      ]
	      [                                      ]
	      [                                      ]
	City [                    ] ST [    ] ZIP [           ] Country [              ]
	Phone [                                    ]
	Email [                                   ]
	Processor: [ ]    SX/DX: [ ]   Co-processor? [ ]   Speed: [     ]   RAM: [     ]
	Video Card: [          ] Video RAM: [     ]  Hard Disk: [ ]  Disk Space: [     ]

	Problem Number: [          ]    Date Reported: [          ]    Tech: [         ]

	Description:
	[                                                                              ]
	[                                                                              ]
	[                                                                              ]
	Resolution:
	[                                                                              ]
	[                                                                              ]
	[                                                                              ]
.sp \n(pDu
.DE
.PP
The following describes the tasks you can perform with this sub-system.
.Sh "Handle a Technical Problem"
.PP
When a customer calls with a problem, you must first identify the customer.
To do so, select
.B Customer
from the ring menu.
This function walks you through four fields:
``Serial No.'', which holds the serial number of this person's copy of
\*(CO;
``Customer No.'', which holds the customer's serial number;
``Name'', which holds the customer's name;
and ``Problem Number'', which holds the number of a previous problem
reported by this customer.
If you enter information into any of these fields, the module attempts to
look up the customer.
.PP
To abort selecting a customer, press
.BR <Del> .
.PP
If you enter information in the ``Name'' field and that name identifies
more than one customer, the system will display all of the names and let
walk through them until you find the one that you want.
.PP
If you enter information in the ``Problem Number'' field,
the system selects the problem that this number describes as well as
information about the customer.
.PP
If, for some reason, the system selects information about the wrong customer
(say, you typed a number incorrectly), just press
.B Customer
once more and try again.
.PP
Once you have identified the customer, you can either update an existing
problem or enter a new problem.
.PP
To update an existing problem, select
.B "Update Problem"
from the ring menu.
The system selects all problems that this customer has reported, and
lets you walk through them by pressing
.B Select
and
.B Previous
keys.
Once you have selected the problem you want, the cursor jumps to the
``Description'' fields.
You can then modify what is in these fields and the ``Resolution'' fields.
When you are finished, type
.BR <Esc> .
.PP
To enter a new problem, select
.B "New Problem"
from the ring menu.
The system automatically initializes the field
``Problem Number'' with this problem's number, the field ``Date Reported''
with today's date, and the field ``Tech'' with your login identifier.
Be sure to tell the customer what his problem number is, so he can refer
to it should he call back.
The cursor then jumps to the first ``Description'' field.
Type a description of the problem; you must press
.B <Return>
to jump from one description field to the next.
Then type what advice you give the customer; again, type
.B <Return>
to jump from one field to the next.
When you have finished, press
.BR <Esc> .
If you find that you have made a mistake, you can use the
.B "Update Problem"
option to correct what you have entered.
.Sh "Add a New Customer"
.PP
Sometimes you may need to add a new customer to the data base.
For example, a customer may have purchased his copy of \*(CO from a
dealer, and so may not be known to our data base.
.PP
To enter information about a new customer, select
.B "Add Customer"
from the ring menu.
The module will walk you through all of the relevant fields.
Type the appropriate information into each field.
The module will complain if you try to skip a key field, such as the
name, city, ZIP code, or phone number.
.PP
Be sure to ask the customer about his E-mail address and hardware.
Enter those data into the appropriate fields.
.PP
To abort entering a new customer record, press
.BR <Del> .
.PP
When you have finished entering information about this customer, press
.BR <Esc> .
The system will assign a customer number to this person and display the
it in the appropriate field.
.Sh "Fix a Customer's Address"
.PP
If, when you are identifying a customer, you find that that customer's
address is incorrect, you can update the address.
This may be necessary if, for example, the customer has moved.
You will also use this feature to add the customer's E-mail address to the
data base.
.PP
To update the customer's address, select
.B "Fix Address"
from the ring menu.
The module will walk you through the appropriate fields.
Be sure to ask the customer for his E-mail address.
.PP
To abort data entry, press
.BR <Del> .
.PP
When you have finished entering data, press
.BR <Esc> .
If you find later that you have made a mistake, you can again invoke
.B "Fix Address"
to correct your correction.
.Sh "Add or Update Information About Hardware"
.PP
To add or update information about the user's hardware, select
.B Hardware
from the ring menu.
The module walks you through the appropriate fields.
Most require a one-character response.
Note that disk space and RAM must be entered in megabytes; but video RAM
should be entered in kilobytes.
.PP
To abort entering hardware information, press
.BR <Del> .
To indicate that you have finished entering information, press
.BR <Esc> .
If you have skipped any key fields, the system will beep at you
and move the cursor to the field into which you must enter information.
.SH "Processing Registration Cards"
.PP
When a user receives a product, he should fill out and return the user
registration card.
We must transcribe cards into the system, so we can build reports around them.
For example, if a user indicates that he would be interested in the driver
kit, then we'll send him a mailer when the next release of the driver kit
is published.
.PP
To transcribe a registration card, log into the SCO system and type
.B inv
to invoke the invoice system.
Then select
.B Nreg
from the main menu.
The system displays the following screen:
.B1
.sp \n(pDu
	REGCARD:  Add  Query  Invoice  Modify  Delete  Report  Exit
.sp \n(pDu
			New Registration Cards
	ser no     [           ] date [          ]
	cust no    [           ] [                                      ]
	                         [                                      ]
                                 [                                      ]
	city [                    ] ST [    ] ctry [              ] zip [           ]
	comp type  [                                      ] disk size  [      ]
.sp \n(pDu
	Development [ ]	Learn UNIX [ ] Other [ ] Communication [ ] Business[ ]
	Annual Expend [ ] experience level  [ ]
	personal use [ ] business use [ ] education [ ]
.sp \n(pDu
	C Compilers [ ] Turbo C [ ] Micro C [ ] Other [ ]
	MacIntosh [ ] Windows [ ]
	Workstations [ ] SUN [ ] IBM [ ] DEC [ ] HP [ ]
	O.S [ ] Sys V [ ] ULTRIX [ ] XENIX [ ] AIX [ ] SUNOS [  ] HPUX [  ] ESIX [  ]
	 Other [          ]
.sp \n(pDu
.B2
.PP
Select the command
.B Add
from the ring menu.
Then wand the bar code from the registration card.
This retrieves the information about this customer and displays it on the
screen.
Check it to make sure that it matches what the customer has entered on the
card.
.PP
When you have checked (and, if necessary, corrected) the information on the
customer, then transcribe the card.
The screen matches fairly close the layout of the card; just copy what the
user has entered in each cell of the card into the corresponding field on the
screen.
.PP
When you have finished entering data, the system records it in its data base.
Check what you have entered; if you have made a mistake, select
.B Modify
from the ring menu and correct any erroneous fields.
When you are sure the information is correct, you can either add another
card, or select
.B Exit
to return to the main menu.
.SH "Checking an Order"
.PP
From time to time, a customer will call to ask, ``Where's my \*(CO?''
This section discusses what to do when this happens.
.PP
The first step is to look up the customer's invoice.
The customer naturally will not know his invoice number because he hasn't
received his order yet.
To do this, log into the SCO machine; then invoke the
.B inv
command and select
.B Inv
from the main menu.
This displays the invoice screen, shown above.
Then select the
.B Query
option, and enter information with which the system can locate the invoice.
Try the following information:
.IP \(bu 0.3i
First use the customer's name.
If the customer has a common name, you may wish to use his name plus his
ZIP code number.
.IP \(bu
If you cannot locate the customer under his name (his may be acting as an
agent for a company, or his name may have been misspelled), try entering his
credit card number.
.IP \(bu
If the credit-card number fails, try entering the customer's ZIP code number
and the date on which he ordered the product.
.IP \(bu
If all else fails, try looking through all orders for the date the customer
placed the order, assuming the customer knows the date (if he ordered by mail,
he will not.)
.PP
If worse comes to worst, ask one of the front-office staff members to search
for the customer's order among the paper files.
.PP
Once you have found the customer's invoice, check the the shipping date.
If the package is being shipped UPS ground, the package can take up to a
week to arrive; UPS Red or UPS Blue should arrive more quickly.
However, the customer should be prepared to be patient.
.PP
If a package is overdue, check that it was shipped correctly.
The customer may have requested (and been charged for) UPS Red or Blue
but the package may have mistakenly been shipped via UPS Ground.
In that case, try to soothe the customer; we may have to reimburse the
customer's shipping charges to mollify him (but only offer this as a last
resort).
.PP
If an overdue package was shipped correctly,
check that the address is correct:
the package may be undeliverable because the address is garbled.
If the package was sent to the wrong address, correct it and notify
the front office of the problem.
.PP
If the address is correct, you may need to trace the package.
Usually, this is done by the front-office staff; in brief, however, a trace
requires calling UPS, and giving them the pickup record number and ZIP code to
which the package is going.
UPS usually responds in an hour or so.
UPS may have lost the package; or it may have been delivered and misplaced at
its destination \(em this sometimes happens with packages sent to big
companies.
.\" Or sometimes even small ones, as well we know ...
If the package arrived at the correct destination and was signed for, notify
the customer of that fact; at that point, the problem basically
is in his hands.
If UPS appears to have misplaced the package, notify the front office.
.PP
If the package has no shipping date,
check why it wasn't shipped.
The product may be on back-order; if so, notify the customer of that fact
and give him some idea of when we expect it the product to be shipped.
.PP
If the product is not on back order, check the status of his credit-card
transaction.
If the transaction was rejected, check the customer's credit-card number:
it may have been entered incorrectly.
If so, correct the number and resubmit the invoice for processing.
If the credit-card number is correct, the customer's account may
have been ``maxed out'';
in that case, the customer may give you another credit-card number,
or may ask you to try again.
.PP
In any case, don't give up on an order unless you absolutely have to.
.SH "Reports"
.PP
The invoice system has many reports built into it.
The following describes most of the commonly used reports, by category of
who uses them.
The most important report, the invoice-batch report (which drives the
processing of invoices and processes credit applications with
.BR tymnet ),
is discussed above, in the section that describes how to process invoices.
.Sh "Reports for Marketing"
.PP
Marketing routine uses a number of reports.
The following describes how to generate the reports that Marketing uses
most commonly.
.IP "\fBProduct Report\fR"
The product report
uses the criteria that you type into the Invoice screen to select information
about products.
For each product, it prints the number sold and revenues (charges for the
product, shipping and handling, taxes, and a total).
To run this report, do the following:
.RS
.IP \(bu 0.3i
Enter the
.B inv
program as usual.
.IP \(bu
Select
.B Inv
from the main menu, to select the Invoice screen.
.IP \(bu
Select
.B Report
from the Invoice ring menu.
.IP \(bu
When the Report menu appears, select
.BR Prod .
.IP \(bu
Type information into the Invoice screen to control the report.
To select the period of time for which the report is
generated, type dates into the field labelled
.BR "invoice data" .
For example, entering
.B "<040193"
selects all invoices entered before April 1, 1993.
To enter a range of dates, use the colon syntax; for example, entering
.B "030193:033193"
selects all dates between March 1, 1993, and March 31, 1993.
You may also wish to enter information into the fields for state, ZIP code,
or product.
When you have finished entering information into the screen, press
.BR <Esc> .
.IP \(bu
The report then prompts and asks if you want the detailed report.
Press `y' if you want the detailed report, `n' if you do not.
.RE
.IP
As its name implies, the detailed report gives more information about each
product; it also gives a fuller summary at the end of the report.
This option gives you more information, but it also longer to generate.
.IP "\fBSource Report\fR"
The source report resembles the product report, except that it organizes
its output by the source of the order rather than by product.
In this way, you can evaluate how effective a given source (e.g., a magazine
advertisement) has been in attracting sales.
To print the source report, do the following:
.RS
.IP \(bu 0.3i
Enter the
.B inv
program as usual.
.IP \(bu
Select
.B Inv
from the main menu, to select the Invoice screen.
.IP \(bu
Select
.B Report
from the Invoice ring menu.
.IP \(bu
When the Report menu appears, select
.B Mag
(for ``magazine'').
.IP \(bu
Type information into the Invoice screen to control the report, as
described for the product report.
When you have finished entering information into the screen, press
.BR <Esc> .
.IP \(bu
The system prompts and asks if this is a monthly report.
Press `y' if it is, `n' if it is not.
.IP \(bu
The system prompts and asks if this is an original report (i.e.,
one that you have never run before).
Press `y' if it is, `n' if it is not.
.RE
.IP
The report prints a summary of the quantity and revenue generated by each
originating source.
.IP "\fBJay's Report\fR"
This report resembles the source report, except that it sorts sales by week
by inquiry source, then pipes its output to a shell script that computes
profitability for various magazines.
To run this report, do the following:
.RS
.IP \(bu 0.3i
Enter the
.B inv
program as usual.
.IP \(bu
Select
.B Inv
from the main menu, to select the Invoice screen.
.IP \(bu
Select
.B Report
from the Invoice ring menu.
.IP \(bu
When the Report menu appears, select
.BR Jay .
.IP \(bu
Type information into the Invoice screen to control the report, as
described for the product report.
When you have finished entering information into the screen, press
.BR <Esc> .
.RE
.IP
The system selects information from the data base, then pipes them through
the program
.B forrdb
into file
.BR jay.data .
You can load the contents of
.B jay.data
into Marketing's data base, for further analysis.
.IP "\fBUser Report\fR"
This report generates information on sales, organized by the person who
made or entered the sale.
This report is not run very often.
To generate this report, do the following:
.RS
.IP \(bu 0.3i
Enter the
.B inv
program as usual.
.IP \(bu
Select
.B Inv
from the main menu, to select the Invoice screen.
.IP \(bu
Select
.B Report
from the Invoice ring menu.
.IP \(bu
When the Report menu appears, select
.BR User .
.IP \(bu
Type information into the Invoice screen to control the report, as
described for the product report.
When you have finished entering information into the screen, press
.BR <Esc> .
.RE
.IP
The output of this report is piped through program
.B c10
before it is printed.
.IP "\fBState Report\fR"
This report profiles our sales by state, province, and country.
To invoke the report, do the following:
.RS
.IP \(bu 0.3i
Enter the
.B inv
program as usual.
.IP \(bu
Select
.B Inv
from the main menu, to select the Invoice screen.
.IP \(bu
Select
.B Xtra
(for ``eXtra reports'')
from the Invoice ring menu.
.IP \(bu
When the Xtra menu appears, select
.BR State .
.IP \(bu
Type information into the Invoice screen to control the report, as
described for the product report.
When you have finished entering information into the screen, press
.BR <Esc> .
.RE
.IP
The system pipes the output of this report through program
.B c10
before printing.
.IP "\fBAddress Report\fR"
This report generates a list of every invoice number
plus the state and country from which it originated.
To run this report, do the following:
.RS
.IP \(bu 0.3i
Enter the
.B inv
program as usual.
.IP \(bu
Select
.B Inv
from the main menu, to select the Invoice screen.
.IP \(bu
Select
.B Xtra
(for ``eXtra reports'')
from the Invoice ring menu.
.IP \(bu
When the Xtra menu appears, select
.BR Address .
.IP \(bu
Type information into the Invoice screen to control the report, as
described for the product report.
When you have finished entering information into the screen, press
.BR <Esc> .
.RE
.IP
The system pipes the output of this report through program
.B c10
before printing.
.IP "\fBCommercial Report\fR"
This report prints a commercial invoices.
It prints the contact name and shipping address for every invoice
that matches the criteria you type into the Invoice screen.
To run this report, do the following:
.RS
.IP \(bu 0.3i
Enter the
.B inv
program as usual.
.IP \(bu
Select
.B Inv
from the main menu, to select the Invoice screen.
.IP \(bu
Select
.B Xtra
(for ``eXtra reports'')
from the Invoice ring menu.
.IP \(bu
When the Xtra menu appears, select
.BR Com .
.IP \(bu
Type information into the Invoice screen to control the report, as
described for the product report.
When you have finished entering information into the screen, press
.BR <Esc> .
.RE
.IP
The program pipes the output of this report through the program
.B conform
before printing.
.IP "\fBOriginal-Inquiry Report\fR"
This report prints information the number of invoices and the number of
products ordered by person, organized by the origin of their inquiry
(e.g., a magazine advertisement).
This is another version of the Magazine report, described above.
To run this report, do the following:
.RS
.IP \(bu 0.3i
Enter the
.B inv
program as usual.
.IP \(bu
Select
.B Inv
from the main menu, to select the Invoice screen.
.IP \(bu
Select
.B Ytra
(for ``Yet more reports'')
from the Invoice ring menu.
.IP \(bu
When the Ytra menu appears, select
.BR Orig .
.IP \(bu
Type information into the Invoice screen to control the report, as
described for the product report.
When you have finished entering information into the screen, press
.BR <Esc> .
.RE
.IP
The output of this report is piped through program
.B c10
before printing.
.IP "\fBLine Report\fR"
For each invoice, this report prints the date of the invoice and the 
number of each product in it.
At the bottom, it prints the total number of products ordered.
To run this report, do the following:
.RS
.IP \(bu 0.3i
Enter the
.B inv
program as usual.
.IP \(bu
Select
.B Inv
from the main menu, to select the Invoice screen.
.IP \(bu
Select
.B Ytra
(for ``Yet more reports'')
from the Invoice ring menu.
.IP \(bu
When the Ytra menu appears, select
.BR Line .
.IP \(bu
Type information into the Invoice screen to control the report, as
described for the product report.
When you have finished entering information into the screen, press
.BR <Esc> .
.RE
.IP
The system pipes the output of this report through program
.B c10
before printing.
.IP "\fBMultiple Copies Report\fR"
This report lists customers who have received multiple copies of a product.
These are usually corporate customers.
To run this report, do the following:
.RS
.IP \(bu 0.3i
Enter the
.B inv
program as usual.
.IP \(bu
Select
.B Inv
from the main menu, to select the Invoice screen.
.IP \(bu
Select
.B Ytra
(for ``Yet more reports'')
from the Invoice ring menu.
.IP \(bu
When the Ytra menu appears, select
.BR Line .
.IP \(bu
Type information into the Invoice screen to control the report, as
described for the product report.
When you have finished entering information into the screen, press
.BR <Esc> .
.RE
.IP
The system pipes the output of this report through program
.B c10
before printing.
.Sh "Reports for Accounting"
Accounting runs a number of reports from the Invoice system.
Some reports are printed; others are written to disk and then
copied into Accounting's general ledger system.
The following describes what reports Accounting runs, and how to run them.
.IP "\fBProduct Report\fR"
Accounting runs this report at month's end to find what our sales were during
the month.
It also runs the report periodically to see how many orders are outstanding
due to products being back-ordered.
To run this report, do the following:
.RS
.IP \(bu 0.3i
Enter the
.B inv
program as usual.
.IP \(bu
Select
.B Inv
from the main menu, to select the Invoice screen.
.IP \(bu
Select
.B Report
from the Invoice ring menu.
.IP \(bu
When the Report menu appears, select
.BR Prod .
.IP \(bu
Type information into the Invoice screen to control the report.
To select the period of time for which the report is
generated, type dates into the field labelled
.BR "invoice data" .
For example, entering
.B "<040193"
selects all invoices entered before April 1, 1993.
To enter a range of dates, use the colon syntax; for example, entering
.B "030193:033193"
selects all dates between March 1, 1993, and March 31, 1993.
You may also wish to enter information into the fields for state, ZIP code,
or product.
To find all invoices that are being held for back-ordered products, type
`Y' into the fields to the right of the one labelled
.BR Ext .
When you have finished entering information into the screen, press
.BR <Esc> .
.IP \(bu
The report then prompts and asks if you want the detailed report.
Press `y' if you want the detailed report, `n' if you do not.
.RE
.IP
This report cannot be written to disk.
.IP "\fBBatch Report\fR"
This report prints information about batches of credit-card applications
send to the bank for verification.
To run this report, do the following:
.RS
.IP \(bu 0.3i
Enter the
.B inv
program as usual.
.IP \(bu
Select
.B Inv
from the main menu, to select the Invoice screen.
.IP \(bu
Select
.B Ytra
(for ``yet more reports'')
from the Invoice ring menu.
.IP \(bu
When the Ytra menu appears, select
.BR Batch .
.IP \(bu
Type information into the Invoice screen to control the report, as
described above for the Product report.
When you have finished entering information into the screen, press
.BR <Esc> .
.IP \(bu
When the program asks if you wish to print the report, type `y' if you
want the report printed, or type `n' if you want the report to be
written to disk.
.IP \(bu
If you want the report to be written to disk, insert a formatted MS-DOS
disk into the 5.25-inch disk drive on the SCO machine.
The program will write the file directly to that disk.
If a disk is not in the drive when the program attempts to write its output,
the report will go into the bit bucket and you'll have to run it again.
.RE
.IP
If the output of this report is being written to disk, it is piped through
program
.BR bacct ;
otherwise, it is piped through program
.BR c10 .
.IP "\fBTerms Report\fR"
This report prints a summary of all invoices that match what you enter into
the Invoice screen, organized by the ``term'' (that is, the method of
payment).
To run this report, do the following:
.RS
.IP \(bu 0.3i
Enter the
.B inv
program as usual.
.IP \(bu
Select
.B Inv
from the main menu, to select the Invoice screen.
.IP \(bu
Select
.B Report
from the Invoice ring menu.
.IP \(bu
When the Report menu appears, select
.BR Terms .
.IP \(bu
Type information into the Invoice screen to control the report, as
described above for the Product report.
To select everyone who did
.I not
order via credit card, enter
.B >4
into the field labelled
.BR terms ;
to select everyone who did order via credit card, enter
.B <5
into this field.
When you have finished entering information into the screen, press
.BR <Esc> .
.IP \(bu
The program then asks if you wan the summary report.
Type `y' if you do, and type `n' if you don't.
.RE
.IP
The system pipes this report through program
.B c10
before it is printed.
.IP "\fBtymnet Report\fR"
This report telephones
.B tymnet
and interrogates that system concerning the invoices that match the criteria
you enter into the Invoice screen.
To run this report, do the following:
.RS
.IP \(bu 0.3i
Enter the
.B inv
program as usual.
.IP \(bu
Select
.B Inv
from the main menu, to select the Invoice screen.
.IP \(bu
Select
.B Ytra
(for ``yet more reports'') from the Invoice ring menu.
.IP \(bu
When the Ytra menu appears, select
.BR Tym .
.IP \(bu
Type information into the Invoice screen to control the report, as
described above for the Product report.
When you have finished entering information into the screen, press
.BR <Esc> .
.IP \(bu
The program then asks if you wan the summary report.
Type `y' if you do, and type `n' if you don't.
.RE
.IP
The system pipes the output of this report through program
.B c10
before printing.
.IP "\fBCredit-Memo Report\fR"
At month's end, Accounting runs the credit-memo report, which counts the
credit memos in the previous month (that is, the number of times we credited
customers' credit cards for products that they returned), and sums the
amount of money credited.
To run this report, do the following:
.RS
.IP \(bu 0.3i
Enter the
.B inv
program as usual.
.IP \(bu
Select
.B Credit
from the main menu, to select the Credit-Memo screen.
.IP \(bu
Select
.B Report
from the Credit-Memo ring menu.
.IP \(bu
When the Report
menu appears, select
.BR Accounting .
.IP \(bu
Type information into the Credit-Memo screen to control the report.
When you have finished entering information into the screen, press
.BR <Esc> .
.RE
.IP
The system pipes the output of this report through the program
.B c10
before printing.
.IP "\fBDetail Report\fR"
This prints a detailed report on every invoice.
To run it, do the following:
.RS
.IP \(bu 0.3i
Enter the
.B inv
program as usual.
.IP \(bu
Select
.B Inv
from the main menu, to select the Invoice screen.
.IP \(bu
Select
.B Report
from the Invoice ring menu.
.IP \(bu
When the Report menu appears, select
.BR Detail .
.IP \(bu
Type information into the Invoice screen to control the report, as described
above for the Product report.
When you have finished entering information into the screen, press
.BR <Esc> .
.RE
.IP
The system pipes the output of this report through the program
.B c10
before printing.
.IP "\fBFile Report\fR"
This report generates a file of information that is downloaded into Accounting's
general-ledger system.
The output is piped through program
.BR pacct
and written into file
.BR acct.fil .
Each row lists the invoice number, invoice date, and total charge for the
invoice.
To run this program, do the following:
.RS
.IP \(bu 0.3i
Enter the
.B inv
program as usual.
.IP \(bu
Select
.B Inv
from the main menu, to select the Invoice screen.
.IP \(bu
Select
.B Xtra
(for ``eXtra reports'')
from the Invoice ring menu.
.IP \(bu
When the Xtra menu appears, select
.BR File .
.IP \(bu
Type information into the Invoice screen to control the report, as
described above for the Product report.
When you have finished entering information into the screen, press
.BR <Esc> .
.RE
.SH "Generating Mailing Labels"
.PP
The
.B inv
program can generate mailing labels, using information that you type into
the Invoice screen.
To generate a set of mailing labels, do the following:
.IP \(bu 0.3i
Enter the
.B inv
program as usual.
.IP \(bu
Select
.B Inv
from the main menu, to select the Invoice screen.
.IP \(bu
Select
.B Xtra
from the Invoice ring menu (for eXtra reports).
.IP \(bu
When the Xtra menu appears, select
.BR Mail .
.IP \(bu
Type information into the Invoice screen to control the report.
To select the period of time for which the report is
generated, type dates into the field labelled
.BR "invoice data" .
For example, entering
.B "<040193"
selects all invoices entered before April 1, 1993.
To enter a range of dates, use the colon syntax; for example, entering
.B "030193:033193"
selects all dates between March 1, 1993, and March 31, 1993.
You may also wish to enter information into the fields for state, ZIP code,
or product.
When you have finished entering information into the screen, press
.BR <Esc> .
.PP
The report selects names and the shipping addresses for each customer who
matches the criteria you entered into the Invoice screen.
The output is sorted by ZIP code number.
The program pipes the output of this report through program
.BR mform ,
which arranges the addresses suitable for printing on two-column
adhesive labels.
.PP
Be sure to load the laser printer attached to the SCO machine with sheets
of labels.
Be sure, too, that everyone knows that you are printing labels, so that
someone does not print another report or a listing onto those expensive
labels.
.SH "Recompiling a Program"
.PP
From time to time, programs need to be updated and recompiled.
To do so, perform the following steps:
.IP \fB1.\fR 
Go the Interactive machine in what used to be Bob's cubicle.
Log into the machine as
.BR bob .
When prompted as to whether to use the new bits, answer `y'.
.IP \fB2.\fR
Type \fBcd $N\fR.
This moves you to the source directory.
.IP \fB3.\fR
Make your changes to the code.
.IP \fB4.\fR
Type \fBi4gl\fR, to invoke the interactive 4GL program.
Select the program to compile interactively; correct any problems that
pop up during compilation.
(We should use \fBmakefile\fRs to control this process.)
.IP \fB5.\fR
When the command is recompiled successfully, exit from \fBi4gl\fR.
.B strip
the newly command command, then
.B tar
it to a floppy disk with this command:
.DM
	tar cvf /dev/rdsk/f05ht \fIfilename\fP
.DE
.IP \fB6.\fR
Log out of the Interactive system.
Log into the SCO system as \fBbob\fR.
Again, answer `y' when asked about using the new bits.
.IP \fB7.\fR
Type \fBcd $B\fR to change to the correct directory.
.IP \fB8.\fR
Insert the floppy disk into the SCO box and type
.DM
	tar xvf /dev/rdsk/f05ht
.DE
to extract the newly compiled program.
.PP
And that's all there is to it.
