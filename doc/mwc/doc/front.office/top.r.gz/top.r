.ie t \{\
.ds AR "\\f(SCANSI\\fP Rationale"
.ds AS "\\f(SCANSI\\fP Standard"
.ds BM "\\f(SCIBM PC\\fP"
.ds CO \\f(SCCOHERENT\\fP
.ds MD \\f(SCMS-DOS\\fP
.ds ME "\\f(SCM\fPicro\\f(SCEMACS\\fP"
.ds OS \\f(SCCOHERENT\\fP
.ds PN \\f(SCCOHERENT\\fP
.ds UN \\f(SCUNIX\\fP
.ds UU "\\f(SCUUCP\\fP"\}
.el \{\
.ds AR "ANSI Rationale"
.ds AS "ANSI Standard"
.ds BM "IBM PC"
.ds CO COHERENT
.ds MD MS-DOS
.ds ME "MicroEMACS"
.ds OS COHERENT
.ds PN COHERENT
.ds UN UNIX
.ds UU "UUCP"\}
.ds CR 1994
.ds KR "\\fIThe C Programming Language\\fR, second edition"
.ds MW "Mark Williams Company"
.ds TI "FRONT OFFICE"
.ds Ql `
.ds Qr '
.ds QL ``
.ds QR ''
