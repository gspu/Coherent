.ds TL "Front-Office Program"
.NH "Front-Office Program"
.PP
This chapter walks you through the MWC sales and inventory program.
This program manipulates the data base
.BR mwc ,
and is built out of the 4GL and C modules described in the previous chapter.
With this system, you can:
.IP \(bu 0.3i
Enter information about a customer.
.IS \(bu
Enter information about an order.
.IS \(bu
Look up information about a previously entered invoice.
.IS \(bu
Modify the static tables in the data base.
.IS \(bu
Run credit memoranda.
.IS \(bu
Wand information into the system.
.IS \(bu
Enter information about payments and credits.
.IS \(bu
Authorize a return.
.IS \(bu
Transcribe registration cards.
.IS \(bu
And generate lots and lots of reports.
.PP
Please note that the bulk of this system was written by Charles Fiterman.
The UPS sub-system was written by Vladimir Smelyansky.
The technical-support sub-system was written by Fred Butzen.
.SH "Invoking the Program"
.PP
To invoke the MWC invoice-management program, log into the SCO system
in the back office, then type
.BR inv .
This brings up the main screen
(function \fBMAIN\fR, found in module \fBall.4gl\fR).
This screen is blank; at the top is a ring menu, from which you can select
one of the sub-programs.
The main ring menu has the following entries:
.IP \fBInv\fR 0.75i
Invoke the invoice sub-system.
This lets you enter a new invoice for a customer.
.IP \fBTech\fR
Invoke the technical-support sub-system.
This lets you add or update a report of a technical problem that a user has
phoned in.
It also lets you update a user's address or E-mail address, or add a new user.
.IP \fBBase\fR
Find, enter, or alter information about
shippers, terms, products, and magazines.
.IP \fBDate\fR
Look up or enter a shipping date.
.IP \fBCrdt\fR
Generate a credit memorandum.
.IP \fBWnd\fR
Wand a bar code into the system.
.IP \fBPay\fR
Enter a payment.
.IP \fBAuth\fR
Enter a return authorization.
.IP \fBReg\fR
Enter an ``old'' registration card.
.IP \fBNreg\fR
Enter a ``new'' registration card, that is, one of the cards that we now
ship with \*(CO.
.IP \fBMail\fR
Add a person to our mailing list.
.IP \fBUPS\fR
Run the UPS subsystem.
.IP \fBExit\fR
Exit from the system and return to the shell.
.PP
The following sections describe each of these sub-systems in detail.
.SH "Inv:  The Invoice Sub-System"
.PP
The
.B Inv
sub-system lets you enter an invoice, plus perform other useful tasks \(em
in particular, run a slew of reports.
To invoke this sub-system, select
.B Inv
from the main menu.
When you do so, the following screen appears (\fBmainline.per\fR):
.B1
.sp \n(pDu
	INVOICE:   Add   Find   Query   Card   Report   Xtra   Ytra   Exit
.sp \n(pDu
	invoice no   [f000       ] invoice date [f001      ]      ship dt. [f003      ]
	contact      [a001                                  ]     cust no  [a000       ]
	phone no     [a002                                ]       orig inq [f047]
	address type [c]   [f018                                  ]	
	 ser [f043      ]  [f019                                  ]  Club  [a003]
	 id  [f042     ]   [f020                                  ]
	city [f021                ] ST [a0  ] ctry [f023          ]    zip [f022       ]
	terms [f9  ][f009   ] card [f040                ] [f041 ]   rf [f046      ] [d]
	payments [f031       ] credits [f030       ] batch [f045 ]  bounce [a]
	comments [f005                                              ]
	inquiry source [f006] [f038                ]
	prod no   [f024  ] quant [f025  ] price [f026    ] Ext [f027    ] [e]
	prod name [f028                          ][f029                          ]
	prod no   [f024  ] quant [f025  ] price [f026    ] Ext [f027    ] [e]
	prod name [f028                          ][f029                          ]
	ship via [f008  ] [f034           ] amt [f013    ] trc [f044              ] [f]
	subtot [f007     ] disc [f014     ] tax [f017][f015    ] tot [f016     ]
.sp \n(pDu
.B2
.PP
The ring menu at the top permits you to perform the following tasks
(function \fBinvoice_menu()\fR in module \fBmainline.4gl\fR):
.IP \fBAdd\fR 0.75i
Add an invoice (function \fBenter_invoice()\fR, in \fBmainline.4gl\fR).
When you invoke this option, you will be popped into the above screen.
The program walks you the following steps:
.RS
.IP \(bu 0.3i
Enter information about the customer.
.IS \(bu
Enter information about the customer's addresses.
One address is the customer's mailing address, the other his shipping address.
In most instances, these are the same.
.IS \(bu
Enter information about the customer's credit card.
.IS \(bu
Enter information about the source of the order.
.IS \(bu
Enter the products the customer is ordering, if any.
.IS \(bu
Enter information on method of shipping, shipping cost, and discount.
.RE
.IP \fBFind\fR
Search for an invoice (function \fBfind_invoice()\fR, in \fBmainline.4gl\fR).
You can search either on a shipping registration number, or on information
about the customer (name, address, telephone number).
The system retrieves a number of ``candidate'' invoices; you can look at
them at select the one that you wish to review.
.IP \fBQuery\fR
Search for an invoice (function \fBfind_invoice()\fR, in \fBmainline.4gl\fR).
Unlike the
.B Find
option, you will not be prompted to enter a \*(CO registration number.
.IP
If you select a record with either the
.B Find
or the
.B Query
options, the system displays a new ring menu, with which you can manipulate
this record (function \fBmod_invoice_menu(), in \fBmainline.4gl\fR).
This menu has the following commands:
.RS
.IP \fBModify\fR 0.75i
Modify this invoice (\fBmodify_invoice()\fR in \fBmainline.4gl\fR).
.IP \fBFix\fR
Fix a batch number; update all of the invoices linked to that batch.
Only users
.B esther
and
.B madeline
can run this command.
.IP \fBResend\fR
Retry a failed transaction.
.IP \fBVoid\fR
Send a void message to
.BR tymnet .
Log the invoice as having been marked void.
.IP \fBDelete\fR
Delete this invoice.
.IP \fBBounce\fR
Record a bounced check.
Set field
.B bounce
to
.B Y
in the record of this invoice.
.IP \fBPayment\fR
Register a payment (function \fBregister_pay()\fR in \fBmainline.4gl\fR).
.IP \fBExit\fR
Exit from this menu; do not modify the invoice.
.RE
.IP \fBCard\fR
Run a credit-card batch (\fBcard_batch()\fR in \fBmainline.4gl\fR).
.IP \fBReport\fR
Select and run a report (program \fBreports.4ge\fR, from module
\fBreports.4gl\fR).
This displays a new ring menu at the top of the screen, which contains
the following commands:
.RS
.IP \fBProd\fR 0.75i
Run the product report (function \fBa_report()\fR, in \fBreports.4gl\fR).
.IS \fBTerms\fR
Run the ``terms'' report (function \fBx_report()\fR, in \fBreports.4gl\fR).
The report gives sales by ``terms'' \(em that is, by the method of payment.
The output of this report is piped through program
.B c10
before printing.
.IS \fBDetail\fR
Run the detail report (function \fBx_report()\fR, in \fBreports.4gl\fR).
.IS \fBFreeze\fR
Freeze some invoices (function \fBrefrig()\fR [get it?], in \fBreports.4gl\fR).
.IS \fBMag\fR
Report inquiries by source (function \fBa_report()\fR, in \fBreports.4gl\fR).
.IS \fBJay\fR
Run Jay's inquiry file (function \fBa_report()\fR, in \fBreports.4gl\fR).
Note that the output of this report is piped to the program
.BR forrdb ,
which massages the data into a form that can be used by
.BR /rdb ;
and the output is written into file
.BR jay.data .
Marketing loads the contents of
.B jay.data
into its own data base, and analyzes the data to check the profitability
of our advertisements.
.IS \fBUser\fR
Generate the sales report, organized by the person who took the sale
(function \fBx_report()\fR, in \fBreports.4gl\fR).
The output of this report is piped through program
.B c10
before it is printed.
.IS \fBState\fR
Run the report on the Illinois-state taxes
(function \fBst_report()\fR, in \fBreports.4gl\fR).
.IS \fBCust\fR
Print the master customer list
(function \fBst_report()\fR, in \fBreports.4gl\fR).
.IS \fBExit\fR
Exit from this menu and return to the
.B Inv
menu.
.RE
.IP
Many of these reports depend on parameters that you type into the
Inventory screen
The reports are described more fully below.
.IP \fBXtra\fR
Run still more reports
(executable \fBrepx.4ge\fR, whose source is in module
\fBrepx.4gl\fR).
This displays a new ring menu at the top of the screen;
the following gives each entry in the ring menu:
.RS
.IP \fBDetail\fR 0.75i
Run the detail report for credit (\fBa_report()\fR in \fBrepx.4gl\fR).
.IS \fBMail\fR
Generate mailing labels (\fBad_report()\fR in \fBrepx.4gl\fR).
The output of this report is piped through program
.B mform
(compiled from source file
.BR mform.c ).
This program formats the output of the report into two-column form and
aligns the output, suitable for printing onto adhesive labels via the
laser printer.
.IS \fBState\fR
Show sales by state (\fBst_report()\fR in \fBrepx.4gl\fR).
The system pipes the output of this report through the program
.B c10
before printing.
.IS \fBAddress\fR
Generate a report for Bob Swartz that organizes information by address
(\fBad_report()\fR in \fBrepx.4gl\fR).
The output of this report is piped through program
.B c10
before printing.
.IS \fBFile\fR
Generate a file of information used by accounting
(\fBa_report()\fR in \fBrepx.4gl\fR).
The output of this report is piped through program
.B pacct
(compiled from source \fBpacct.c\fR),
whose output is written into file
.BR acct.fil .
.IS \fBXfile\fR
Generate a detail file for accounting
(\fBa_report()\fR in \fBrepx.4gl\fR).
.IS \fBBounce\fR
Report on all all bounced checks
(\fBb_report()\fR in \fBrepx.4gl\fR).
.IS \fBCom\fR
Report on all commercial invoice forms
(\fBa_report()\fR in \fBrepx.4gl\fR).
The output of this report is piped through the program
.B conform
before printing.
.IS \fBHip\fR
Generate the shipping report
(\fBb_report()\fR in \fBrepx.4gl\fR).
.IS \fBExit\fR
Exit and return to the
.B Inv
ring menu.
.RE
.IP
Again, some of the reports depending on parameters that you type into
Invoice screen.
.IP \fBYtra\fR
Run yet more reports (executable
\fBccreps.4ge\fR, compiled from source \fBccreps.4gl).
This displays a new ring menu that contains the following commands:
.RS
.IP \fBBatch\fR
Run the batch report
(\fBb_report()\fR in \fBccreps.4gl\fR).
This report can be written to disk.
If the user selects this option, the output is piped through program
.BR bacct .
.IP \fBTym\fR
Batch report from bank (\fBt_report()\fR, in \fBccreps.4gl\fR).
The output of this report is piped through program
.B c10
before printing.
.IP \fBOrig\fR
Original inquiry report (\fBo_report()\fR, in \fBccreps.4gl\fR).
The output of this report is piped through program
.B c10
before printing.
.IP \fBCard\fR
Credit card report (\fBc_report()\fR, in \fBccreps.4gl\fR).
.IP \fBLine\fR
Quantity date by business name (\fBe_report()\fR, in \fBccreps.4gl\fR).
This report is piped through program
.B c10
before printing.
.IP \fBMulti\fR
Multiple copies to same address (\fBm_report()\fR, \fBccreps.4gl\fR).
This report uses table
.BR qworkf ,
which it drops and recreates every time it is run.
The output of the report is piped through program
.B c10
before printing.
.IP \fBPay\fR
Late payment report (\fBp_report()\fR, in \fBccreps.4gl\fR).
.IP \fBQuick\fR
Quick report (\fBq_report()\fR, in \fBccreps.4gl\fR).
.IP \fBInv\fR
Run the batch inventory report
(executable \fBtnet.4ge\fR, compiled from \fBtnet.4gl\fR).
.IP \fBDup\fR
List duplicate mailing addresses
(executable \fBdupfind.4ge\fR, compiled from \fBdupfind.4gl\fR).
.IP \fBExit\fR
Exit report menu, and return to the Invoice menu.
.RE
.IP \fBExit\fR
Exit from the Invoice screen and returns you to the main menu.
.SH "Base:  Maintain Information on Static Tables"
.PP
The sub-system
.B Base
lets you update some key static tables in the data base.
In particular, you can enter or correct information on
shippers, ``terms'' (that is, method of payment \(em not terminals),
products, and magazines.
.PP
To invoke this sub-system, select
.B Base
from the main menu (executable \fBbase.4ge\fR, from module \fBbase.4gl\fR).
When you do so, the screen clears; and you see a ring menu at the top of the
screen that has the following entries:
.IP \fBProd\fR 0.75i
This entry lets you manipulate table
.BR product ,
which describes the products that we sell (function \fBprod_menu()\fR,
module \fBprod.4gl\fR).
When you select this option, the following screen appears
(from \fBproduct.per\fR):
.PP
.B1
.sp \n(pDu
	PRODUCT:  Add  Query  Backorder  Unback  Modify  Delete  Exit
.sp \n(pDu
	product no   [           ]
	product name [                              ]
	comment1     [                              ]
	price        [           ]
	weight	     [    	 ]
	no list      [ ]
	backorder    [ ]
.sp \n(pDu
.B2
.IP " " 0.75i
You can invoke any of the following commands from the ring menu on this
screen:
.RS
.IP \fBAdd\fR 0.75i
Add a new product to the data base (\fBenter_prod()\fR in \fBprod.4gl\fR).
.IP \fBQuery\fR
Search for a product that is already in the data base
(\fBquery_prod()\fR in \fBprod.4gl\fR).
.IP \fBBackorder\fR
Free the invoices of back-ordered products
(\fBfree_back()\fR in \fBprod.4gl\fR).
The system assumes that a back-ordered product
has arrived in house, and will be shipped soon.
The system therefore removes the
back-order ``lock'' on invoices that are pending the arrival of the
product, so it can process the checks and credit-card orders for these invoices.
.IP \fBUnback\fR
Indicate that back-orders are completed.
.\" whatever that means ...
.IP \fBModify\fR
Modify information about a product, e.g., its price (\fBchange_prod()\fR,
in \fBprod.4gl\fR).
.IP \fBDelete\fR
Drop from the data base the product currently displayed.
.IP \fBExit\fR
Leave this screen, and return to the
.B Base
menu.
.RE
.IP \fBBad\fR
This entry lets you record a complaint about a bad disk.
When you select this entry, the following screen appears
(form \fBbad_disk.per\fR):
.PP
.B1
.sp \n(pDu
		Find    Add    Modify    Delete    Reports    Exit
.sp \n(pDu
	invoice no   [           ] invoice date [           ] ship date [           ]
	contact      [                                      ] cust numb	[           ]
	phone no     [                                    ]
	                      ship address   [                                      ]
	 ser [          ]                    [                                      ]
			                     [                                      ]
	city [                    ] ST [    ] ctry [              ] zip [           ]
	
	call date     [          ]  type [ ]  comments  [                           ]
	reshiped date [          ]  reshiped  shipped via  [      ] [               ] 
.sp \n(pDu
	prod [    ] [                              ] [                              ]
	disk [             ] head [  ]  cylin [    ] file  [                        ]

				  controller [                                      ]
       				inst.message [                                      ]
.sp \n(pDu
.B2
.IP " " 0.75i
The ring menu on the screen contains the following entries
(function \fBbad_disk()\fR, in module \fBbad_disk.4gl\fR):
.RS
.IP \fBFind\fR 0.75i
This option lets you find a customer in the data base
(\fBfind_customer()\fR in \fBbad_disk.4gl\fR).
You must do this before you can change a report of bad media, since the
reports are organized by the customers who registered them.
.IP \fBAdd\fR
This lets you add a new report about a bad disk
(\fBadd_baddisk()\fR in \fBbad_disk.4gl\fR).
The program walks you through the above screen, and prompt you for the
information you must enter into every field.
.IP \fBModify\fR
This lets you modify and correct a report that was entered earlier
(\fBmodify_row()\fR in \fBbad_disk.4gl\fR).
.IP \fBDelete\fR
Delete the current bad-disk report (\fBdel_row()\fR in \fBbad_disk.4gl\fR).
.IP \fBReports\fR
This lets you run reports on bad media (\fBreport_menu()\fR, in
\fBbad_report.4gl\fR).
If you select this option, a new ring menu appears at the top of the screen,
which contains the following following commands:
.RS
.IP \fBTotal\fR 0.75i
Write the total numbers of bad-disk reports and bad disks reported
(\fBtotal()\fR in \fBbad_report.4gl\fR).
The system writes the output of this option to the screen.
.IP \fBCustomer\fR
Profile the customers who report bad media (\fBbad_report()\fR, in
\fBbad_report.4gl\fR).
.IP \fBExit\fR
Exit this menu and return to the
.B Bad
screen.
.RE
.IP \fBExit\fR
Exit this menu and return to the
.B Base
screen.
.RE
.IP \fBMag\fR
This command lets you enter or modify a row into table
.BR magazines .
This table holds the possible routes by which a customer may have heard
of our product \(em that is, an advertisement, a mailer, word of mouth,
or other source.
When you select this option, the following screen appears
(\fBmag.per\fR):
.B1
.sp \n(pDu
	MAGAZINE:  Add  Query  Modify  Delete  Exit
.sp \n(pDu
	inquiry src no [           ]
	description    [                   ]
	monthly cost   [         ]
	current ad     [ ]
.sp \n(pDu
.B2
.IP
The following describes each entry in the ring menu (\fBmag_menu()\fR in
module \fBmag.4gl\fR):
.RS
.IP \fBAdd\fR 0.75i
Add a new magazine (\fBenter_mag()\fR in \fBmag.4gl\fR).
.IP \fBQuery\fR
Find a magazine that already is in the data base (\fBquery_mag()\fR in
\fBmag.4gl\fR).
.IP \fBModify\fR
Modify the magazine record that is now displayed on the screen
(\fBchange_mag()\fR in \fBmag.4gl\fR).
.IP \fBDelete\fR
Delete the record that is currently displayed (\fBdelete_mag()\fR, in
\fBmag.4gl\fR).
.IP \fBExit\fR
Exit this screen and return to the
.B Base
screen.
.RE
.IP \fBShip\fR
Enter information about a shipper.
When you select this option, the following screen appears
(\fBshippers.per\fR):
.B1
.sp \n(pDu
	SHIPPER:  Add  Query  Modify  Delete  Exit
.sp \n(pDu
	shipper no   [      ]
	shipper name [               ]
	cust cost    [         ]
.sp \n(pDu
.B2
.IP
The following describes the entries in the ring menu:
.RS
.IP \fBAdd\fR 0.75i
Add a new shipper (\fBenter_ship()\fR in \fBship.4gl\fR).
.IP \fBQuery\fR
Search for a shipper (\fBquery_ship()\fR in \fBship.4gl\fR).
The system walks you through entering information into the above screen,
then searches the data base for a record that matches.
.IP \fBModify\fR
Modify the record now on the screen (\fBchange_ship()\fR in \fBship.4gl\fR).
.IP \fBDelete\fR
Deletes from the data base the record now displayed on the screen
(\fBdelete_ship()\fR in \fBship.4gl\fR).
.IP \fBExit\fR
Exit from this screen, and return to the
.B Base
screen.
.RE
.IP \fBTerm\fR
This entry lets you add or modify a new term to the data base.
Users can look up terms to ensure that terminology is used consistently
and correctly.
When you select this option, the following screen appears (\fBterm.per\fR):
.B1
.sp \n(pDu
	TERMS:  Add  Query  Modify  Delete  Exit
.sp \n(pDu
	term no   [           ]
	term name [                    ]
.sp \n(pDu
.B2
.IP
The following describes the entries in the ring menu:
.RS
.IP \fBAdd\fR 0.75i
Add a new term to the data base (\fBenter_term()\fR, in \fBterm.4gl\fR).
.IP \fBQuery\fR
Find a term in the data base (\fBquery_term()\fR, in \fBterm.4gl\fR).
.IP \fBModify\fR
Modify the term that is now on the screen (\fBchange_term()\fR,
in \fBterm.4gl\fR).
.IP \fBDelete\fR
Delete the term that is now on the screen (\fBdelete_term()\fR, in
\fBterm.4gl\fR).
.IP \fBExit\fR
Exit from this screen and return to the
.B Base
screen.
.RE
.IP \fBDest\fR
This lets you add or modify a record about a destination.
When you select this option, the system displays the following screen
(\fBdest.per\fR):
.B1
.sp \n(pDu
	DESTS:  Add  Query  Modify  Delete  Exit
.sp \n(pDu
	dest no   [           ]
	dest name [                    ]
.sp \n(pDu
.B2
.IP
The following describes the entries in the ring menu:
.RS
.IP \fBAdd\fR 0.75i
Add a new destination to the data base (\fBenter_dest()\fR, in \fBdest.4gl\fR).
.IP \fBQuery\fR
Find a destination in the data base (\fBquery_dest()\fR, in \fBdest.4gl\fR).
.IP \fBModify\fR
Modify the destination record that is now on the screen
(\fBchange_dest()\fR, in \fBdest.4gl\fR).
.IP \fBDelete\fR
Delete the destination record that is now on the screen
(\fBdelete_dest()\fR, in \fBdest.4gl\fR).
.IP \fBExit\fR
Exit from this screen and return to the
.B Base
screen.
.RE
.IP \fBFrt\fR
Enter information about freight charges.
When you select this option, the system displays the following screen
(\fBfreight.per\fR):
.B1
.sp \n(pDu
	TERMS:  Add  Query   Modify   Delete  Report  Exit
.sp \n(pDu
			MWC Freght Charges
.sp \n(pDu
	prod no    [      ] [                              ]
		   [                              ]
	ship no    [      ] [               ]
	dest no    [      ] [               ]
.sp \n(pDu
	const cost [         ] per pound cost [         ]
.sp \n(pDu
.B2
.IP
Note that the name \fBTERMS\fR in the above ring menu is not a
typographical error.
The following describes the entries in the ring menu:
.RS
.IP \fBAdd\fR
Add a new freight record to the data base (\fBenter_freight()\fR, in
\fBfreight.4gl\fR).
The system walks you through the fields in the above screen, and
prompt you to enter information about the new freight record.
.IP \fBQuery\fR
Find a freight record in the data base (\fBquery_freight()\fR, in
\fBfreight.4gl\fR).
.IP \fBModify\fR
Modify the freight record that is now on the screen
(\fBenter_freight()\fR, in \fBfreight.4gl\fR).
.IP \fBDelete\fR
Delete the freight record that is now on the screen
(\fBdelete_freight()\fR, in \fBfreight.4gl\fR).
.IP \fBReport\fR
This generates a report that describes all freight classes
that the system now recognizes (report \fBfreight_rep()\fR, in
\fBfreight.4gl\fR).
.IP \fBExit\fR
Leave the freight menu and return to the
.B Base
screen.
.RE
.IP \fBCtrys\fR
This option lets you enter or modify information on
``States and Countrys'' [\fIsic\^\fR].
When you select this option, the following screen appears (\fBstate.per\fR):
.B1
.sp \n(pDu
	STATES:  Add  Query  Modify  Delete  Report  Exit
.sp \n(pDu
	state   [    ]			country [              ]
.sp \n(pDu
	blue_zone [      ]	red_zone [      ]
.sp \n(pDu
	destination [    ] [               ]
.sp \n(pDu
.B2
.IP
The following describes each entry in the ring menu:
.RS
.IP \fBAdd\fR 0.75i
Add a new record for a state or country (\fBenter_staet()\fR, in
\fBstate.4gl\fR).
.IP \fBQuery\fR
Find the record for a state or country (\fBquery_state()\fR, in
\fBstate.4gl\fR).
.IP \fBModify\fR
Modify the record that is now on the screen (\fBchange_state()\fR, in
\fBstate.4gl\fR).
.IP \fBDelete\fR
Delete the record that is now on the screen (\fBdelete_state()\fR, in
\fBstate.4gl\fR).
.IP \fBReport\fR
Generate a report on every record for a state and country that the system has
(report \fBstate_list()\fR, in \fBstate.4gl\fR).
.IP \fBExit\fR
Exit from this screen and return to the
.BR Base
screen.
.RE
.IP \fBRep\fR
This option generates a report that dumps most of the static tables in
the data base (\fBrep_all()\fR in \fBbase.4gl\fR).
It returns listings for
products,
shippers,
terms,
destinations,
and
magazines.
.IP \fBExit\fR
Exit from this sub-system and return to the main menu.
.SH "Date:  Maintain Information on Shipping Dates"
.PP
This option in the main menu lets you enter, look up, or modify
shipping dates.
When you select it, the following screen appears (\fBshipdate.per\fR):
.B1
.sp \n(pDu
	invoice no   [           ] ship date [          ]
	contact      [                                      ]
	comments     [                                                ]
.sp \n(pDu
.B2
.PP
The system lets you enter an invoice number, then pulls up the name of the
customer and the shipping record for that invoice (function
\fBship_date()\fR, in module \fBshipdate.4gl\fR).
You can then enter or modify the shipping date, and add comments.
If the shipping date is NULL, the system initializes the shipping date
to yesterday; if this is not the correct shipping date, press the space
bar to blank out the field.
.PP
To exit from this screen, press \fB<Esc>\fR, which accepts the shipping
date that appears on the screen; or \fB<Del>\fR, which aborts this screen.
.SH "Tech:  Enter a Technical Problem"
.PP
This option on the main menu invokes the
.B tech
sub-system.
This sub-system lets you record or update the record of a problem that
a user has telephoned in to us.
It also lets you update a person's address (including his E-mail address),
or add a new person to the system.
.PP
When you select it, the system displays the following screen
(\fBtech.per\fR):
.DM
.sp \n(pDu
	Customer  Add Customer  Fix Address  Hardware  New  Update  Exit
.sp \n(pDu
	COHERENT Serial No.: [           ]  Customer No.: [           ]
	Name: [                                      ]
	      [                                      ]
	      [                                      ]
	      [                                      ]
	City [                    ] ST [    ] ZIP [           ] Country [              ]
	Phone [                                    ]
	Email [                                   ]
	Processor: [ ]    SX/DX: [ ]   Co-processor? [ ]   Speed: [     ]   RAM: [     ]
	Video Card: [          ] Video RAM: [     ]  Hard Disk: [ ]  Disk Space: [     ]

	Problem Number: [          ]    Date Reported: [          ]    Tech: [         ]
	Description:
	[                                                                              ]
	[                                                                              ]
	[                                                                              ]
	Resolution:
	[                                                                              ]
	[                                                                              ]
	[                                                                              ]
.sp \n(pDu
.DE
.PP
The following describes each entry in this screen's ring menu
(\fBtfup_menu()\fR in module \fBtech.4gl\fR):
.IP \fBCustomer\fR
Select a customer (\fBselect_customer()\fR in \fBtech.4gl\fR).
You can enter information in fields ``Serial No.'', ``Customer No.'',
``Name'', or ``Problem Number''.
If you enter information in the ``Name'' field and the name links to more than
one customer, the following ring-menu appears:
.RS
.IP \fBSelect\fR
Select the customer whose record is now displayed on the screen.
.IP \fBNext\fR
View the next record.
If no more records are available to be viewed,
the program displays an error message.
.IP \fBPrevious\fR
View the previous record.
If no more records are available to be viewed,
the program displays an error message.
.IP \fBAbort\fR
Abort looking up a record with the information you entered, and try again.
.RE
.IP "\fBAdd Customer\fR"
Add a new customer to the data base
(\fBadd_customer()\fR in \fBtech.4gl\fR).
You would use this if, for example, a customer had purchased \*(CO from a
dealer instead of directly from us.
.IP "\fBFix Address\fR"
Update the customer's address, telephone number, and E-mail address
(\fBupdate_address()\fR in \fBtech.4gl\fR).
.IP "\fBHardware\fR"
Enter or update information about the user's hardware.
.IP "\fBNew\fR"
Add a new problem (\fBadd_problem()\fR in \fBtech.4gl\fR).
.IP "\fBUpdate\fR"
Update the current problem (\fBupdate_problem()\fR in \fBtech.4gl\fR).
The program displays all problems that this customer has reported, and
displays the following menu:
.RS
.IP "\fBSelect\fR"
Select the problem now displayed on the screen.
.IP \fBNext\fR
View the next record.
If no more records are available to be viewed,
the program displays an error message.
.IP \fBPrevious\fR
View the previous record.
If no more records are available to be viewed,
the program displays an error message.
.IP \fBAbort\fR
Abort looking up a problem with the information you entered, and try again.
.RE
.IP "\fBExit\fR" 
Exit from this module, and return to the main menu.
.SH "Crdt:  Run a Credit Memo"
.PP
This option on the main menu lets you enter a credit memo.
(Credit memos are managed through executable \fBcredit.4ge\fR, which is
compiled from module \fBcredit.4gl\fR.)
A
.I "credit memo"
is to credit a customer's credit card, usually when they have returned
a product and want a refund.
When you select it, the system displays the following screen
(\fBcredit.per\fR):
.B1
.sp \n(pDu
	CREDIT:  Add    Query    Card    Report    Exit
.sp \n(pDu
				Credit Memo
.sp \n(pDu
	memo no    [           ] memo date [          ] auth no [          ]
	invoice no [           ] [                                      ]
	amount     [           ] payments [           ]
	comments   [                                                  ]
	           [                                                  ]
	bounce	   [ ] batch [      ]
	terms [    ] card [                    ] [     ] rf [          ] [ ]
	add type   [ ] [                                      ]
	               [                                      ] 
	               [                                      ]
	city [               ] state [    ] country [              ] zip [          ]
.sp \n(pDu
.B2
.PP
The following describes each entry in this screen's ring menu
(\fBcredit_menu()\fR in module \fBcredit.4gl\fR):
.IP \fBAdd\fR 0.75i
Enter a credit memo (\fBenter_memo()\fR, in \fBcredit.4gl\fR).
This function walks you through the fields of the above screen.
.IP \fBQuery\fR
Find a credit memo, based on information that you enter into the above
screen (\fBquery_memo()\fR, in \fBcredit.4gl\fR).
If you accept the credit memo that the system finds, then the system
displays the following menu (\fBmod_credit_menu()\fR in \fBcredit.4gl\fR):
.RS
.IP \fBModify\fR 0.75i
Modify the current credit memo (\fBchange_memo()\fR in \fBcredit.4gl\fR).
.IP \fBVoid\fR
Send a void message to
.BR tymnet .
.IP \fBResend\fR
Retry a failed transaction.
.IP \fBDelete\fR
Delete the credit memo now displayed on the screen
(\fBdelete_memo()\fR, in \fBcredit.4gl\fR).
.IP \fBExit\fR
Exit from this function without modifying the credit memo; and return
to the credit menu.
.RE
.IP \fBCard\fR
Run a credit-card batch (\fBcard_bat()\fR in \fBcredit.4gl\fR).
The system walks you through entering information into the appropriate
fields, then runs the batch.
.IP \fBReport\fR
Select and run a report on credit memoranda.
(This calls function \fBmemo_report()\fR, in module\fBcredit.4gl\fR.
This function performs all of its work internally, and does not call any
other 4GL functions.)
When you invoke this option, a new ring menu appears, which has the following
options:
.RS
.IP \fBAccount\fR 0.75i
Run the accounting report.
The output of this report is piped through the program
.B c10
before printing.
.IP \fBTerms\fR
Run a credit memo by method of payment (``terms'').
.IP \fBMemo\fR
Print credit-memo sheets.
.IP \fBExit\fR
Exit from the credit-memo screen and return to the main menu
.RE
.IP
.IP \fBExit\fR
Exit from the
.B Crdt
screen and return to the main menu
.SH "Wnd:  Wand Data"
.PP
This entry in the main menu lets you use the bar-code reader to link
an invoice with the physical products being shipped to the customer.
When you invoke it, the following screen appears (\fBwand.per\fR):
.B1
.sp \n(pDu
	WAND:  Add  Find  Delete  Exit
.sp \n(pDu
			Wand Screen
.sp \n(pDu
	Customer Number: [           ]
	Invoice Number:  [           ] 
	Trace Number:    [                  ]
	Shipping Date:   [          ]
	Serial Number:   [           ]
.sp \n(pDu
.B2
.PP
The ring menu for this screen has the following entries:
.IP \fBAdd\fR 0.75i
Add one or more wand entries (\fBenter_wand()\fR in \fBwand.4gl\fR).
.IP \fBFind\fR
Find a wand entry (\fBfind_wand()\fR in \fBwand.4gl\fR).
.IP \fBDelete\fR
Delete a wand entry.
.IP \fBExit\fR
Leave the wand screen and return to the main menu.
.SH "Pay:  Enter a Payment"
.PP
This entry in the main menu lets you record a payment, or modify a previously
entered record.
When you select this option, the following screen appears (\fBpay.per\fR):
.B1
.sp \n(pDu
	Payment:  Add  Query  Modify  Delete  Report  Exit
.sp \n(pDu
				Payment Screen

	payment no  [           ]
	pay date    [          ]
	invoice no  [           ]
	contact     [                                      ]
	phone_no    [                                    ]
	amount      [           ]
	comment     [                                                  ]
.sp \n(pDu
.B2
.PP
The ring menu includes the following commands.
(This menu is invoked by executable \fBcredit.4ge\fR, which is compiled from
module \fBcredit.4gl\fR.
It calls function \fBpay_menu()\fR, in module \fBpayment.4gl\fR.)
.IP \fBAdd\fR 0.75i
Enter a payment (\fBenter_payment()\fR in \fBpayment.4gl\fR).
The system walks you through the fields on the screen, to help you enter
a payment.       
.IP \fBQuery\fR
Search for a payment (\fBquery_payment()\fR in \fBpayment.4gl\fR).
You can enter information into the screen; the system then retrieves the
record, if any, that matches what you entered.
.IP \fBModify\fR
Modify the payment record that is on the screen
(\fBchange_payment()\fR in \fBpayment.4gl\fR).
.IP \fBDelete\fR
Delete the payment record that is on the screen
(\fBdelete_payment()\fR in \fBpayment.4gl\fR).
.IP \fBReport\fR
This function constructs a report on all of the payments that match the
information you entered into the screen
(\fBpayment_report()\fR in \fBpayment.4gl\fR).
.IP \fBExit\fR
Return to the main menu.
.SH "Auth:  Authorize a Return"
.PP
This entry in the main menu lets you enter or modify a return authorization.
When you select it, the system displays the following screen (\fBauth.per\fR):
.B1
.sp \n(pDu
	Authorization:  Add  Query  Modify  Delete  Report  Why  Exit
.sp \n(pDu
			Return Authorization
.sp \n(pDu
	auth no    [           ] auth date [          ] ret date [          ]
				 inv date [          ] ship date [          ]
	invoice no [           ] [                                      ]
        	                 [                                      ]
	                         [                                      ]
        	    phone no     [                                    ]
	prod   [    ] [                              ]
	reason [    ] [                                      ]
.sp \n(pDu
.B2
.PP
The ring menu contains the following commands.
(This menu is invoked by executable \fBcredit.4ge\fR, which is compiled from
module \fBcredit.4gl\fR.
It calls function \fBauth_menu()\fR, in module \fBauth.4gl\fR.)
.IP \fBAdd\fR 0.75i
Add a new return authorization (\fBenter_auth()\fR, in \fBauth.4gl\fR).
The system walks you through each field in the screen, and prompts you for
the proper information.
.IP \fBQuery\fR
Search for an authorization (\fBquery_auth()\fR in \fBquery.4gl\fR).
The system finds the return-authorization records that match
what you enter into the screen.
.IP \fBModify\fR
Modify the authorization record that is on the screen
(\fBchange_auth()\fR, in \fBauth.4gl\fR).
You must first have used
.B Add
or
.B Query
to have, respectively, created or found an authorization record.
.IP \fBDelete\fR
Delete the authorization record that is on the screen
(\fBdelete_auth()\fR, in \fBauth.4gl\fR).
.IP \fBReport\fR
Report on authorization (\fBauth_report()\fR, in \fBauth.4gl\fR).
This command builds a report on the return authorizations
that fit the information you enter into the screen.
.IP \fBWhy\fR
Report on return reasons (\fBwhy_report()\fR, in \fBauth.4gl\fR).
This report builds a report on the return authorization
that fit the information you enter into the screen.
The report concentrates on why people returned the products.
.IP \fBExit\fR
Exit from the
.B Auth
screen and return to the main menu.
.\".SH "Reg:  Enter an Old Registration Card"
.\".PP
.\"The entry
.\".B Reg
.\"in the main menu lets you transcribe an ``old'' registration card into the
.\"system.
.\"When you invoke this command, the system draws the following screen
.\"(\fBregcard.per\fR):
.\".B1
.\".sp \n(pDu
.\"	REGCARD:  Add  Query  Invoice  Modify  Delete  Report  Exit
.\".sp \n(pDu
.\"				Registration Cards
.\"	ser no     [           ] date [          ]
.\"	cust no    [           ] [                                      ]
.\"        	                 [                                      ]
.\"                	         [                                      ]
.\"	city [                    ] ST [    ] ctry [              ] zip [           ]
.\"	comp type  [                                      ] disk size  [      ]
.\"				Magazines
.\"	byte           [ ] C Gazette      [ ] CUG            [ ] Circut Cellar  [ ]
.\"	Comm. of ACM   [ ] Computer Shopp [ ] Comp Language  [ ] Comp World     [ ]
.\"	DR Dobbs       [ ] Unix Review    [ ] Unix Today     [ ] Unix World     [ ]
.\"	EE times       [ ] Embeded Sys    [ ] IEEE spectrum  [ ] Info World     [ ]
.\"	PC Computing   [ ] Personal Comp  [ ] Personal Wk St [ ] Prog Journal   [ ]
.\"	Sys Integrat   [ ] PC Mag         [ ] PC Week        [ ] PC World       [ ]
.\".sp \n(pDu
.\"	experience level  [ ]
.\"	personal use   [ ] business use   [  ] education      [  ]
.\".sp \n(pDu
.\".B2
.\".PP
.\"The ring menu contains the following commands (\fBreg_base()\fB,
.\"in \fBregcard.4gl\fR):
.\".IP \fBAdd\fR 0.75i
.\"Add a new registration card (\fBenter_reg()\fR in \fB\fBregcard.4gl\fR).
.\"The system walks you through the above screen.
.\".IP \fBQuery\fR
.\"Search for a registration card (\fBquery_reg()\fR in \fB\fBregcard.4gl\fR).
.\"The system looks for the registration card that matches the criteria
.\"that you type into the screen.
.\".IP \fBInvoice\fR
.\"Invoice query:
.\"find the registration card that is linked to a given invoice.
.\"The system displays the Invoice screen, which is displayed above;
.\"then finds the registration cards that match the information you enter
.\"into that screen, returns to the registration-card screen, and displays
.\"the cards linked to the invoice you have selected.
.\"The system then lets you enter a registration card for that invoice
.\"if you wish (\fBenter_reg()\fR in \fB\fBregcard.4gl\fR).
.\".IP \fBModify\fR
.\"Modify the registration card that is shown on the screen
.\"(\fBchange_reg()\fR in \fBregcard.4gl\fR).
.\".IP \fBDelete\fR
.\"Delete the registration card shown on the screen
.\"(\fBdelete_reg()\fR in \fBregcard.4gl\fR).
.\".IP \fBReport\fR
.\"Generate a statistical report on registration cards
.\"(\fBreg_report()\fR in \fBregcard.4gl\fR).
.\"The report includes all registration cards that match the information you
.\"enter into the above screen.
.\".IP \fBExit\fR
.\"Exit from this sub-system and return to the main menu.
.SH "Nreg:  Enter a New Registration Card"
.PP
This sub-system lets you transcribe a ``new'' registration card into
the system.
The ``new'' cards are the ones that are now included with our products.
.PP
When you invoke this command, the system displays the following screen
(\fBnewreg.per\fR):
.B1
.sp \n(pDu
	REGCARD:  Add  Query  Invoice  Modify  Delete  Report  Exit
.sp \n(pDu
			New Registration Cards
	ser no     [           ] date [          ]
	cust no    [           ] [                                      ]
	                         [                                      ]
                                 [                                      ]
	city [                    ] ST [    ] ctry [              ] zip [           ]
	comp type  [                                      ] disk size  [      ]
.sp \n(pDu
	Development [ ]	Learn UNIX [ ] Other [ ] Communication [ ] Business[ ]
	Annual Expend [ ] experience level  [ ]
	personal use [ ] business use [ ] education [ ]
.sp \n(pDu
	C Compilers [ ] Turbo C [ ] Micro C [ ] Other [ ]
	MacIntosh [ ] Windows [ ]
	Workstations [ ] SUN [ ] IBM [ ] DEC [ ] HP [ ]
	O.S [ ] Sys V [ ] ULTRIX [ ] XENIX [ ] AIX [ ] SUNOS [  ] HPUX [  ] ESIX [  ]
	 Other [          ]
.sp \n(pDu
.B2
.PP
The ring menu contains the following commands (\fBnreg_base()\fR in
\fBnewreg.4gl\fR):
.IP \fBAdd\fR 0.75i
Add a new registration card
(\fBenter_nreg()\fR in \fBnewreg.4gl\fR).
.IP \fBQuery\fR
Search for a registration card, using the information that you enter into
the screen (\fBquery_nreg()\fR in \fBnewreg.4gl\fR).
.IP \fBInvoice\fR
Invoice query:
find the registration card that is linked to a given invoice.
The system displays the Invoice screen, which is displayed above;
then finds the registration cards that match the information you enter
into that screen, returns to the registration-card screen, and displays
the cards linked to the invoice you have selected.
The system then lets you enter a registration card for that invoice
if you wish (\fBenter_nreg()\fR in \fB\fBregcard.4gl\fR).
.IP \fBModify\fR
Modify the registration card that is on the screen
(\fBchange_nreg()\fR in \fBnewreg.4gl\fR).
.IP \fBDelete\fR
Delete the registration card that is on the screen
(\fBdelete_nreg()\fR in \fBnewreg.4gl\fR).
.IP \fBReport\fR
Generate a statistical report on the registration cards
(\fBnreg_report()\fR in \fBnewreg.4gl\fR).
The report includes all cards that match the criteria you enter into the screen.
.IP \fBExit\fR
Exit from this sub-system and return to the main menu.
.SH "Mail:  Mailer Data Base"
.PP
This sub-system lets you add a person to our mailing list.
When you invoke this command, the system displays the following screen
(\fBmailer.per\fR):
.B1
.sp \n(pDu
	MAILER:  Add  Query  Modify  Delete  Call  Report  Exit
.sp \n(pDu
					Mailer screen
	customer no  [           ] id [         ] ser [          ] date [           ]
	contact      [                                      ]
	phone no     [                                    ]
	all info     [ ]
	address      [                                      ]
	             [                                      ]
	             [                                      ]
	city [                    ] ST [    ] cntry [              ] zip [           ]
	inquiry source [      ] [                    ]
.sp \n(pDu
.B2
.PP
The ring menu contains the following commands (\fBmail_menu()\fR in
\fBmailer.4gl\fR):
.IP \fBAdd\fR 0.75i
Add a new person to the mailing list (\fBenter_mail()\fR in \fBmailer.4gl\fR).
.IP \fBQuery\fR
Search for a person in the mailing list
(\fBquery_mail()\fR in \fBmailer.4gl\fR).
The search finds all mailers that match the information you put into the
screen.
.IP \fBModify\fR
Modify the person who is now on the screen
(\fBchange_mail()\fR in \fBmailer.4gl\fR).
.IP \fBDelete\fR
Delete the record that is now on the screen
(\fBdelete_mail()\fR in \fBmailer.4gl\fR).
.IP \fBCall\fR
Callback report on mailer:
generate a report on all the customers who contacted MWC in response to
a given mailer (\fBcall_rpt()\fR in \fBmailer.4gl\fR).
The mailer in question is the one that matches the information you enter
into field ``Inquiry Source''.
.IP \fBReport\fR
Generate a report on this mailer (\fBmail_rpt()\fR in \fBmailer.4gl\fR).
.IP \fBExit\fR
Exit from this sub-system and return to the main menu.
.SH "UPS:  UPS System"
.PP
The UPS sub-system manages the information required to ship products via
the United Parcel System.
It used to constitute an entire system unto itself; however, it now
is part of the
.B inv 
program.
We made this change to permit the
.B wand
program to insert records into the UPS tables automatically.
The UPS sub-system consists of source modules
.BR ups_add.4gl ,
.BR ups_charge.4gl ,
.BR ups_cor.4gl ,
.BR ups_func.4gl ,
.BR ups_grzone.4gl ,
.BR ups_main.4gl ,
.BR ups_report.4gl ,
and
.BR ups_tag.4gl .)
.PP
When you select this command, the screen clears and the following ring
menu appears (function \fBups_main()\fR in \fBups_main.4gl\fR):
.IP "\fBUPS Report\fR" 0.75i
Add new entry, correct, print, and close a UPS report
(\fBups_central()\fR in \fBups_main.4gl\fR).
The UPS report prints a batch of paper used to ship products via UPS.
This is the central UPS function.
When you select this option, the following screen appears (\fBPickLine.per\fR):
.PP
.B1
.sp \n(pDu
	Add    Today   Report UPS    Last    Close    Exit
.sp \n(pDu
				UPS REPORT DATABASE
.sp \n(pDu
	invoice_no [           ]
	contact    [              ]
	address    [                  ]	    commercial [  ]
	.sp \n(pDu
	city       [        ]       ST [   ]     cntry [    ]      zip [       ]
.sp \n(pDu
	weight     [      ]       zone     [      ]       charge   [           ]
	dec_value  [           ]  cod_amt  [           ]  cod_chrg [           ]
	aod        [ ]            Call tag [ ]
.sp \n(pDu
	tag number [           ]
	why        [                                                           ]
	action     [    			                               ]
	issue date [          ]             recieve date [          ]
.sp \n(pDu
.B2
.IP " " 0.75i
The following describes each entry in this screen's ring menu:
.RS
.IP \fBAdd\fR 0.75i
Enter the next invoice number for the UPS report
(\fBups_add()\fR, in \fBups_add.4gl\fR).
.IP \fBToday\fR
View and correct today's UPS report
(\fBups_correct()\fR in \fBups_cor.4gl\fR).
.IP "\fBReport UPS\fR"
Print today's UPS report (\fBups_report()\fR in \fBups_report.4gl\fR).
.IP \fBLast\fR
Print yesterday's UPS report (\fBups_report()\fR in \fBups_report.4gl\fR).
.IP \fBClose\fR
Close the UPS report \(em that is, indicate that you have finished entering
invoice numbers into the UPS system (\fBups_close()\fR in \fBups_func.4gl\fR).
.IP \fBExit\fR
Exit from the report screen, and return to the main UPS screen.
.RE
.IP \fBTag\fR
This command manipulates UPS tags (\fBups_tag()\fR, in \fBups_tag.4gl\fR).
When you invoke this command, the system displays the following screen
(\fBups_tag.per\fR):
.PP
.B1
.sp \n(pDu
	Find    Modify    Delete    Report    Exit
.sp \n(pDu
				    TAG DATABASE
.sp \n(pDu
	invoice_no [           ]
	contact    [              ]
	address    [                  ]	    commercial [  ]
.sp \n(pDu
	city       [        ]       ST [   ]     cntry [    ]      zip [       ]
.sp \n(pDu
	tag number [           ]
	why        [                                                           ]
	action     [    			                               ]
	issue date [          ]             recieve date [          ]
.sp \n(pDu
.B2
.IP " " 0.75i
The ring menu contains of the following commands:
.RS
.IP \fBFind\fR 0.75i
Finds a tag or tags,
using the information that type into the above screen
(\fBtag_find()\fR in \fBups_tag.4gl\fR).
.IP \fBModify\fR
Modify the tag record that is now displayed on the screen
(\fBtag_modify()\fR in \fBups_tag.4gl\fR).
.IP \fBDelete\fR
Delete the tag record that is now displayed on the screen
(\fBtag_delete()\fR in \fBups_tag.4gl\fR).
.IP \fBReport\fR
Run the general tag report (\fBtag_report()\fR in \fBups_tag.4gl\fR).
This report includes all tags whose records match what
you type into the screen.
.IP \fBExit\fR
Exit from this screen, and return to the main UPS screen.
.RE
.IP \fBPrice\fR
This entry helps you to compute the price of a UPS shipment, from
the weight of the package and the zone to which it is being shipped
(\fBups_charge()\fR in \fBups_charge.4gl\fR).
When you invoke this command, the system displays the following screen
(\fBw_z_p.per\fR):
.PP
.B1
.sp \n(pDu
	Add    Find    Modify    Delete    Report    Exit
.sp \n(pDu
	weight [      ]	   zone [      ]    price [        ]   commercial [  ]
.sp \n(pDu
.B2
.IP " " 0.75i
The ring menu contains the following commands:
.RS
.IP \fBAdd\fR 0.75i
Add another weight\-zone\-price combination to the data base.
.IP \fBFind\fR
Find a weight\-zone\-price record, based on what you have typed into the
screen (\fBfind_row()\fR in \fBups_charge.4gl\fR).
.IP \fBModify\fR
Modify the record that is now displayed on the screen
(\fBmodify_row()\fR in \fBups_charge.4gl\fR).
For example,
you could change a price that is associated with a given weight and zone.
.IP \fBDelete\fR
Delete the record that is now displayed on the screen.
.IP \fBReport\fR
Select and print a report (\fBselect_rep()\fR in \fBups_charge.4gl\fR).
This option presents another ring menu, from which you can select a
number of reports on shipping charges,
as follows:
.RS
.IP \fBGround\fR 0.75i
UPS Ground shipping charges (\fBcharge_rep()\fB in \fBups_charge.4gl).
.IP \fBRed\fR
UPS Red (\fBcharge_rep()\fB in \fBups_charge.4gl).
.IP \fBBlue\fR
UPS Blue (\fBcharge_rep()\fB in \fBups_charge.4gl).
.IP "\fBCanada ground\fR"
UPS Canada Ground (\fBcharge_rep()\fB in \fBups_charge.4gl).
.IP "\fBAir Canada\fR"
UPS Canada Air (\fBcharge_rep()\fB in \fBups_charge.4gl).
.IP "\fBInetrnational [\fIsic\^\fB]\fR"
UPS International (\fBcharge_rep()\fB in \fBups_charge.4gl).
.IP \fBExit\fR
Exit from this screen and return to the UPS price screen.
.RE
.IP \fBExit\fR
Exit from this screen and return to the main UPS screen.
.RE
.IP \fBGround\fR
This command lets you maintain the system's table that links a UPS zone
to a range of ZIP-code numbers (\fBups_grzone()\fR in \fBups_grzone.4gl\fR).
When you invoke this command, the system displays the following screen
(\fBground.per\fR):
.PP
.B1
.sp \n(pDu
	Add    Find    Modify    Delete    Report    Exit
.sp \n(pDu
		from_zip [      ]	to_zip [      ]		zone [      ]
.sp \n(pDu
.B2
.IP " " 0.75i
The ring menu contains the following commands:
.RS
.IP \fBAdd\fR 0.75i
Add a new record.
You would use this option should UPS add a new zone.
.IP \fBFind\fR
Find a row, based on information that you type into the screen
(\fBgrzn_find()\fR, in \fBups_grzone.4gl\fR).
For example, if you type a number into the \fBzone\fR field, the system will
find the record for that zone, and display it for you.
In this way, you can see the range of zones that comprise that zone.
.IP \fBModify\fR
Modify the record that is currently on the screen
(\fBgrzn_modify()\fR in \fBups_grzone.4gl\fR).
.IP \fBDelete\fR
Delete from the data base the record that is currently on the screen.
.IP \fBReport\fR
Build and print
a report that lists every UPS zone and its range of ZIP codes
(\fBreport_out()\fR in \fBups_grzone.4gl\fR).
.IP \fBExit\fR
Exit from this screen, and return to the main UPS menu.
.RE
.IP \fBExit\fR
Exit from the UPS program and return to the main menu.
.SH "Where To Go From Here"
.PP
This concludes the introduction to the MWC inventory and sales program.
The next chapter walks you through how to perform specific tasks.
