.ds VN "4.0"
.ll 6.0i
.wh 0 HD
.wh -1.5i FO
.de HD
.sp |2.2i
..
.de FO
.bp
..
.po 1.0i
.sp
.ce 50
.ft HH
.vs 20
Mark Williams Company
.sp 2
Sales & Shipping Procedures
.sp 2
Version 2.0
.ce 0
