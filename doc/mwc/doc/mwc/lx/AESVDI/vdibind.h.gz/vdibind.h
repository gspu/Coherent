.\" ENVIRONMENTS:  TOS
.TH vdibind.h "" "" "Header"
.PC "Declarations for VDI routines"
.B "#include <vdibind.h>"
.PP
.B vdibind.h
is the header file that holds declarations and
definitions for the GEM VDI routines, which
are contained in the library
.BR libvdi .
.SH "See Also"
.B
aesbind.h, headers, VDI
.R
