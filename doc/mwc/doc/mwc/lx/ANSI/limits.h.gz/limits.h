.\" ENVIRONMENTS: COHERENT, LC, TOS, ISIS, ANSI
.TH "limits.h" Header "(Environment/environmental considerations)" Header
.PC
.PP
The header
.B limits.h
defines a group of macros that set the numerical limits for the translation
environment.
.PP
The following table gives the macros defined in
.BR limits.h .
Each value given is the macro's minimum maximum:
a conforming implementation of C must  meet these limits, and
may exceed them.
.RS
.IP \fBCHAR_BIT\fR
.br
Number of bits in a
.BR char ;
must be at least eight.
.IP \fBCHAR_MAX\fR
.br
Largest value representable in an object of type
.BR char .
If the implementation defines a
.B char
to be signed, then it is equal to the value of the macro
.BR SCHAR_MAX ;
otherwise, it is equal to the value of the macro
.BR UCHAR_MAX .
.IP \fBCHAR_MIN\fR
.br
Smallest value representable in an object of type
.BR char .
If the implementation defines a
.B char
to be signed, then it is equal to the value of the macro
.BR SCHAR_MIN ;
otherwise, it is zero.
.IP \fBINT_MAX\fR
.br
Largest value representable in an object of type
.BR int ;
it must be at least 32,767.
.IP \fBINT_MIN\fR
.br
Smallest value representable in an object of type
.BR int ;
it must be at most \-32,767.
.IP \fBLONG_MAX\fR
.br
Largest value representable in an object of type
.BR "long int" ;
it must be at least 2,147,483,647.
.IP \fBLONG_MIN\fR
.br
Smallest value representable in an object of type
.BR "long int" ;
it must be at most \-2,147,483,647.
.IP \fBMB_LEN_MAX\fR
.br
Largest number of bytes in any multibyte character, for any locale;
it must be at least one.
.IP \fBSCHAR_MAX\fR
.br
Largest value representable in an object of type
.BR "signed char" ;
it must be at least 127.
.IP \fBSCHAR_MIN\fR
.br
Smallest value representable in an object of type
.BR "signed char" ;
it must be at most \-127.
.IP \fBSHRT_MAX\fR
.br
Largest value representable in an object of type
.BR "short int" ;
it must be at least 32,767.
.IP \fBSHRT_MIN\fR
.br
Smallest value representable in an object of type
.BR "short int" ;
it must be at most \-32,767.
.IP \fBUCHAR_MAX\fR
.br
Largest value representable in an object of type
.BR "unsigned char" ;
it must be at least 255.
.IP \fBUINT_MAX\fR
.br
Largest value representable in an object of type
.BR "unsigned int" ;
it must be at least 65,535.
.IP \fBULONG_MAX\fR
.br
Largest value representable in an object of type
.BR "unsigned long int" ;
it must be at least 4,294,967,295.
.IP \fBUSHRT_MAX\fR
.br
Largest value representable in an object of type
.BR "unsigned short int" ;
it must be at least 65,535.
.SH Cross-references
.nf
\*(AS, \*(PS2.2.4.2
\*(KR, p. 257
.SH "See Also"
.B
.if \nX<4 Environment, header, numerical limits
.if \nX=4 environmental considerations, header, numerical limits
.R
