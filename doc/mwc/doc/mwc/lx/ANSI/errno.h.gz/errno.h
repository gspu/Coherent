.\" ENVIRONMENTS:  COHERENT, LC, TOS, ISIS, ANSI
.TH errno.h "Header" "(Library/errors)" Header
.XR "error codes, define"
.XR "errno, define"
.XR "define common error codes"
.PC "Define errno and error codes"
.B "#include <errno.h>"
.PP
.B errno.h
is a header that holds information which relates to the reporting of error
conditions.
It defines the macro
.BR errno ,
which expands to global variable of type
.BR "volatile int" .
If an error condition occurs, a
function can write a value into
.BR errno ,
to report just what type of error occurred.
.PP
.if \nX<4 \{\
For a list of the \*(OS system errors described in
.BR errno.h ,
see
.BR error codes . \}
.if \nX=4 \{\
.B errno.h
can also include macros that expand to define specific error conditions.
The Standard mandates that each such macro begin with a capital \*(QlE\*(Qr
and include at least one other capital letter.
The Standard describes two such macros,
.B ERANGE
and
.BR EDOM ,
which indicate, respectively, a range error and a domain error.
These are defined in the header
.BR math.h . \}
.SH Cross-references
.nf
\*(AS, \*(PS4.1.3
\*(KR, p. 248
.SH "See Also"
.B
.if \nX<4 errno, error codes, errors
.if \nX=4 EDOM, ERANGE, errno, errors
.R
