.\" ENVIRONMENTS:  TOS, ANSI
.TH stddef.h "Header" "(Library)" Header
.PC "Header for standard definitions"
.B "#include <stddef.h>"
.PP
The header
.B stddef.h
defines three types and two macros that are used through the library.
They are as follows:
.DS
.ta 0.4i 1.25i
	\fBNULL\fR	Null pointer
	\fBoffsetof()\fR	Offset of a field within a structure
	\fBptrdiff_t\fR	Numeric difference between two pointers
	\fBsize_t\fR	Type returned by \fBsizeof\fR operator
	\fBwchar_t\fR	Typedef for wide \fBchar\fRs
.DE
.SH "Cross-reference"
\*(AS, \*(PS4.1.5
.SH "See Also"
.B
header, Library
.R
