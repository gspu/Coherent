.\" ENVIRONMENTS:  COHERENT, LC, TOS, ISIS, ANSI
.TH string.h Header "(Library/string handling)" Header
.PC
.B "#include <string.h>"
.PP
.B string.h
is the header that holds the declarations and definitions of all
routines that handle strings and buffers.
For a list of these routines, see
.BR "string handling" .
.SH "Cross-references"
.nf
\*(AS, \*(PS4.11
\*(KR, p. 249
.SH "See Also"
.B
header, string handling
.R
