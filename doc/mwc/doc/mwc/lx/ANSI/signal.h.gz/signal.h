.\" ENVIRONMENTS:  COHERENT, LC, TOS, ISIS, ANSI
.TH signal.h "Header" "(Library/signal handling)" Header
.XR "header, signal-handling routines"
.XR "declare signal-handling routines"
.PC "Signal-handling routines"
.B "#include <signal.h>"
.PP
.B signal.h
is the header that defines or declares all elements used to
handle asynchronous interrupts, or
.IR signals .
.PP
Signals vary from environment to
environment.
Therefore, the contents of
.B signal.h
will also vary greatly from environment to environment, and from
implementation to implementation.
The Standard mandates that it define the following
elements to create a skeletal, portable suite of signal-handling
routines:
.DM
.ta 0.4i 1.40i
\fIType\fR
	\fBsig_atomic_t\fR	Type that can be accessed atomically
.DE
.DM
.ta 0.4i 1.40i
.if \nX=2 \fIManifest Constants\fR
.if \nX=4 \fIMacros\fR
	\fBSIG_DFL\fR	Default signal-handling indicator
	\fBSIG_ERR\fR	Indicate error in setting a signal
	\fBSIG_IGN\fR	Indicate ignore a signal
.sp \n(pDu
	\fBSIGABRT\fR	Abort signal
	\fBSIGFPE\fR	Erroneous arithmetic signal
	\fBSIGILL\fR	Illegal instruction
	\fBSIGINT\fR	Interrupt signal
	\fBSIGSEGV\fR	Invalid access to storage signal
	\fBSIGTERM\fR	Program termination signal
.DE
.DM
.ta 0.4i 1.40i
\fIFunctions\fR
	\fBraise\fR	Generate a signal
	\fBsignal\fR	Set processing for a signal
.DE
.SH "Cross-references"
.nf
\*(AS, \*(PS\fR4.7
\*(KR, p. 255
.SH "See Also"
.B
signal handling
.R
