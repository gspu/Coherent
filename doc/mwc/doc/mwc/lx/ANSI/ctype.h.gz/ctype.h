.\" ENVIRONMENTS:  COHERENT, LC, TOS, ISIS, ANSI
.TH ctype.h "Header" "(Library/character handling)" Header
.XR "header for character handling"
.XR "character-handling functions, header"
.PC "Header for character-handling functions"
.B "#include <ctype.h>"
.PP
.B ctype.h
is the header file that declares the functions used to handle characters.
These are as follows:
.DS
	\fBisalnum\fR	Check if a character is a numeral or letter
	\fBisalpha\fR	Check if a character is a letter
	\fBiscntrl\fR	Check if a character is a control character
	\fBisdigit\fR	Check if a character is a numeral
	\fBisgraph\fR	Check if a character is printable
	\fBislower\fR	Check if a character is a lower-case letter
	\fBisprint\fR	Check if a character is printable
	\fBispunct\fR	Check if a character is a punctuation mark
	\fBisspace\fR	Check if a character is white space
	\fBisupper\fR	Check if a character is a upper-case letter
	\fBisxdigit\fR	Check if a character is a hexadecimal numeral
	\fBtolower\fR	Convert character to lower case
	\fBtoupper\fR	Convert character to upper case
.DE
.SH Cross-references
.nf
\*(AS, \*(PS4.3
\*(KR, p. 248
.SH "See Also"
.B
.if \nX<4 character handling, header, xctype.h
.if \nX=4 character handling, character-case mapping, header
.R
