.\" ENVIRONMENTS:  COHERENT, LC, TOS, ISIS, ANSI
.TH time.h "Header" "(Library/date and time)" Header
.XR "date and time, header"
.XR "time and date, header"
.PC "Header for date and time"
.B "#include <time.h>"
.PP
.B time.h
is the header
that declares the function and defines the types
used to represent time.
It contains prototypes for the following nine functions:
.DS
.ta 0.4i 1.25i
	\fBasctime\fR	Convert broken-down time into text
	\fBclock\fR	Get processor time used by the program
	\fBctime\fR	Convert calendar time to text
	\fBdifftime\fR	Calculate difference between two times
	\fBgmtime\fR	Convert calendar time to Universal Coordinated Time
	\fBlocaltime\fR	Convert calendar time to local time
	\fBmktime\fR	Convert broken-down time into calendar time
	\fBstrftime\fR	Format locale-specific time
	\fBtime\fR	Get current calendar time
.DE
.PP
It also contains definitions for the following data types:
.DS
.ta 0.4i 1.25i
	\fBclock_t\fR	Encode system time
	\fBtime_t\fR	Encode calendar time
	\fBtm\fR	Encode broken-down time
.DE
.PP
It contains a definition for the macro
.BR CLK_TCK ,
which is used to convert the value returned by the function
.B clock
into seconds of real time.
.SH Cross-references
.nf
\*(AS, \*(PS4.12
\*(KR, p. 255
.SH "See Also"
.B
.if \nX<4 CLK_TCK, date and time, header, xtime.h
.if \nX=4 date and time, header
.R
