.\" ENVIRONMENTS: COHERENT, LC, TOS, ISIS, ANSI
.TH "float.h" Header "(Environment/environmental considerations)" Header
.XR "floating-point numbers, formula"
.PC
.PP
The header
.B float.h
defines a set of macros that return the limits for computation of
floating-point numbers.
.PP
.\"The following formula defines a floating-point number:
.\".sp 2
.\".br
.\".mk
.\".de AA
.\"\f(SIx =  \f(CIs  \f(LPX  \f(CIb   \f(LPX  \f(LXS   \f(SIf\f(LSk  \f(LPX  \f(CIb   ,  \f(SIe\f(LSmin \f(CI< \f(SIe \f(CI< \f(SIe\f(LSmax
.\"..
.\".de UU
.\".br
.\".rt
.\".sp -0.5v
.\".br
.\"\h'1.9c'\f(CIe\h'2.15c'\f(LS-k
.\"..
.\".de UN
.\".br
.\".rt
.\".sp -1v
.\"\h'2.62c'\f(LSp
.\"..
.\".de LL
.\".br
.\".rt
.\".sp 0.85v
.\".br
.\"\h'2.5c'\f(LSk=1
.\"..
.\".de LS
.\".br
.\".rt
.\".sp 0.15v
.\".br
.\"\h'5.75c'\f(CI_\h'0.56c'_
.\".br
.\"..
.\".br
.\".AA
.\".UU
.\".UN
.\".LL
.\".LS
.\".br
.\".sp 2
.\".R
.\"where
.\".I s
.\"indicates the sign (+1 or -1),
.\".I b
.\"indicates the base in which the exponent is represented
.\"(any integer greater than one),
.\".I e
.\"indicates the exponent (any integer between the minimum value
.\"\fIe\f(LSmin\fR and the maximum value \fIe\f(LSmax\fR),
.\".I p
.\"indicates the precision (that is, the number of digits in the mantissa,
.\"using base \fIb\fR), and, finally, \fIf\f(LSk\fR the mantissa digits.
.\".PP
The following lists the macros defined in
.BR float.h .
With the exception of
.BR FLT_ROUNDS ,
each macro is an expression;
each value given is the minimum maximum that each expression must yield.
The prefixes
.BR DBL ,
.BR FLT ,
and
.B LDBL
refer, respective, to
.BR double ,
.BR float ,
and
.BR "long double" .
.RS
.IP \fBDBL_DIG\fR
.br
Number of decimal digits of precision.
Must yield at least ten.
.IP \fBDBL_EPSILON\fR
.br
Smallest possible floating-point number \fIx\fR,
such that 1.0 plus \fIx\fR does not test equal to 1.0.
Must be at most 1E-9.
.IP \fBDBL_MANT_DIG\fR
.br
Number of digits in the floating-point mantissa for base
.BR FLT_RADIX .
.IP \fBDBL_MAX\fR
.br
Largest number that can be held by type
.BR double .
Must yield at least 1E+37.
.IP \fBDBL_MAX_EXP\fR
.br
Largest integer such that the value of
.B FLT_RADIX
raised to its power minus one is less than or equal to
.BR DBL_MAX .
.IP \fBDBL_MAX_10_EXP\fR
.br
Largest integer such that ten
raised to its power is less than or equal to
.BR DBL_MAX .
.IP \fBDBL_MIN\fR
.br
Smallest number that can be held by type
.BR double .
.IP \fBDBL_MIN_EXP\fR
.br
Smallest integer such that the value of
.B FLT_RADIX
raised to its power minus one is greater than or equal to
.BR DBL_MIN .
.IP \fBDBL_MIN_10_EXP\fR
.br
Smallest integer such that ten
raised to its power is greater than or equal to
.BR DBL_MAX .
.IP \fBFLT_DIG\fR
.br
Number of decimal digits of precision.
Must yield at least six.
.IP \fBFLT_EPSILON\fR
.br
Smallest floating-point number \fIx\fR, such that 1.0 plus \fIx\fR does not
test equal to 1.0.
Must be at most 1E-5.
.IP \fBFLT_MANT_DIG\fR
.br
Number of digits in the floating-point mantissa for base
.BR FLT_RADIX .
.IP \fBFLT_MAX\fR
.br
Largest number that can be held by type
.BR float .
Must yield at least 1E+37.
.IP \fBFLT_MAX_EXP\fR
.br
Largest integer such that the value of
.B FLT_RADIX
raised to its power minus one is less than or equal to
.BR FLT_MAX .
.IP \fBFLT_MAX_10_EXP\fR
.br
Largest integer such that ten
raised to its power is less than or equal to
.BR FLT_MAX .
.IP \fBFLT_MIN\fR
.br
Smallest number that can be held by type
.BR float .
.IP \fBFLT_MIN_EXP\fR
.br
Smallest integer such that the value of
.B FLT_RADIX
raised to its power minus one is greater than or equal to
.BR FLT_MIN .
.IP \fBFLT_MIN_10_EXP\fR
.br
Smallest integer such that ten
raised to its power is greater than or equal to
.BR FLT_MIN .
.IP \fBFLT_RADIX\fR
.br
Base in which the exponents of all floating-point numbers are represented.
.IP \fBFLT_ROUNDS\fR
.br
Manner of rounding used by the implementation, as follows:
.ID
.ta 0.1iR 0.4i
	\fB\-1\fR	Indeterminable, i.e., no strict rules apply
	\fB0\fR	Toward zero, i.e., truncation
	\fB1\fR	To nearest, i.e., rounds to nearest representable value
	\fB2\fR	Toward positive infinity, i.e., always rounds up
	\fB3\fR	Toward negative infinity, i.e., always rounds down
.IE
Any other value indicates that the manner of rounding is defined by the
implementation.
.IP \fBLDBL_DIG\fR
.br
Number of decimal digits of precision.
Must yield at least ten.
.IP \fBLDBL_EPSILON\fR
.br
Smallest floating-point number \fIx\fR, such that 1.0 plus \fIx\fR does not
test equal to 1.0.
Must be at most 1E-9.
.IP \fBLDBL_MANT_DIG\fR
.br
Number of digits in the floating-point mantissa for base
.BR FLT_RADIX .
.IP \fBLDBL_MAX\fR
.br
Largest number that can be held by type
.BR "long double" .
Must yield at least 1E+37.
.IP \fBLDBL_MAX_EXP\fR
.br
Largest integer such that the value of
.B FLT_RADIX
raised to its power minus one is less than or equal to
.BR LDBL_MAX .
.IP \fBLDBL_MAX_10_EXP\fR
.br
Largest integer such that ten
raised to its power is less than or equal to
.BR LDBL_MAX .
.IP \fBLDBL_MIN\fR
.br
Smallest number that can be held by type
.BR "long double" .
Must be no greater than 1E-37.
.IP \fBLDBL_MIN_EXP\fR
.br
Smallest integer such that the value of
.B FLT_RADIX
raised to its power minus one is greater than or equal to
.BR LDBL_MIN .
.IP \fBLDBL_MIN_10_EXP\fR
.br
Smallest integer such that ten
raised to its power is greater than or equal to
.BR LDBL_MIN .
.SH Cross-references
.nf
\*(AS, \*(PS2.2.4.2
\*(KR, p. 257
.SH "See Also"
.B
.if \nX<4 Environment, header, numerical limits
.if \nX=4 environmental considerations, header, numerical limits
.R
