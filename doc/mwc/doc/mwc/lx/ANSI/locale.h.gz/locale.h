.\" ENVIRONMENTS:  COHERENT, LC, TOS, ISIS, ANSI
.TH locale.h "Header" "(Library/localization)" Header
.XR "header, localization functions and macros"
.XR "localization functions and macros"
.PC "Localization functions and macros"
.B "#include <locale.h>"
.PP
.B locale.h
is a header that declares or defines all functions and macros used to
manipulate a program's locale.
The Standard describes the following items within this header:
.nf
.ta 0.4i 1.75i
.sp \n(pDu
\fIType\fR
	\fBlconv\fR	Structure for numeric formatting
.sp \n(pDu
.if \nX<4 \fIManifest constants\fR
.if \nX=4 \fIMacros\fR
	\fBLC_ALL\fR	All locale information
	\fBLC_COLLATE\fR	Locale collation information
	\fBLC_CTYPE\fR	Locale character-handling information
	\fBLC_MONETARY\fR	Locale monetary information
	\fBLC_NUMERIC\fR	Locale numeric information
	\fBLC_TIME\fR	Locale time information
.sp \n(pDu
\fIFunctions\fR
	\fBlocaleconv\fR	initialize \fBlconv\fR structure
	\fBsetlocale\fR	set/query locale
.SH "Cross-references"
.nf
\*(AS, \*(PS4.4
\*(KR, pp 
.SH "See Also"
.B
localization
.R
.if \nX=4 \{\
.SH Notes
An implementation may also define additional macros that examine the
locale.
All must begin with
.B LC_
followed by at least one capital letter.
Such names are reserved, i.e., a maximally portable program should not
define such names, as they may conflict with those already established
within the implementation. \}
