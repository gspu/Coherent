.\" ENVIRONMENTS:  COHERENT, LC, TOS, ISIS, ANSI
.TH assert.h "Header" "(Library/diagnostics)" Header
.XR "assertions, define elements that test"
.XR "define elements that test assertions"
.XR "header for assertions"
.PC "Header for assertions"
\fB#include <assert.h>\fR
.PP
.B assert.h
is the header file that defines the macro
.BR assert .
.SH Cross-references
.nf
\*(AS, \*(PS4.2
\*(KR, pp 
.SH "See Also"
.B
.if \nX<4 assert, diagnostics, header
.if \nX=4 assert, diagnostics, header, NDEBUG
.R
