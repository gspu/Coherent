.\" ENVIRONMENTS:  COHERENT, LC, TOS, ISIS, ANSI
.TH setjmp.h "Header" "(Library/non-local jump)" Header
.XR "header, non-local jump"
.PC "Declarations for non-local jump"
.B "#include <setjmp.h>"
.PP
.B setjmp.h
is the header that contains declarations for the elements
that perform a non-local jump.
It contains the prototype for the function
.BR longjmp ,
and it defines the macro
.B setjmp
and the type
.BR jmp_buf .
.SH Cross-references
.nf
\*(AS, \*(PS4.6
\*(KR, p. 254
.SH "See Also"
.B
header, jmp_buf, longjmp, non-local jump, setjmp
.R
