.\" ENVIRONMENTS:  COHERENT, LC, TOS, ISIS, ANSI
.TH math.h "Header" "(Library/mathematics)" Header
.XR "header, mathematics functions"
.XR "mathematics functions, declare"
.PC "Header for mathematics functions"
.B "#include <math.h>"
.PP
.B math.h
is the header file that declares and defines mathematical functions and
macros.
.PP
The Standard describes three
.if \nX<4 manifest constants
.if \nX=4 macros
to be included in
.BR math.h ,
as follows:
.DS
.ta 0.4i 1.5i
	\fBEDOM\fR	Domain error
	\fBERANGE\fR	Range error
	\fBHUGE_VAL\fR	Unrepresentable object
.DE
.PP
The first two are used to set the global variable
.B errno
to an appropriate value when, respectively, a domain error or
a range error occurs.
.B HUGE_VAL
is returned when any mathematics function attempts to calculate a number
that is too large to be encoded into a
.BR double .
.PP
.if \nX<4 \*(PN also includes 27 mathematics functions.
.if \nX=4 \{\
The Standard also describes 22 mathematics functions that are to be
included with every implementation of C. \}
For a listing of them, see
.BR mathematics .
.SH Cross-references
.nf
\*(AS, \*(PS4.5
\*(KR, p. 250
.SH "See Also"
.B
header, mathematics
.R
