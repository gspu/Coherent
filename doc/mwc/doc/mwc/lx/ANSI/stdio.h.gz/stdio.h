.\" ENVIRONMENTS:  COHERENT, LC, TOS, ISIS, ANSI
.TH stdio.h "Header" "(Library/STDIO)" Header
.XR "header, STDIO declarations and definitions"
.XR "STDIO declarations and definitions"
.XR "declarations and definitions for STDIO"
.PC "Declarations and definitions for STDIO"
.PP
.B stdio.h
is the header that holds the definitions, declarations, and
function prototypes used by the STDIO routines.
.PP
The following lists the
.if \nX<4 types, macros, and manifest constants
.if \nX=4 types and macros
defined in
.BR stdio.h :
.DS
.ta 0.4i 1.5i
\fITypes\fR
	\fBFILE\fR	Hold descriptor for a stream
	\fBfpos_t\fR	Hold current position within a file
.DE
.if \nX=4 \{\
.DS
\fIMacros\fR
	\fBstderr\fR	Pointer to standard error stream
	\fBstdin\fR	Pointer to standard input stream
	\fBstdout\fR	Pointer to standard output stream
.DE
.DS
\fIManifest Constants\fR
	\fB_IOFBF\fR	Indicates stream is fully buffered
	\fB_IOLBF\fR	Indicates stream is line-buffered
	\fB_IONBF\fR	Indicates stream is unbuffered
	\fBBUFSIZ\fR	Default size of buffer for STDIO stream
	\fBEOF\fR	Indicates end of file when returned by STDIO routine
	\fBFILENAME_MAX\fR
		Maximum length of a file name, in bytes
	\fBFOPEN_MAX\fR	Maximum number of files that can be opened at once
	\fBL_tmpnam\fR	Maximum length of temporary file name, in bytes
	\fBSEEK_CUR\fR	Seek from current position (\fBfseek\fR)
	\fBSEEK_END\fR	Seek from the end of a file (\fBfseek\fR)
	\fBSEEK_SET\fR	Seek from beginning of a file (\fBfseek\fR)
	\fBTMP_MAX\fR	Maximum number of calls to \fBtmpnam\fR
.DE \}
.if \nX=4 \{\
.DS
\fIMacros\fR
	\fB_IOFBF\fR	Indicates stream is fully buffered
	\fB_IOLBF\fR	Indicates stream is line-buffered
	\fB_IONBF\fR	Indicates stream is unbuffered
	\fBBUFSIZ\fR	Default size of buffer for STDIO stream
	\fBEOF\fR	Indicates end of file when returned by STDIO routine
	\fBFILENAME_MAX\fR
		Maximum length of a file name, in bytes
	\fBFOPEN_MAX\fR	Maximum number of files that can be opened at once
	\fBL_tmpnam\fR	Maximum length of temporary file name, in bytes
	\fBSEEK_CUR\fR	Seek from current position (\fBfseek\fR)
	\fBSEEK_END\fR	Seek from the end of a file (\fBfseek\fR)
	\fBSEEK_SET\fR	Seek from beginning of a file (\fBfseek\fR)
	\fBstderr\fR	Pointer to standard error stream
	\fBstdin\fR	Pointer to standard input stream
	\fBstdout\fR	Pointer to standard output stream
	\fBTMP_MAX\fR	Maximum number of calls to \fBtmpnam\fR
.DE \}
.SH "Cross-references
.nf
\*(AS, \*(PS4.9.1
\*(KR, pp. 151\fIff\fR, 241\fIff\fR
.SH "See Also"
.B
header, STDIO
.R
