.\" ENVIRONMENTS:  COHERENT, LC, TOS, ISIS, ANSI
.TH "stdarg.h" "Header" "(Library/variable arguments)" "Header"
.PC "Header for variable numbers of arguments"
\fB#include <stdarg.h>\fR
.PP
The header
.B stdarg.h
declares and defines
routines that are used to traverse a variable-length argument list.
It declares the type
.B va_list
and the function
.BR va_end ,
and it defines the macros
.B va_start
and
.BR va_arg .
.SH "Cross-references"
.nf
\*(AS, \*(PS4.8
\*(KR, p. 254
.SH "See Also"
.B
header, variable arguments
.R
