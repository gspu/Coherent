.TH "storclass.h" "" "" "Header File"
.PC "Define COFF storage classes"
#include <coff/storclass.h>
.PP
.B storclass.h
defines manifest constants for the various types of COFF storage classes.
.SH "See Also"
.B
a_out.h,
aouthdr.h,
arcoff.h,
file formats,
filehdr.h,
header files,
linenum.h,
reloc.h,
scnhdr.h,
syms.h,
utype.h
.R
