.\" ENVIRONMENTS:  COHERENT3
.TH  stty.h "" "" "Header File"
.PC "Manifest constants for tty settings"
.B "#include <sgtty.h>
.PP
The header file
.B sgtty.h
declares a number of manifest constants that are used to
set
.B tty
devices to a variety of baud rates and search patterns.
.SH "See Also"
.B
getty, header files
.R
