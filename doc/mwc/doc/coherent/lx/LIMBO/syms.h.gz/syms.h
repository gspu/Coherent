.TH "syms.h" "" "" "Header File"
.PC "COFF symbol-entry file"
#include <coff/syms.h>
.PP
.B syms.h
declares the structures and defines the manifest constants used for COFF
symbol entry.
.\" whatever the hell that means ... :-\
.SH "See Also"
.B
a_out.h,
aouthdr.h,
arcoff.h,
file formats,
filehdr.h,
header files,
linenum.h,
reloc.h,
scnhdr.h,
storclass.h,
utype.h
.R
