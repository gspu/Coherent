.TH "utype.h" "" "" "Header File"
.PC "Character-handling library"
#include <coff/utype.h>
.PP
.B utype.h
defines manifest constants and macros that are used to handle text
characters.
.SH "See Also"
.B
a_out.h,
aouthdr.h,
arcoff.h,
file formats,
filehdr.h,
header files,
linenum.h,
reloc.h,
scnhdr.h,
storclass.h,
syms.h
.R
