.TH "linenum.h" "" "" "Header File"
.PC "COFF line-number file"
#include <coff/linenum.h>
.PP
.B linenum.h
declares the structure, as follows:
.DM
.ta 0.5i 1.0i 1.5i 2.0i 3.5i
struct lineno
{
	union
	{
		long	l_symndx ;	/* sym. table index of function name
					iff l_lnno == 0      */
		long	l_paddr ;	/* (physical) address of line number */
	}		l_addr ;
	unsigned short	l_lnno ;	/* line number */
} ;
.DE
.PP
COFF sets one line-number entry for every
``breakpoint-able'' source line in a section.
Line numbers are grouped on a per-function
basis; the first entry in a function grouping
has
.DM
	l_lnno = 0
.DE
.PP
and in place of physical address is the symbol-table index of the function name.
.SH "See Also"
.B
a_out.h,
aouthdr.h,
arcoff.h,
file formats,
filehdr.h,
header files,
reloc.h,
scnhdr.h,
storclass.h,
syms.h,
utype.h
.R
