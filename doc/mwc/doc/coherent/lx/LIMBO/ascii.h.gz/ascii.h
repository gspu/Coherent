.TH ascii.h "" "" "Header File"
.PC "Define non-printable ASCII characters"
.B "#include <sys/ascii.h>"
.PP
.B ascii.h
defines a set of manifest constants that
describe the non-printable ASCII characters.
.SH "See Also"
.B
ASCII, header files
.R
