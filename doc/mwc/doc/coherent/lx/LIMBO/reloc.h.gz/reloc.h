.TH "reloc.h" "" "" "Header File"
.PC "COFF relocation file"
#include <coff/reloc.h>
.PP
.B reloc.h
declares structure
.BR reloc ,
as follows:
.DM
.ta 0.5i 2.0i 3.5i
struct reloc {
	long	r_vaddr;	/* (virtual) address of reference */
	long	r_symndx;	/* index into symbol table */
	unsigned short	r_type;		/* relocation type */
};
.DE
.PP
It also defines manifest constants for products and generic types.
.SH "See Also"
.B
a_out.h,
aouthdr.h,
arcoff.h,
file formats,
filehdr.h,
header files,
linenum.h,
scnhdr.h,
storclass.h,
syms.h,
utype.h
.R
