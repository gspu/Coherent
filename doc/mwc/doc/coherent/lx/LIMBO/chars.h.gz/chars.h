.TH chars.h "" "" "Header File"
.PC "Character definitions"
.B "#include <sys/chars.h>"
.PP
.B chars.h
defines manifest constants for some commonly used characters.
.SH "See Also"
.B
header files
.R
