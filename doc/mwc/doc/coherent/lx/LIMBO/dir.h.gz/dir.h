.TH dir.h "" "" "Header File"
.PC "Directory format"
.B "#include <dir.h>"
.PP
.II "COHERENT file format"
.II "file format^COHERENT file"
A \*(CO directory is exactly like an ordinary file,
except that a user's process may write on it only through
system calls such as
.BR creat() ,
.BR link() ,
.BR mknod() ,
or
.BR unlink() .
The system distinguishes directories from other types of
files by the mode word
.B S_IFDIR
in the i-node.
(For more information on i-nodes, see
.BR stat ).
.PP
Every directory is an array of entries
of the following structure, as defined in
the header file
.BR dir.h :
.DM
.ta 0.5i 2.5i
#define	DIRSIZ 14
.sp \n(pDu
struct direct {
	ino_t d_ino;	/* i-number */
	char d_name[DIRSIZ];	/* name */
};
.DE
.PP
Any entry in which
.B d_ino
has a value of zero is unused.
.PP
The command
.B mkdir
creates a directory, with the convention
that its first two entries are `.' and `..'.
The name `.' is self-referential \(em a link to the directory itself.
The name `..' is a link to the parent directory.
Because the root directory has no parent,
its `..' is a link to itself.
.PP
The
.B d_ino
entry of the directory structure
is stored in the file system in canonical form,
as described in
.BR canon.h .
.SH "See Also"
.B
canon.h,
header files,
mkdir,
stat()
.R
