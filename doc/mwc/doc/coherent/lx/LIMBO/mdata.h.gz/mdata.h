.TH mdata.h "" "" "Header File"
.PC "Define machine-specific magic numbers"
.B "#include <sys/mdata.h>"
.PP
.B mdata.h
defines the \*(QLmagic numbers\*(QR for the machine upon which \*(CO
is being run.
.SH "See Also"
.B
header files
.R
