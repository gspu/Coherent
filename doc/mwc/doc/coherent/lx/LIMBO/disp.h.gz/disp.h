.\" ENVIRONMENTS:  COHERENT3
.TH disp.h "" "" "Header File"
.PC "Control display of money strings"
.B "#include <disp.h>"
.PP
The header file
.B /usr/include/disp.h
contains manifest constants that control the printing of money strings
by the function
.BR ltomw .
.SH "See Also"
.B
header files, ltomw
.R
