.TH  access.h "" "" "Header File"
.PC "Check accessibility"
.B "#include <access.h>\fR
.PP
The header file
.B access.h
declares the function
.B access
and a set of associated manifest constants.
You can use these to check the accessibility of a given file.
.SH "See Also"
.B
access, header files
.R
