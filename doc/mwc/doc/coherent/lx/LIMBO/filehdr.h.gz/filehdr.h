.TH "filehdr.h" "" "" "Header File"
.PC ""
#include <coff/filehdr.h>
.PP
.B filehdr.h
declares the structure
.BR fileheader ,
which appears at the head of every COFF file,
plus numerous manifest constants.
.PP
.B filehead
is structured as follows:
.DM
.ta 0.5i 1.5i 3.0i
struct filehdr {
	unsigned short	f_magic;	/* magic number */
	unsigned short	f_nscns;	/* number of sections */
	long	f_timdat;	/* time & date stamp */
	long	f_symptr;	/* file pointer to symtab */
	long	f_nsyms;	/* number of symtab entries */
	unsigned short	f_opthdr;	/* sizeof(optional hdr) */
	unsigned short	f_flags;	/* flags */
};
.DE
.PP
The constants that identify the microprocessor for
which this file is compiled, and perform other useful tasks.
.SH "See Also"
.B
a_out.h,
aouthdr.h,
arcoff.h,
file formats,
header files,
linenum.h,
reloc.h,
scnhdr.h,
storclass.h,
syms.h,
utype.h
.R
.br
Gircyc, G.R.: \fIUnderstanding and Using COFF\fR.
Sebastopol, Calif, O'Reilly & Associates, Inc., 1990.
