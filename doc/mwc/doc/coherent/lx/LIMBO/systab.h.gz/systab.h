.TH "systab.h" "" "" "Header File"
.PC "Definions for the system-call table"
.B "#include <sys/systab.h>"
.PP
The header file
.B systab.h
holds definitions used by routines that manipulate the
system-call table.
.SH "See Also"
.B
header files
.R
