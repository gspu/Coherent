.TH "scnhdr.h" "" "" "Header File"
.PC "COFF section-header file"
#include <coff/scnhdr.h>
.PP
.B scnhdr.h
declares the structure
.BR scnhdr ,
as follows:
.DM
.ta 0.5i 1.5i 3.0i
struct scnhdr {
	char	s_name[8];	/* section name */
	long	s_paddr;	/* physical address, aliased s_nlib */
	long	s_vaddr;	/* virtual address */
	long	s_size;	/* section size */
	long	s_scnptr;	/* file ptr to raw data for section */
	long	s_relptr;	/* file ptr to relocation */
	long	s_lnnoptr;	/* file ptr to line numbers */
	unsigned short	s_nreloc;	/* number of relocation entries */
	unsigned short	s_nlnno;	/* number of line number entries */
	long	s_flags;	/* flags */
};
.DE
.PP
This structure prefaces each section within a COFF file.
.SH "See Also"
.B
a_out.h,
aouthdr.h,
arcoff.h,
file formats,
filehdr.h,
header files,
linenum.h,
reloc.h,
storclass.h,
syms.h,
utype.h
.R
