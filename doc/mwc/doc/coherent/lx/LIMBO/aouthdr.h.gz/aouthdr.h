.TH "aouthdr.h" "" "" "Header File"
.PC "COFF optional header"
#include <coff/aouthdr.h.h>
.PP
.B aouthdr.h
is the COFF optional header.
.SH "See Also"
.B
a_out.h,
arcoff.h,
file formats,
filehdr.h,
header files,
linenum.h,
reloc.h,
scnhdr.h,
storclass.h,
syms.h,
utype.h
.R
.br
Gircyc, G.R.: \fIUnderstanding and Using COFF\fR.
Sebastopol, Calif, O'Reilly & Associates, Inc., 1990.
