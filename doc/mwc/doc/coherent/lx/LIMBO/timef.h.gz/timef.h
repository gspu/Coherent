.TH timef.h "" "" "Header File"
.PC "Definitions for user-level timed functions"
.B "#include <timef.h>"
.PP
.B timef.h
defines structures and constants used by user-level timed functions.
.SH "See Also"
.B
header files
.R
