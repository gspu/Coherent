.\" ENVIRONMENTS:  COHERENT3
.TH v7sgtty.h "" "" "Header File"
.PC "UNIX Version 7-style terminal I/O"
.B "#include <v7sgtty.h>"
.PP
.B v7sgtty.h
defines structures and constants used by routines that perform
terminal I/O in the manner of UNIX version 7.
.SH "See Also"
.B
header files, sgtty.h, tty.h
.R
.SH Notes
.B v7sgtty.h
is included only with COHERENT 286.
