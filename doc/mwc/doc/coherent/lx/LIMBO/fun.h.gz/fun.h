.TH "fun.h" "" "" "Header File"
.PC "Miscellaneous definitions"
.B "#include <sys/fun.h>"
.PP
The header file
.B fun.h
holds miscellaneous definitions that are used by the obsolete method
of writing \*(CO device drivers.
.SH "See Also"
.B
header files
.R
