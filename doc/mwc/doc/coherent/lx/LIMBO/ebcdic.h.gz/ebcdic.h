.TH ebcdic.h "" "" "Header File"
.PC "Define constants for non-printable EBCDIC characters"
.B "#include <ebcdic.h>"
.PP
.B ebcdic.h
defines manifest constants for non-printable characters used in the
EBCDIC character set.
The constants correspond to those defined in the header file
.BR <sys/ascii.h> .
.SH "See Also"
.B
ASCII,
ascii.h,
header files
.R
