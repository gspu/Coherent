.ds TI "ERROR MESSAGES"
.ds TL "The COHERENT System"
.NH "Error Messages"
.PP
The following lists the error messages produced by
major utilities within \*(CO.
.SH "COHERENT System Error Messages"
.II "error messages^system"
.II "COHERENT system^error messages"
.PP
The following gives the error messages returned by the \*(CO kernel.
The messages describe two categories of error:
.IP \(bu 0.3i
\fBHardware:\fR
These messages indicate serious problems with your system hardware.
If any appears, you need to contact a representative
of the hardware manufacturer.
Note that the symbol `#' in the following messages stands for a number
that appears when the kernel prints the message on the console.
When reporting the problem, be sure to include the number actually printed out.
.IP \(bu
\fBHalts:\fR
These messages appear when \*(CO has crashed.
.PP
When you see a \fIhalt\fR message on the console, copy it down, as well
as all other information on the screen.
If the advice offered in this section does not help the problem, call
Mark Williams Support.
.PP
.so \*(DI/text/errors.coherent
.SH "Compiler Error Messages"
.II "cc^error messages"
.II "error messages^cc"
.II "compiler^error messages"
.PP
The following gives the error messages returned by
the \*(CO C compiler, the assembler \fBas\fR
and the linker \fBld\fR.
The messages are in alphabetical order, and each is marked as to whether it is a
.IR fatal ,
.IR error ,
.IR warning ,
or
.I strict
condition.
The compilation phases are
.BR cpp ,
the preprocessor;
.BR cc0 ,
the parser;
.BR cc1 ,
the code generator;
and
.BR cc2 ,
the optimizer.
.PP
A fatal message usually indicates a condition that caused
the compiler to terminate execution.
Fatal errors from the later phases of compilation often cannot
be fixed, and may indicate problems in the compiler or assembler.
.PP
An error message points to a condition in the source code
that the compiler cannot resolve.
This almost always occurs when the program does something illegal, e.g.,
has unbalanced braces.
.PP
Warning messages point out code that is compilable, but
may produce trouble when the program is executed.
A strict message refers to a passage in the code that is
unorthodox and may not be portable.
.Sh "as Error Messages"
.II "error messages^assembler"
.II "as^error messages"
.II "assembler^error messages"
.so \*(DI/text/errors.as
.Sh "cpp Error Messages"
.II "cpp^error messages"
.II "C preprocessor^error messages"
.II "error messages^cpp"
.so \*(DI/text/errors.cpp
.Sh "cc0 Error Messages"
.II "cc0^error messages"
.II "error messages^cc0"
.so \*(DI/text/errors.cc0
.Sh "cc1 Error Messages"
.II "cc1^error messages"
.II "error messages^cc1"
.so \*(DI/text/errors.cc1
.Sh "cc2 Error Messages"
.II "cc2^error messages"
.II "error messages^cc2"
.so \*(DI/text/errors.cc2
.Sh "ld Error Messages"
.II "error messages^linker"
.II "ld^error messages"
.II "linker^error messages"
.so \*(DI/text/errors.ld
.SH "fsck Error Messages"
.II "error messages^fsck"
.II "fsck^error messages"
.PP
The \*(CO command
.B fsck
checks the \*(CO file systems.
This command produces an especially rich set of error messages, both to
keep you abreast of its actions and to warn you of potential problems with
a file or file system.
.PP
.B fsck
can correct most of the common error conditions it detects; however,
if it detects an error that it can correct, it will stop and
ask your permission before it modifies your file system.
.PP
The following describes
.BR fsck 's
error messages and questions.
The error messages fall into two categories:
\fIwarnings\fR, which describe something possibly wrong with a file;
and \fBfatals\fR, which indicate that something has gone wrong with a file
system or with
.B fsck
with which
.B fsck
cannot cope.
Each question describes the condition in question; here, it is followed
by advice on what is probably the correct response.
.so \*(DI/text/errors.fsck
.SH "make Error Messages"
.II "error messages^make"
.II "make^error messages"
.PP
The following gives the error messages that can be produced by
.BR make .
Its message describe fatal conditions, errors, or warnings, as described above.
.so \*(DI/text/errors.make
.SH "nroff Error Messages"
.II "error messages^nroff"
.II "nroff^error messages"
.PP
The following gives \fBnroff\fR's error messages, and
hints about how to correct the situation.
Errors are of two types:
\fIsimple errors\fR, which simply cause an error message to be
printed on your screen; and \fIpanics\fR, which causes processing to abort.
Note that a panic will leave behind a half-written temporary
file; you may wish to look at the end of it to see just how far
processing proceeded, but otherwise it should be thrown away.
.so \*(DI/text/errors.nroff

