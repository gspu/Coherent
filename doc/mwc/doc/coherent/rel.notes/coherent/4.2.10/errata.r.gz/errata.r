.ds TL Errata
.NH "Notes and Errata"
.PP
The following notes limitations that have been discovered with \*(CO.
It also notes errors that have been found in the \*(CO manual, and
describes extensions to the \*(CO Lexicon that have been since the manual
was printed (but are available in the on-line Lexicon).
Try as we might, no system the size and complexity of \*(CO will ever
be entirely free of errors.
We hope that you will note these problems in your manual, and that you will
accept our apologies for any inconvenience they may have caused you.
.SH "Known Limitations"
.PP
\*(CO 4.2 contains the following limitations:
.IP \(bu 0.3i
The program that converts old \*(UU files into the Taylor format makes
a number of assumptions about the form and content of the old files.
If those assumptions are not met, the program may write something
non-functional into one of the new \*(UU files.
Please note the following in particular:
.RS
.IP \(bu 0.3i
On occasion, times are converted without a day of week into the
.B sys
file.
.IP \(bu
Some commands that the old
.B Permissions
file allowed do not always make it into
.BR sys .
.IP
Be sure to read the generated files
.BR sys ,
.BR dial ,
and
.B port
to make sure that all is correct.
For details, check the Lexicon entries for these files.
.RE
.IP \(bu
The command
.B uumvlog
manages the log files that are kept in directory /usr/spool/uucp/.Log.
However, it does not touch the files kept in directory
/usr/spool/uucp/.Admin.
These files log all UUCP connections to your system, and can grow quite large.
You must manage the files by hand.
.SH "Notes"
.PP
The following should be noted prior to using \*(CO.
.IP \(bu 0.3i
This release of \*(CO does not include the floppy tape driver.
It is under development, but was not ready in time to be included in this
release.
It will be available
.\" Real Soon Now
shortly and will be posted on the
Mark Williams Company Bulletin Board System.
If you require the driver on floppy disk
please contact our Sales Department at 1-800-636-6700 or 708-291-6700.
We apologize for this delay and thank you for your patience and understanding.
