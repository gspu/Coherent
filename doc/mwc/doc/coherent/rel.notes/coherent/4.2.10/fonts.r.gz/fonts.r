.\" font settings for the Mark Williams COHERENT manuals.
.\" by fwb, 6/91.
.\"
.\" copyright (c) 1991 by Mark Williams Company, Northbrook, Ill.
.\"
.lf B	Bookman_B.fwt   9
.lf I	Bookman_I.fwt   9
.lf K	I_keyb.fwt	9
.lf L	Courier_R.fwt   8
.lf R	Bookman_R.fwt   9
.lf S	Symbol.fwt      9
.lf DB	Dingbats.fwt    9
.lf HB	HelvNar_BI.fwt 12
.lf HC	Avant_B.fwt    24
.lf HH	HelvNar_B.fwt  18
.lf HR	HelvNar_R.fwt  12
.lf HL	HelvNar_BI.fwt 14
.lf IS  Bookman_I.fwt   8
.lf RS  Bookman_R.fwt   8
.lf SC	Bookman_R.fwt   8
.\" include keycap font in the output file
.\".rb /usr/typeface/ps/keyfont.ps2
