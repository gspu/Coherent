/* $Header: version.h,v 7.0 86/10/08 15:14:43 lwall Exp $
 *
 * $Log:	version.h,v $
 * Revision 7.0  86/10/08  15:14:43  lwall
 * Split into separate files.  Added amoebas and pirates.
 * 
 */

void version();
