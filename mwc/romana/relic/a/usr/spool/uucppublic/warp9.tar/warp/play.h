/* $Header: play.h,v 7.0 86/10/08 15:13:12 lwall Exp $ */

/* $Log:	play.h,v $
 * Revision 7.0  86/10/08  15:13:12  lwall
 * Split into separate files.  Added amoebas and pirates.
 * 
 */

EXT int finish INIT(0);
EXT int timer;

void play();
void play_init();
