/* $Header: init.h,v 7.0 86/10/08 15:12:17 lwall Exp $ */

/* $Log:	init.h,v $
 * Revision 7.0  86/10/08  15:12:17  lwall
 * Split into separate files.  Added amoebas and pirates.
 * 
 */

void initialize();
