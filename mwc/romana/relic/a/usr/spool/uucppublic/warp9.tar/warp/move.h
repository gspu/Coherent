/* $Header: move.h,v 7.0 86/10/08 15:12:46 lwall Exp $ */

/* $Log:	move.h,v $
 * Revision 7.0  86/10/08  15:12:46  lwall
 * Split into separate files.  Added amoebas and pirates.
 * 
 */

void bounce();
void move_universe();
int lookaround();
int lookfor();
OBJECT *lookimg();
void move_init();
