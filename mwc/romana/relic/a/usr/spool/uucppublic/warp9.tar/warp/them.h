/* $Header: them.h,v 7.0 86/10/08 15:14:19 lwall Exp $ */

/* $Log:	them.h,v $
 * Revision 7.0  86/10/08  15:14:19  lwall
 * Split into separate files.  Added amoebas and pirates.
 * 
 */

void their_smarts();
void modify_amoeba();
void them_init();
