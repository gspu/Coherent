/*
 * PD KSH
 * $Id: patchlevel.h,v 4.7 1992/08/12 14:15:45 sjg Exp $
 */
#define VERSION		4
#define PATCHLEVEL	7
